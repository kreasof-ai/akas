"""WebGPU specializations and shared bindings for ggml."""

from .definition import FORMAT, IMPLEMENTATIONS as _CHOICES


def decoder(encoding, depth):
    from akas.quantization.weights.ggml.kernel import weight_decoder

    return weight_decoder(encoding, depth, packed_words=True)


def bind(shape, *, encoding, layout="raw"):
    if layout == "planar":
        return planar_binding(shape, encoding=encoding)
    from akas.quantization.formats import Codec
    from akas.quantization._shared.access import matrix_reader, matrix_tile
    from .definition import FORMAT

    storage = FORMAT.storage(shape, provider="webgpu", encoding=encoding)
    read = matrix_reader(decoder(encoding, shape[-1]))

    return Codec(
        storage,
        read,
        matrix_tile(read, shape),
        dot_float=packed_dot_float(shape)
        if supports("dot_float", shape, encoding=encoding)
        else None,
    )


def gemv_terms(p, *, fast_q4, lanes, row_count, dot_q4, dot_q6):
    """Format-specific lane products; the operation owns launch and reduction."""
    import tilelang.language as T
    from akas.quantization._shared.packing import packed_loads
    from .kernel import weight_decoder

    k, q = p["k"], p["type"]
    planar = p.get("weight_layout", "raw") == "planar"
    if planar and (q != 2 or not fast_q4):
        raise ValueError("planar dense GEMV requires whole packed Q4_0 blocks")
    blocks = p["o"] * k // 32
    byte, half_value, word_value = packed_loads()
    decoder = weight_decoder(q, k, packed_words=True)

    def q4_terms(acc, x, index, scale, packed, slot):
        if dot_q4:
            for component in range(2):
                vector_term(acc[slot][0], x, index, scale, packed, component)
        else:
            for component in range(4):
                chain = component if p.get("gemv_accumulators", 1) == 4 else slot
                scalar_term(
                    acc[chain][0], x, index + component, scale, packed, component * 8, 0
                )
                scalar_term(
                    acc[chain][0],
                    x,
                    index + component,
                    scale,
                    packed,
                    component * 8 + 4,
                    16,
                )

    def q6_terms(acc, x, w, base, tile, lane, slot, scale):
        # A 16-lane subgroup owns both halves of the original 32-lane
        # assignment, retaining all 256 coefficients without cross-subgroup
        # workgroup barriers on Mali.
        for segment in range(32 // lanes):
            logical_lane = lane + segment * lanes
            if dot_q6:
                for half in range(2):
                    q6_vector(acc[slot][0], x, w, base, tile, logical_lane, half, scale)
            else:
                for group in range(8):
                    q6_scalar(
                        acc[slot][0], x, w, base, tile, logical_lane, group, scale
                    )

    @T.macro
    def scalar_term(acc: T.Ref, x, index, scale, packed, shift, offset):
        acc = acc + x[index + offset] * (
            scale * (T.cast(packed >> shift & 15, "float32") - 8)
        )

    @T.macro
    def vector_term(acc: T.Ref, x, index, scale, packed, component):
        left = T.call_extern(
            "float32x4",
            "vec4<f32>",
            x[index + component * 16],
            x[index + component * 16 + 1],
            x[index + component * 16 + 2],
            x[index + component * 16 + 3],
        )
        right = T.call_extern(
            "float32x4",
            "vec4<f32>",
            T.cast(packed >> component * 4 & 15, "float32") - 8,
            T.cast(packed >> 8 + component * 4 & 15, "float32") - 8,
            T.cast(packed >> 16 + component * 4 & 15, "float32") - 8,
            T.cast(packed >> 24 + component * 4 & 15, "float32") - 8,
        )
        acc = acc + scale * T.call_extern("float32", "dot", left, right)

    @T.macro
    def q6_scalar(acc: T.Ref, x, w, base, tile, lane, group, scale):
        low = byte(w, base + (group // 4 * 2 + group % 2) * 32 + lane)
        high = byte(w, base + 128 + group // 4 * 32 + lane)
        bits = byte(w, base + 192 + group * 2 + lane // 16)
        signed_scale = T.cast(
            T.cast(bits, "int32")
            - T.if_then_else(T.cast(bits, "int32") >= 128, 256, 0),
            "float32",
        )
        value = low >> 4 * (group % 4 // 2) & 15 | (high >> 2 * (group % 4) & 3) << 4
        acc = acc + x[tile * 256 + group * 32 + lane] * (
            scale * signed_scale * (T.cast(value, "float32") - 32)
        )

    @T.macro
    def q6_vector(acc: T.Ref, x, w, base, tile, lane, half, scale):
        low = word_value(w, base + half * 64 + lane // 8 % 2 * 32 + lane % 8 * 4)
        high = word_value(w, base + 128 + half * 32 + lane % 8 * 4)
        j = tile * 256 + half * 128 + lane * 4
        left = T.call_extern(
            "float32x4", "vec4<f32>", x[j], x[j + 1], x[j + 2], x[j + 3]
        )
        right = T.call_extern(
            "float32x4",
            "vec4<f32>",
            T.cast(
                low >> lane // 16 * 4 & 15 | (high >> lane // 8 * 2 & 3) << 4, "float32"
            )
            - 32,
            T.cast(
                low >> 8 + lane // 16 * 4 & 15 | (high >> 8 + lane // 8 * 2 & 3) << 4,
                "float32",
            )
            - 32,
            T.cast(
                low >> 16 + lane // 16 * 4 & 15 | (high >> 16 + lane // 8 * 2 & 3) << 4,
                "float32",
            )
            - 32,
            T.cast(
                low >> 24 + lane // 16 * 4 & 15 | (high >> 24 + lane // 8 * 2 & 3) << 4,
                "float32",
            )
            - 32,
        )
        bits = byte(w, base + 192 + half * 8 + lane // 4)
        signed_scale = T.cast(
            T.cast(bits, "int32")
            - T.if_then_else(T.cast(bits, "int32") >= 128, 256, 0),
            "float32",
        )
        acc = acc + scale * signed_scale * T.call_extern("float32", "dot", left, right)

    @T.macro
    def update_native(acc: T.Ref, x, w, tile, lane, row, bx):
        index = tile * 128 + lane * 4
        left = T.call_extern(
            "float32x4", "vec4<f32>", x[index], x[index + 1], x[index + 2], x[index + 3]
        )
        base = (bx * 4 + row) * k + index
        right = T.call_extern(
            "float32x4",
            "vec4<f32>",
            T.cast(w[base], "float32"),
            T.cast(w[base + 1], "float32"),
            T.cast(w[base + 2], "float32"),
            T.cast(w[base + 3], "float32"),
        )
        acc = acc + T.call_extern("float32", "dot", left, right)

    @T.macro
    def update_scalar(acc: T.Ref, x, w, tile, lane, row, bx):
        acc = acc + x[tile * 32 + lane] * decoder(
            w, bx * row_count + row, tile * 32 + lane
        )

    @T.macro
    def compute(acc, x, w, tile, lane, row, bx, slot):
        if fast_q4:
            block = (bx * row_count + row) * (k // 32) + tile * (lanes // 4) + lane // 4
            if planar:
                scale = T.call_extern(
                    "float32",
                    "tensor_unpack_f16",
                    w[blocks * 4 + block // 2] >> (block % 2 * 16) & T.uint32(65535),
                )
                packed = w[block * 4 + lane % 4]
            else:
                base = block * 18
                scale = half_value(w, base)
                packed = word_value(w, base + 2 + lane % 4 * 4)
            index = tile * (lanes * 8) + lane // 4 * 32 + lane % 4 * 4
            q4_terms(acc, x, index, scale, packed, slot)
        elif q == 14:
            base = ((bx * row_count + row) * (k // 256) + tile) * 210
            scale = half_value(w, base + 208)
            q6_terms(acc, x, w, base, tile, lane, slot, scale)
        elif q in (0, 1) and k % 128 == 0:
            update_native(acc[slot][0], x, w, tile, lane, row, bx)
        elif q == 2:
            base = ((bx * row_count + row) * (k // 32) + tile) * 18
            scale = half_value(w, base)
            packed = byte(w, base + 2 + lane)
            scalar_term(acc[slot][0], x, tile * 32 + lane, scale, packed, 0, 0)
            scalar_term(acc[slot][0], x, tile * 32 + lane, scale, packed, 4, 16)
        else:
            update_scalar(acc[slot][0], x, w, tile, lane, row, bx)

    return compute


def integer_rhs(shape, *, prepacked=False, layout="raw"):
    """Q4_0 logical words/scales for an integer matrix consumer."""
    from .definition import integer_layout

    k = shape[-1]
    blocks = shape[0] * k // 32
    if layout not in ("raw", "planar") or prepacked and layout != "raw":
        raise ValueError("invalid Q4_0 integer consumer layout")
    storage = integer_layout(shape, prepacked=prepacked)
    import tilelang.language as T
    from akas.quantization._shared.packing import packed_loads

    byte, half_value, word_value = packed_loads()

    @T.macro
    def read_word(w, col, block, word):
        if prepacked:
            return w[(col * (k // 32) + block) * 9 + word]
        elif layout == "planar":
            return w[(col * (k // 32) + block) * 4 + word]
        else:
            return word_value(w, (col * (k // 32) + block) * 18 + 2 + word * 4)

    @T.macro
    def read_scale(w, col, block):
        if prepacked:
            return T.reinterpret("float32", w[(col * (k // 32) + block) * 9 + 8])
        elif layout == "planar":
            return half_value(w, blocks * 16 + (col * (k // 32) + block) * 2)
        else:
            return half_value(w, (col * (k // 32) + block) * 18)

    return storage, read_word, read_scale


def q8_aligned_words(raw):
    """Keep signed coefficients and promote the block scale to aligned words."""
    import numpy as np

    blocks = raw.view("uint8").reshape(-1, 34)
    aligned = np.empty((len(blocks), 9), dtype="uint32")
    aligned[:, :8].view("uint8")[:] = blocks[:, 2:]
    scales = np.ascontiguousarray(blocks[:, :2]).view("<f2").reshape(-1)
    aligned[:, 8] = scales.astype("float32").view("uint32")
    return aligned.reshape(-1)


def q8_integer_rhs(shape, *, aligned=False):
    """Expose the original signed Q8_0 words and half block scales."""
    import tilelang.language as T

    from akas.quantization._shared.packing import packed_loads
    from .definition import weight_storage

    columns, depth = shape
    size = (
        columns * depth // 32 * 9
        if aligned
        else weight_storage(8, columns * depth, packed_words=True)[0]
    )
    _, half_at, word_at = packed_loads()

    @T.macro
    def word(w, column, block, index):
        if aligned:
            return w[(column * (depth // 32) + block) * 9 + index]
        else:
            return word_at(w, (column * (depth // 32) + block) * 34 + 2 + index * 4)

    @T.macro
    def scale(w, column, block):
        if aligned:
            return T.reinterpret("float32", w[(column * (depth // 32) + block) * 9 + 8])
        else:
            return half_at(w, (column * (depth // 32) + block) * 34)

    return size, word, scale


def q8_dot(k, o):
    """Packed Q8 activation × Q4_0 weight dot with inline correction sums."""
    if k <= 0 or k % 128:
        raise ValueError(
            "packed Q8 dot requires depth divisible by 128; use quantized_linear for other shapes"
        )
    import tilelang.language as T
    from akas.kernels.webgpu import segmented_reduce
    from akas.quantization._shared.packing import packed_loads

    lanes = 16
    segmented = segmented_reduce(lanes)
    byte, half_value, word_value = packed_loads()

    @T.macro
    def dot(x, scales, sums, w, out):
        with T.Kernel(T.ceildiv(o, 8), threads=128) as bx:
            tx = T.get_thread_binding()
            row = tx // lanes
            lane = tx % lanes
            accum = T.alloc_var("float32")
            scratch = T.alloc_shared((128,), "float32")
            accum = 0
            if bx * 8 + row < o:
                for tile in T.serial(k // 128):
                    block = tile * 4 + lane // 4
                    base = ((bx * 8 + row) * (k // 32) + block) * 18
                    packed = word_value(w, base + 2 + lane % 4 * 4)
                    low = T.call_extern(
                        "int32",
                        "dot4I8Packed",
                        packed & T.uint32(252645135),
                        x[block * 8 + lane % 4],
                    )
                    high = T.call_extern(
                        "int32",
                        "dot4I8Packed",
                        packed >> 4 & T.uint32(252645135),
                        x[block * 8 + lane % 4 + 4],
                    )
                    accum = accum + T.cast(
                        low + high - 2 * sums[block], "float32"
                    ) * scales[block] * half_value(w, base)
            segmented(accum, scratch, tx, lane)
            if (lane == 0) & (bx * 8 + row < o):
                out[bx * 8 + row] = scratch[tx]

    return dot


def q8_vector_dot(depth):
    """Four signed Q8_0 coefficients per lane with the original block scale."""
    import tilelang.language as T
    from akas.quantization._shared.packing import packed_loads

    _, scale_at, word_at = packed_loads()

    @T.macro
    def signed(word, shift):
        return T.cast(T.reinterpret("int32", word << shift) >> 24, "float32")

    @T.macro
    def product(x, w, column, index):
        base = (column * (depth // 32) + index // 32) * 34
        word = word_at(w, base + 2 + index % 32)
        values = T.call_extern(
            "float32x4", "vec4<f32>", x[index], x[index + 1], x[index + 2], x[index + 3]
        )
        coefficients = T.call_extern(
            "float32x4",
            "vec4<f32>",
            signed(word, 24),
            signed(word, 16),
            signed(word, 8),
            signed(word, 0),
        )
        return scale_at(w, base) * T.call_extern("float32", "dot", values, coefficients)

    return product


def dequantize(spec, schedule):
    from .kernel import dequantize

    return dequantize(spec, schedule, provider="webgpu")


AVAILABLE = "webgpu" in dict(FORMAT.providers)
CAPABILITIES = ("read", "read_tile", "dot_float", "dequantize")
IMPLEMENTATIONS = tuple(choice for choice in _CHOICES if choice.provider == "webgpu")


def packed_dot_float(shape):
    """A 32-lane, 256-channel tile with original F32 coefficients/operands."""
    import tilelang.language as T
    from tensor.compiler.webgpu.schedules.registers import vector
    from akas.quantization._shared.packing import packed_loads

    byte, half, word = packed_loads()
    depth = shape[-1]
    row_bytes = depth // 32 * 18

    def activation(x, channel):
        return vector([x[channel + i] for i in range(4)])

    def coefficients(packed, scale, offset):
        return vector(
            [
                (T.cast((packed >> (i * 8 + offset)) & 15, "float32") - 8) * scale
                for i in range(4)
            ]
        )

    @T.macro
    def dot(encoded, x, offset, tile, lane, row, previous):
        base = row * row_bytes + (tile * 8 + lane // 4) * 18
        scale = half(encoded[0], base)
        packed = word(encoded[0], base + 2 + lane % 4 * 4)
        channel = offset + tile * 256 + lane // 4 * 32 + lane % 4 * 4
        lo = activation(x, channel)
        hi = activation(x, channel + 16)
        low = coefficients(packed, scale, 0)
        high = coefficients(packed, scale, 4)
        return previous + (
            T.call_extern("float32", "dot", lo, low)
            + T.call_extern("float32", "dot", hi, high)
        )

    return dot


def supports(capability, shape, *, encoding, layout="raw"):
    from .definition import validate_layout

    validate_layout(shape, encoding=encoding, layout=layout)
    if layout == "planar":
        return capability in ("read", "read_tile", "dot_float")
    if capability == "dot_float":
        return encoding == 2 and shape[-1] % 256 == 0
    return capability in CAPABILITIES


def planar_dot_float(shape):
    """A 32-lane, 256-channel tile with original F32 coefficients/operands."""
    from math import prod
    import tilelang.language as T
    from tensor.compiler.webgpu.schedules.registers import vector
    from akas.quantization._shared.packing import packed_loads

    byte, half, word = packed_loads()
    depth = shape[-1]
    scales_offset = prod(shape) // 2

    def activation(x, channel):
        return vector([x[channel + i] for i in range(4)])

    def coefficients(packed, scale, offset):
        return vector(
            [
                (T.cast((packed >> (i * 8 + offset)) & 15, "float32") - 8) * scale
                for i in range(4)
            ]
        )

    @T.macro
    def dot(encoded, x, offset, tile, lane, row, previous):
        block = row * (depth // 32) + tile * 8 + lane // 4
        scale = half(encoded[0], scales_offset + block * 2)
        packed = encoded[0][block * 4 + lane % 4]
        channel = offset + tile * 256 + lane // 4 * 32 + lane % 4 * 4
        lo = activation(x, channel)
        hi = activation(x, channel + 16)
        low = coefficients(packed, scale, 0)
        high = coefficients(packed, scale, 4)
        return previous + (
            T.call_extern("float32", "dot", lo, low)
            + T.call_extern("float32", "dot", hi, high)
        )

    return dot


def planar_binding(shape, *, encoding):
    from akas.quantization.formats import Codec
    from akas.quantization._shared.access import matrix_tile
    from .definition import FORMAT
    from .kernel import planar_reader

    storage = FORMAT.storage(
        shape, provider="webgpu", encoding=encoding, layout="planar"
    )
    read = planar_reader(shape)
    return Codec(
        storage, read, matrix_tile(read, shape), dot_float=planar_dot_float(shape)
    )
