# Inworld Voice Isolator

`VoiceIsolator` runs the released **offline** `inworld/voice-isolator`
checkpoint as a compiled WebGPU Forward bundle. It processes mono 48 kHz audio
with the exact STFT, 46-band dual-path network, complex correction and iSTFT.
No learned computation remains on the host during a chunk.

The checkpoint reader validates all 691 tensors (64,047,112 parameters).
Original bytes are FP32; `weight_dtype="float16"` converts two-dimensional
projection matrices once at upload. Biases, normalization coefficients,
recurrent decay and skip coefficients remain F32. F16 projection operands use
F32 totals, while the selective scan, LayerNorm, exclusive attention, FFT
reconstruction and output waveform stay F32. Compile separate bundles to compare F16 with F32 storage.
The realtime checkpoint and streaming API are outside this offline demo.

```powershell
$env:WGPU_BACKEND_TYPE = 'Vulkan'
uv run --no-sync akas compile --profile speech `
  --definition akas.models.voice_isolator:VoiceIsolator `
  --checkpoint build/checkpoints/voice-isolator-v1/denoiser.safetensors `
  --checkpoint-options '{\"weight_dtype\":\"float16\"}' `
  --config '{\"chunks\":[144000,384000]}' `
  --out build/voice-isolator/f16
```

Each capacity is the exact sample count of one full network pass. Short clips
are not padded into an eight-second forward pass: non-causal attention would
otherwise see the padding. Long audio uses complete eight-second windows, a
six-second advance, and the upstream two-second linear crossfade. The last
window ends at the recording's end.

Use the canonical enhancement workload and isolated upstream environment:

```powershell
uv run --no-sync python -m tools.baselines inworld voice-isolator-v1 --provider cpu
uv run --no-sync python -m tools.baselines akas voice-isolator-v1 --provider vulkan --bundle build/voice-isolator/f16 --reference-run UPSTREAM_CPU_RUN_ID
uv run --no-sync python -m tools.campaign_report --runs AKAS_RUN_ID --model voice-isolator-v1 --workload voice-enhancement-demo-v1
```

The workload pins public Inworld demo/golden recordings, not the private VIBE
evaluation set. Warm timing starts before WAV decoding and ends with the
isolated FP32 waveform, excluding checkpoint loading and WAV writing. Each
output retains voice and background FP32 WAVs whose sum reconstructs the
input. Operation checks are not independent full-model quality qualification.
