# Baseline preflight

These are short execution checks for vLLM, SGLang and llama.cpp. Each worker
implements `run(config) -> report` using its own runtime. The launcher owns the
deadline, source capture and [benchmark history](../../benchmarks/README.md).
These probes do not establish optimized baseline throughput.

[Model declarations](../../benchmarks/models/) hold checkpoint paths, pinned
sources, generation modes and runtime options. Add a model by adding one JSON
file; the workers contain no model-name dispatch. Cache weights under
`build/checkpoints/<model-id>/`. A declaration may point to an existing local
cache; copying large files is unnecessary.

Create separate Python 3.12 environments under `build/baselines/vllm` and
`build/baselines/sglang`. The validated versions are vLLM 0.31.0 and SGLang 0.5.21;
install each with `uv pip install --python <environment>/bin/python`. Use a
complete CUDA toolkit and set `CUDA_HOME` and `PATH` to it. An environment with
`nvcc` but missing CUDA headers is insufficient for first-use JIT compilation.
Keep compiler, CRT, NVVM and runtime headers on compatible CUDA versions; merely
installing a newer `nvcc` beside older headers can fail FlashInfer startup.

Build llama.cpp commit `620d2225cc436ab0b001e3200e590e3b286ef9ab` under
`build/baselines/llama.cpp`, with separate `build-cuda` and `build-vulkan`
directories. Enable `GGML_CUDA` or `GGML_VULKAN` and build `llama-server`.
Use the GPU's actual CUDA architecture. Vulkan needs the loader and matching
NVIDIA graphics libraries; a software Vulkan adapter is not a GPU baseline.

Run one probe at a time from the repository root:

```sh
uv run --no-sync python -m tools.baselines vllm lfm
uv run --no-sync python -m tools.baselines vllm qwen
uv run --no-sync python -m tools.baselines vllm qwen --mtp
uv run --no-sync python -m tools.baselines sglang lfm
uv run --no-sync python -m tools.baselines sglang qwen
uv run --no-sync python -m tools.baselines sglang qwen --mtp
uv run --no-sync python -m tools.baselines llama qwen --format q4_k_m --provider vulkan
```

Native probes check B1/P32, B4/P32 and B1/P2048 with 128 total output tokens.
The llama.cpp server probe checks B1 at both prompt lengths; server concurrency
is not a controlled native batch. MTP checks compare token IDs against the
matching AR probe, which must be run first. Every probe uses one warmup and one
measured repeat, with a ten-minute process deadline by default. Cold JIT
compilation can consume several minutes; keep its cache for subsequent runs.

The launcher archives its exact model/configuration files, runtime dependencies,
checkpoint hash, raw output and log. `purpose=preflight` keeps these records
separate from final measurements. Failures and time limits remain in history.

For Qwen F16, the model declaration specifies conversion from the pinned original
safetensors checkpoint with llama.cpp `--outtype f16 --no-mtp`; a vision projector
is not the text model. The other GGUF variants reference their pinned repositories.
Use identical resulting bytes when measuring AKAS and llama.cpp.

## Speech synthesis demo

The [ZONOS3-Mini declaration](../../benchmarks/models/zonos3-mini.json) pins
the Q8_0 backbone, F32 audio projector, and llama.cpp b12424 revision.
Place both GGUF files at their declared paths and extract the
[Windows Vulkan release](https://github.com/ggml-org/llama.cpp/releases/tag/b12424)
under `build/baselines/llama-b12424-vulkan`. Supply `--binary` to use a build
from the same revision elsewhere.

```sh
uv run --no-sync python -m tools.baselines llama zonos3-mini --format q8_0 --provider vulkan
```

Compile AKAS with the [ZONOS3-Mini speech profile](../../src/akas/models/zonos3/README.md).
Use the retained llama.cpp Vulkan run ID when measuring AKAS. The launcher
checks the reference report checksum, hardware, checkpoint pair, and workload.

```sh
uv run --no-sync python -m tools.baselines akas zonos3-mini --format q8_0 --provider vulkan \
  --bundle build/zonos3-mini/speech --reference-run LLAMA_RUN_ID
```

Use `--workload speech-multilingual-v1` on both commands to run six
FLORES-200 prompts in each of the 43 model-card languages. Set a deadline
for the full matrix with `--seconds` and include a 384-frame codec phase
in the AKAS bundle so its capacity covers the request frame limit.
Export the measured run and its frozen reference with
`python -m tools.campaign_report --runs AKAS_RUN_ID --model zonos3-mini --workload speech-multilingual-v1`.

`speech-language-voices-v1` keeps the same six prompts for each of the 10
languages with a shipped preset. It explicitly pins a matching voice per
language on both runtimes. Use its own frozen llama.cpp run when comparing it.

Select `--provider cpu` on the llama.cpp command for a CPU control.

[`speech-demo-v1`](../../src/akas/benchmarking/workloads/speech-demo-v1.json)
uses two English utterances, a fixed seed and the same predefined voice on both
backends. Each utterance gets one warmup and three measured requests. Timing
starts at the localhost request and ends when the client has read all PCM16
samples. It includes text conditioning, audio generation, codec decoding and
delivery. The real-time factor is elapsed seconds divided by returned audio
seconds. Model loading and WAV writing are outside this interval.

The run retains the workload, the server log and a WAV per measured repeat
under `benchmarks/runs/<run-id>/`. The comparison reports both wall latency
and the ratio of real-time factors. Seeded sampling can produce different clip
durations across runtimes.

## Speech transcription demo

[Qwen3 ASR](../../src/akas/models/qwen3_asr/README.md) uses the pinned
Rumble-2-Flash Q8_0 decoder and Q8_0 audio projector. Extract the
[llama.cpp b12521 Windows Vulkan release](https://github.com/ggml-org/llama.cpp/releases/tag/b12521)
under `build/baselines/llama-b12521-vulkan` or pass a binary from that
revision with `--binary`.

```sh
uv run --no-sync python -m tools.baselines llama qwen3-asr --provider vulkan
uv run --no-sync python -m tools.baselines akas qwen3-asr --provider vulkan \
  --bundle build/qwen3-asr/speech --reference-run LLAMA_RUN_ID
uv run --no-sync python -m tools.campaign_report --runs AKAS_RUN_ID \
  --model qwen3-asr --workload asr-demo-v1
```

Both runtimes read the same WAV, force the clip's language, and decode
greedily. The launcher uses a persistent AKAS worker and the stock
`llama-mtmd-cli` over local process pipes. Wall time includes reading each WAV
through receipt of the complete transcript. It excludes model loading and
context reset. The
[`asr-demo-v1` workload](../../src/akas/benchmarking/workloads/asr-demo-v1.json)
pins English, Indonesian and Japanese clips from the repository's ZONOS3-Mini
showcase. Each clip gets one warmup and three measurements. The recorder
retains the input, transcript and request latency, plus word or character
error against the synthesis script. These three synthetic clips demonstrate
the end-to-end path. Independent transcription quality requires a broader
recorded speech workload.

### ASR latency by input duration

[`asr-length-v1`](../../src/akas/benchmarking/workloads/asr-length-v1.json) pins
nine LibriSpeech dev-clean recordings from one reader. Its short, medium and
long bands cover 1.91–4.23 s, 9.01–12.49 s and 15.12–29.40 s. It uses the
same 512-token context on both runtimes with a 100-token output cap so the
longest input stays within the compiled context.

Download the Parquet archive pinned in the workload's `source.archive` and
verify `source.sha256`. To recreate the input WAVs, use PyArrow and SoundFile
in an audio preparation environment. Decode the selected FLAC rows as
signed 16-bit PCM and write mono WAV headers with Python's `wave` module.

```python
import io
import json
import wave
from hashlib import sha256
from pathlib import Path

import pyarrow.parquet as pq
import soundfile as sf

workload = json.loads(Path("src/akas/benchmarking/workloads/asr-length-v1.json").read_text())
archive = Path("validation-00000-of-00001.parquet")
assert sha256(archive.read_bytes()).hexdigest() == workload["source"]["sha256"]
audio = {row["id"]: row["audio"]["bytes"] for row in pq.read_table(archive, columns=["id", "audio"]).to_pylist()}
for clip in workload["utterances"]:
    pcm, rate = sf.read(io.BytesIO(audio[clip["id"]]), dtype="int16")
    path = Path(clip["path"])
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as wav:
        wav.setparams((1, 2, rate, 0, "NONE", "not compressed"))
        wav.writeframes(pcm.astype("<i2", copy=False).tobytes())
    assert sha256(path.read_bytes()).hexdigest() == clip["sha256"]
```

Use the existing ASR commands with `--workload asr-length-v1` on both
runtimes and the report exporter. Freeze a new Vulkan run for this workload.

## Measure the complete workload

Add `--optimized` to enable graph execution for the native engines, provision the
full request capacity, and measure all ten `standard-v1` shapes. Each shape runs
one warmup and three measured repetitions, generating exactly 128 tokens per
request. `--workload path.json`, `--repeats` and `--seconds` provide bounded pilot
controls. Final measurements keep their complete runtime settings and sampled
whole-device VRAM; graph capture and loading are outside inference timings.

```sh
python -m tools.baselines vllm lfm --optimized --seconds 900
python -m tools.baselines sglang qwen --optimized --seconds 900
python -m tools.baselines sglang qwen --mtp --optimized --seconds 900
python -m tools.baselines llama qwen --format q4_0 --provider vulkan \
  --optimized --seconds 900
```

The engines receive the same deterministic uniform token-ID prompts as the AKAS
optimizer: seed `17 + B*4099 + P`, using each model's declared vocabulary.
This is a synthetic workload, not an arrival trace or a language-quality test.
Prefix reuse and early EOS are disabled. The MTP run requires its matching AR
run, then compares every output ID at every shape. Completed shapes are saved
incrementally; later OOM, failure or timeout cannot erase their raw evidence.
The llama.cpp worker also disables the RAM prompt cache, idle-slot caching and
context checkpoints. These retained copies are unnecessary for empty-prefix AR
requests and can exhaust host RAM when many recurrent-model slots are active.

These measurements are concurrent request bursts. The scheduler may split or
interleave prefills; B256 does not promise a fixed GPU batch of 256 on every
step. vLLM phase rates use the maximum per-request TTFT and decode interval.
SGLang rates use scheduler prefill-completion and request-finish timestamps;
non-streaming first-output timestamps can reflect buffered outputs instead.
These include scheduler effects. llama.cpp rates use its reported server
prompt/evaluation durations, which have a separate protocol label. Preserve the
raw samples and compare like protocols; these are not interchangeable with
AKAS's isolated native kernel-phase rates. End-to-end committed output throughput
is retained for every runtime. Default optimized settings are measured settings,
not proof that exhaustive baseline tuning found the fastest possible setup.

Use `--format fp8` for declarations containing original FP8 safetensors. Weight
format selection is independent of execution and KV dtypes. For the concurrent
FP8 workload and real token-delivery timing:

```sh
python -m tools.baselines vllm lfm2.5-24b-a2b-fp8 --format fp8 \
  --optimized --streaming --workload concurrent-prefill-v1 --seconds 2400
python -m tools.baselines sglang lfm2.5-24b-a2b-fp8 --format fp8 \
  --optimized --streaming --workload concurrent-prefill-v1 --seconds 2400
```

Both streamed workers use the same cumulative-token collector and record
`client-stream-burst-v1` phase timings, including per-request arrivals and
delivery chunk sizes. They submit distinct requests concurrently, use raw token
IDs with tokenization disabled, and check complete deterministic outputs and
empty-prefix-cache behavior. Keep the source immutable throughout a measurement;
the recorder invalidates changed source trees. A separate frozen checkout lets
development continue while a baseline runs.

First-use FlashInfer warmup also needs cuRAND development headers in the selected
CUDA toolkit. Keep runtime environments isolated and measurements serial.
