"""Preloaded scale tiles retain sequential block-scaling arithmetic."""
import os
import pytest


@pytest.mark.skipif(os.getenv('AKAS_LFM_FP8_CUDA')!='1',reason='CUDA expert scale preload qualification')
@pytest.mark.parametrize('kind,routed,stages',[
 ('expert_partial',True,1),('expert_partial',True,2),
 ('fp8_expert_swiglu',False,1),('fp8_expert_swiglu',False,2),
 ('expert_swiglu',False,1),('expert_swiglu',False,2),
])
def test_transposed_scale_preload_matches_independent_equations(tmp_path,kind,routed,stages):
    from test_lfm_moe_native import test_native_operations_match_independent_references as check
    p=dict(r=33,rows=33,k=384,o=256,experts=7,top=3,partitions=1,
           block_m=32,max_block_m=64,compact=True,tile_map=True,columns=128,
           threads=128,stages=stages,activation_vector=16,packed_input=True,
           packed_output=kind=='fp8_expert_swiglu',routed_input=routed,
           product_dtype='bfloat16',activation_dtype='bfloat16',preload_scales=True)
    if kind=='expert_swiglu':p.update(weight_format='fp8',input_dtype='uint8',output_dtype='bfloat16')
    check(tmp_path,kind,p)
