"""WebGPU specializations and shared bindings for residual."""

from .kernel import add
from .definition import IMPLEMENTATIONS as _CHOICES

IMPLEMENTATIONS = tuple((choice for choice in _CHOICES if choice.provider == "webgpu"))


def batched_attention_residual(spec, schedule):
    """Evaluate independent residual scores through shared reduction barriers."""
    import tilelang.language as T
    from akas.kernels.kernel import Tensor, kernel, output

    p = {**spec.parameters, **schedule}
    rows, width, capacity, index, epsilon = (
        p[key] for key in ("r", "c", "capacity", "index", "eps")
    )
    if rows != 1 or index < 3:
        raise ValueError("batched residual scoring requires one row and four scores")
    groups = p.get("groups", min(4, (index + 1) // 2))
    threads = p.get("threads", 128)
    if groups not in (2, 4) or threads != 128:
        raise ValueError(
            "batched residual scoring requires two or four 128-lane groups"
        )
    rounds = (index + 1 + groups - 1) // groups

    @kernel
    def compute(
        bank: Tensor((capacity, rows, width), "float32"),
        source: Tensor((rows, width), "float32"),
        query: Tensor((width,), "float32"),
    ) -> tuple[
        Tensor((capacity, rows, width), "float32"), Tensor((rows, width), "float32")
    ]:
        out = output((rows, width), "float32")
        with T.Kernel(rows, threads=threads) as row:
            lane = T.get_thread_binding()
            scores = T.alloc_shared((index + 1,), "float32")
            norms = T.alloc_shared((groups, threads), "float32")
            dots = T.alloc_shared((groups, threads), "float32")
            peak = T.alloc_shared((1,), "float32")
            denominator = T.alloc_shared((1,), "float32")
            sum_sq = T.alloc_local((groups,), "float32")
            dot = T.alloc_local((groups,), "float32")
            for stripe in T.serial(T.ceildiv(width, threads)):
                column = stripe * threads + lane
                if column < width:
                    bank[index, row, column] = source[row, column]
            T.sync_threads()
            for batch in T.serial(rounds):
                for group in T.serial(groups):
                    sum_sq[group] = 0
                    dot[group] = 0
                    for stripe in T.serial(T.ceildiv(width, threads)):
                        column = stripe * threads + lane
                        if column < width and batch * groups + group <= index:
                            entry = bank[batch * groups + group, row, column]
                            sum_sq[group] += entry * entry
                            dot[group] += entry * query[column]
                    norms[group, lane] = sum_sq[group]
                    dots[group, lane] = dot[group]
                T.sync_threads()
                for stride in T.serial(threads // 2, 0, -1):
                    for group in T.serial(groups):
                        if lane < stride:
                            norms[group, lane] = (
                                norms[group, lane] + norms[group, lane + stride]
                            )
                            dots[group, lane] = (
                                dots[group, lane] + dots[group, lane + stride]
                            )
                    T.sync_threads()
                if lane == 0:
                    for group in T.serial(groups):
                        if batch * groups + group <= index:
                            scores[batch * groups + group] = dots[group, 0] * T.rsqrt(
                                norms[group, 0] / width + epsilon
                            )
            if lane == 0:
                peak[0] = scores[0]
                for i in T.serial(1, index + 1):
                    peak[0] = T.max(peak[0], scores[i])
                denominator[0] = 0
                for i in T.serial(index + 1):
                    scores[i] = T.exp(scores[i] - peak[0])
                    denominator[0] += scores[i]
            T.sync_threads()
            for stripe in T.serial(T.ceildiv(width, threads)):
                column = stripe * threads + lane
                if column < width:
                    total = T.alloc_var("float32")
                    total = 0
                    for i in T.serial(index + 1):
                        total += bank[i, row, column] * (scores[i] / denominator[0])
                    out[row, column] = total
        return bank, out

    return compute
