"""Exercise the published ZONOS3 weights in AKAS's compiled WebGPU path."""

from contextlib import ExitStack
import os
from pathlib import Path

import numpy as np
import pytest

from akas.checkpoints.gguf import GGUF


ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.skipif(
    os.environ.get("AKAS_ZONOS3_VULKAN") != "1",
    reason="requires both published ZONOS3 GGUF files and a hardware Vulkan adapter",
)
def test_zonos3_checkpoint_operations_on_vulkan(tmp_path):
    from akas.benchmarking.history import Recorder, digest
    from akas.compilation.compile import produce
    from akas.compilation.tuning import SearchSettings
    from akas.execution.forward import Forward
    from akas.graph import Graph
    from akas.quantization._shared.packing import pack_words
    from akas.quantization.weights.ggml.definition import weight_storage
    from tools.baselines.__main__ import model_definition
    from tools.baselines.speech import checked_file
    from tools.context_sweep import vulkan_device

    model_path, model = model_definition(ROOT / "benchmarks/models", "zonos3-mini")
    speech = model["runtime_options"]["llama"]["speech"]
    weight = checked_file(ROOT, model["weights"]["q8_0"])
    projector = checked_file(ROOT, speech["projector"])
    backbone, audio = GGUF(weight["path"]), GGUF(projector["path"])
    assert backbone.metadata["general.architecture"] == "zonos3"
    assert backbone.metadata["general.file_type"] == 7
    assert audio.metadata["clip.gen.audio.projector_type"] == "zonos3_gen"

    inputs = {
        "token": np.array([backbone.metadata["tokenizer.ggml.bos_token_id"]], np.int32),
        "hidden": np.random.default_rng(17).normal(0, 0.25, 1024).astype(np.float32),
        "codes": np.array([0, 1, 4095, 4096, 4097, 5, 6, 7, 8, 9], np.int32)
        + np.arange(10, dtype=np.int32) * 4098,
    }
    graph = Graph(contract="reference")
    buffers = {
        name: graph.buffer(name, value.shape, str(value.dtype), role="input")
        for name, value in inputs.items()
    }
    sources = {
        "token_embd.weight": backbone,
        "blk.0.attn_qkv.weight": backbone,
        "a.gen.code.head.weight": audio,
        "a.gen.code.out_embd.weight": audio,
    }
    for name, source in sources.items():
        info = source.tensors[name]
        count, dtype = weight_storage(
            info.type, np.prod(info.shape).item(), packed_words=True
        )
        buffers[name] = graph.buffer(name, (count,), dtype, role="weight")

    embed = graph.buffer("token_embedding", (1024,), "float32", role="output")
    qkv = graph.buffer("first_gdn_qkv", (1536,), "float32", role="output")
    scores = graph.buffer("codebook_logits", (40980,), "float32", role="output")
    feedback = graph.buffer("feedback_rows", (10 * 1024,), "float32", role="output")
    graph(
        "embedding",
        dict(r=1, c=1024, v=8250, ggml=True, type=8),
        buffers["token"],
        buffers["token_embd.weight"],
        embed,
    )
    graph(
        "linear",
        dict(r=1, k=1024, o=1536, ggml=True, type=8, optimized=True),
        buffers["hidden"],
        buffers["blk.0.attn_qkv.weight"],
        qkv,
    )
    graph(
        "linear",
        dict(r=1, k=1024, o=40980),
        buffers["hidden"],
        buffers["a.gen.code.head.weight"],
        scores,
    )
    graph(
        "embedding",
        dict(r=10, c=1024, v=40980),
        buffers["codes"],
        buffers["a.gen.code.out_embd.weight"],
        feedback,
    )
    outputs = {
        embed.name: embed,
        qkv.name: qkv,
        scores.name: scores,
        feedback.name: feedback,
    }
    metadata = dict(
        model=model["model"],
        runtime="akas",
        purpose="operation-qualification",
        provider="webgpu",
        protocol="zonos3-checkpoint-operation-probe-v1",
        weight_format="q8_0",
        checkpoint=weight["path"],
        checkpoint_sha256=weight["sha256"],
        checkpoint_source=weight["source"],
        projector=projector,
        model_definition_sha256=digest(model_path),
        checks=[],
    )
    recorder = Recorder(
        ROOT / "benchmarks",
        metadata,
        kind="qualification",
        change="Qualify ZONOS3 checkpoint operations on the native AKAS Vulkan path",
    )
    recorder.artifact(model_path, "model.json")
    report = dict(schema="akas.benchmark.v1", metadata=metadata, results=[])
    status = "failed"
    try:
        with vulkan_device() as device, ExitStack() as resources:
            metadata["device"] = dict(
                device.info, name=device.info["adapter"]["device"]
            )
            manifest = produce(
                graph,
                tmp_path,
                provider="webgpu",
                device=device,
                search_settings=SearchSettings(budget=2, samples=3, repeats=3),
            )
            recorder.artifact(tmp_path / "forward.json", "forward.json")
            metadata["kernels"] = manifest["kernels"]
            values = dict(inputs)
            for name, source in sources.items():
                info = source.tensors[name]
                raw = source.packed(name)
                values[name] = (
                    pack_words(raw) if info.type == 8 else raw.view(np.float32)
                )
            uploaded = {}
            for name, value in values.items():
                uploaded[name] = device.from_numpy(np.ascontiguousarray(value))
                resources.callback(uploaded[name].release)
            for name, output in outputs.items():
                uploaded[name] = device.empty(output.shape, output.dtype)
                resources.callback(uploaded[name].release)
            with Forward(tmp_path, device, uploaded, graphs=True) as forward:
                forward.run()
                device.synchronize()
                actual = {name: uploaded[name].to_numpy() for name in outputs}

        hidden = inputs["hidden"].astype(np.float64)
        expected = {
            embed.name: backbone.row("token_embd.weight", int(inputs["token"][0])),
            qkv.name: backbone.array("blk.0.attn_qkv.weight", dtype=np.float64)
            @ hidden,
            scores.name: audio.array("a.gen.code.head.weight", dtype=np.float64)
            @ hidden,
            feedback.name: np.concatenate(
                [
                    audio.row("a.gen.code.out_embd.weight", int(i))
                    for i in inputs["codes"]
                ]
            ),
        }
        for name, value in actual.items():
            reference = expected[name]
            bitwise = np.array_equal(value, reference.astype(np.float32))
            error = float(np.max(np.abs(value - reference)))
            metadata["checks"].append(
                dict(
                    output=name,
                    elements=value.size,
                    max_abs_error=error,
                    bitwise=bitwise,
                )
            )
            if name in (embed.name, feedback.name):
                np.testing.assert_array_equal(value, reference)
            else:
                np.testing.assert_allclose(value, reference, rtol=3e-5, atol=4e-5)
        # Use the audio-head cap and sum feedback in codebook order.
        np.testing.assert_allclose(
            15 * np.tanh(actual[scores.name] / 15),
            15 * np.tanh(expected[scores.name] / 15),
            rtol=3e-5,
            atol=4e-5,
        )
        np.testing.assert_array_equal(
            actual[feedback.name].reshape(10, 1024).sum(axis=0),
            expected[feedback.name].reshape(10, 1024).sum(axis=0),
        )
        status = "passed"
    except Exception as error:
        metadata["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        record = recorder.update(report, final=True, status=status)
        print(
            f"ZONOS3 operation evidence {record['id']} {record['status']}", flush=True
        )
    assert record["status"] == "passed"
