"""Exercise the published ZONOS3 weights in AKAS's compiled WebGPU path."""

from contextlib import ExitStack
import json
import os
from pathlib import Path
import subprocess

import numpy as np
import pytest

from akas.models.zonos3 import Zonos3MiniCheckpoint, compose
from akas.models.zonos3.audio import codebook_logits, feedback_embedding, feedback_ids


ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.skipif(
    os.environ.get("AKAS_ZONOS3_VULKAN") != "1",
    reason="requires both published ZONOS3 GGUF files and a hardware Vulkan adapter",
)
def test_zonos3_checkpoint_operations_on_vulkan(tmp_path):
    from akas.benchmarking.history import Recorder, digest
    from akas.compilation.compile import produce
    from akas.compilation.tuning import SearchSettings
    from akas.execution.forward import Forward
    from akas.benchmarking.workload import load
    from tools.baselines.__main__ import model_definition
    from tools.baselines.speech import checked_file
    from tools.context_sweep import vulkan_device

    model_path, model = model_definition(ROOT / "benchmarks/models", "zonos3-mini")
    speech = model["runtime_options"]["llama"]["speech"]
    weight = checked_file(ROOT, model["weights"]["q8_0"])
    projector = checked_file(ROOT, speech["projector"])
    checkpoint = Zonos3MiniCheckpoint(weight["path"], projector["path"])
    config = checkpoint.config
    assert checkpoint.voice_rows().shape == (180, config.width)
    inputs = {
        "text_embedding": np.array([checkpoint.tokenizer.bos], dtype="int32"),
        "gdn_input": np.random.default_rng(17)
        .normal(0, 0.25, config.width)
        .astype("float32"),
        "audio_feedback": feedback_ids(config, [0, 1, 4095, 4096, 4097, 5, 6, 7, 8, 9]),
    }
    inputs["audio_head"] = inputs["gdn_input"]
    assert inputs["audio_feedback"].tolist() == [
        code + index * 4098
        for index, code in enumerate([0, 1, 4095, 4096, 4097, 5, 6, 7, 8, 9])
    ]
    metadata = dict(
        model=model["model"],
        runtime="akas",
        mode="tts",
        purpose="operation-qualification",
        provider="webgpu",
        protocol="zonos3-checkpoint-operation-probe-v1",
        weight_format="q8_0",
        checkpoint=weight["path"],
        checkpoint_sha256=weight["sha256"],
        checkpoint_source=weight["source"],
        projector=projector,
        model_definition_sha256=digest(model_path),
        checks=[],
    )
    recorder = Recorder(
        ROOT / "benchmarks",
        metadata,
        kind="qualification",
        change="Qualify ZONOS3 checkpoint operations on the native AKAS Vulkan path",
    )
    recorder.artifact(model_path, "model.json")
    report = dict(schema="akas.benchmark.v1", metadata=metadata, results=[])
    status = "failed"
    try:
        binary = ROOT / speech["binary"]
        executable = binary.with_name("llama-tokenize" + binary.suffix)
        metadata["tokenizer_binary_sha256"] = digest(executable)
        metadata["prompt_ids"] = {}
        for item in load(speech["workload"])["utterances"]:
            command = [
                str(executable),
                "-m",
                weight["path"],
                "--device",
                "none",
                "--ids",
                "--no-parse-special",
                "-p",
                item["text"],
            ]
            ids = json.loads(subprocess.check_output(command, text=True, timeout=20))
            prompt = checkpoint.prompt_ids(item["text"])
            assert prompt[3:] == ids
            metadata["prompt_ids"][item["id"]] = prompt

        with vulkan_device() as device:
            metadata["device"] = dict(
                device.info, name=device.info["adapter"]["device"]
            )
            metadata["kernels"] = {}
            for phase, value in inputs.items():
                graph = compose(checkpoint, phase=phase, provider="webgpu")
                directory = tmp_path / phase
                manifest = produce(
                    graph,
                    directory,
                    provider="webgpu",
                    device=device,
                    search_settings=SearchSettings(budget=2, samples=3, repeats=3),
                )
                recorder.artifact(directory / "forward.json", f"{phase}/forward.json")
                metadata["kernels"][phase] = manifest["kernels"]
                weight_name = next(
                    n for n, b in graph.buffers.items() if b.role == "weight"
                )
                source = checkpoint.source(weight_name)
                expected = (
                    np.concatenate([source.row(weight_name, int(i)) for i in value])
                    if phase in ("text_embedding", "audio_feedback")
                    else source.array(weight_name, dtype=np.float64)
                    @ value.astype(np.float64)
                )
                with ExitStack() as resources:
                    supplied = checkpoint.upload(device, (weight_name,))
                    resources.callback(supplied[weight_name].release)
                    output = next(
                        b for b in graph.buffers.values() if b.role == "output"
                    )
                    input_name = next(
                        n for n, b in graph.buffers.items() if b.role == "input"
                    )
                    supplied[input_name] = device.from_numpy(value)
                    resources.callback(supplied[input_name].release)
                    supplied[output.name] = device.empty(output.shape, output.dtype)
                    resources.callback(supplied[output.name].release)
                    with Forward(directory, device, supplied, graphs=True) as forward:
                        forward.run()
                        device.synchronize()
                        actual = supplied[output.name].to_numpy()

                bitwise = np.array_equal(actual, expected.astype(np.float32))
                error = float(np.max(np.abs(actual - expected)))
                metadata["checks"].append(
                    dict(
                        output=phase,
                        elements=actual.size,
                        max_abs_error=error,
                        bitwise=bitwise,
                    )
                )
                if phase in ("text_embedding", "audio_feedback"):
                    np.testing.assert_array_equal(actual, expected)
                else:
                    np.testing.assert_allclose(actual, expected, rtol=3e-5, atol=4e-5)
                if phase == "audio_feedback":
                    np.testing.assert_array_equal(
                        feedback_embedding(config, actual)[0],
                        expected.reshape(10, config.width).sum(axis=0),
                    )
                if phase == "audio_head":
                    np.testing.assert_allclose(
                        codebook_logits(config, actual).reshape(-1),
                        15 * np.tanh(expected / 15),
                        rtol=3e-5,
                        atol=4e-5,
                    )
        status = "passed"
    except Exception as error:
        metadata["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        record = recorder.update(report, final=True, status=status)
        print(
            f"ZONOS3 operation evidence {record['id']} {record['status']}", flush=True
        )
    assert record["status"] == "passed"
