"""Register scale broadcast retains the shared expert arithmetic."""
import os
import pytest

@pytest.mark.skipif(os.getenv('AKAS_LFM_FP8_CUDA')!='1',reason='CUDA expert scale qualification')
@pytest.mark.parametrize('warp',['full_row','full_column'])
@pytest.mark.parametrize('kind,layout,packed,stages',[
 ('expert_partial','wide',False,1),('expert_partial','wide',True,2),
 ('fp8_expert_swiglu','wide',True,2),('fp8_expert_swiglu','separate',True,2),
])
def test_warp_partition_projection_matches_independent_equations(tmp_path,kind,layout,packed,stages,warp):
 from test_lfm_moe_native import test_native_operations_match_independent_references as check
 check(tmp_path,kind,dict(r=65,rows=65,k=384,o=256,experts=7,top=3,partitions=1,
   block_m=64,max_block_m=128,compact=True,tile_map=True,columns=128,
   threads=256,stages=stages,pair_layout=layout,activation_vector=16,
   packed_input=packed,packed_output=packed and kind=='fp8_expert_swiglu',
   routed_input=kind=='expert_partial',product_dtype='bfloat16',activation_dtype='bfloat16',
   warp_policy=warp,guard_metadata=True))
