"""Cooperatively reduce query channels while reusing grouped KV tiles."""

from akas.kernels.kernel import Tensor, kernel, output


def channel_partial(spec, schedule):
    import tilelang.language as T
    from tensor.compiler.webgpu.schedules.registers import registers, vector
    from akas.ops.attention.kernel import cache_reader

    p = {**spec.parameters, **schedule}
    r, h, kh, d, cap = (p[n] for n in ("r", "h", "kh", "d", "capacity"))
    group, splits, bk = h // kh, p.get("splits", 16), p.get("key_rows", 16)
    if d != 64 or h % kh or group not in (1, 2, 4, 8) or bk not in (16, 32):
        raise ValueError("unsupported channel-cooperative attention")
    if p["kv_dtype"] != "float16" or not p.get("unit_scales", False):
        raise ValueError("channel-cooperative attention requires unit-scale half KV")
    lanes = 64 // bk
    terms = d // lanes
    storage, read = cache_reader(p)

    @T.macro
    def exchange(value, stride):
        return T.call_extern("float32", "subgroupShuffleXor", value, T.uint32(stride))

    @T.macro
    def load_query(value: T.Ref, q, slot, head, channel):
        value = q[slot, head * d + channel]

    def load_queries(queries, q, slot, head, channel_group):
        for j in range(terms):
            load_query(queries[j,][0], q, slot, head, channel_group * terms + j)

    @T.macro
    def dot_term(score: T.Ref, left, right):
        score += T.call_extern("float32", "dot", left, right)

    def dot_keys(score, queries, keys, key, channel_group):
        for j in range(terms // 4):
            left = vector([queries[j * 4 + k,][0] for k in range(4)])
            right = vector([T.cast(keys[channel_group * terms + j * 4 + k, key], "float32")
                            for k in range(4)])
            dot_term(score, left, right)

    def dot_values(acc, probabilities, values, head, channel):
        for j in range(bk // 4):
            left = vector([probabilities[head, j * 4 + k] for k in range(4)])
            right = vector([T.cast(values[j * 4 + k, channel], "float32") for k in range(4)])
            dot_term(acc, left, right)

    @kernel
    def compute(
        q: Tensor((r, h * d), "float32"),
        kc: Tensor(storage.values.shape, storage.values.dtype),
        vc: Tensor(storage.values.shape, storage.values.dtype),
        ks: Tensor(storage.metadata[0].shape, "float32"),
        vs: Tensor(storage.metadata[0].shape, "float32"),
        positions: Tensor(r, "int32"), enabled: Tensor(r, "int32"),
    ) -> Tensor(r * h * splits * 66, "float32"):
        out = output(r * h * splits * 66, "float32", position=5)
        with T.Kernel(kh, r, splits, threads=group * 64) as (kv_head, slot, split):
            tx = T.get_thread_binding()
            head, local = tx // 64, tx % 64
            key, channel_group = local // lanes, local % lanes
            length = T.if_then_else(enabled[slot] != 0, T.min(positions[slot] + 1, cap), 0)
            span = T.ceildiv(length, splits)
            begin, end = split * span, T.min((split + 1) * span, length)
            keys = T.alloc_shared((d, bk + 1), "float16")
            values = T.alloc_shared((bk, d), "float16")
            probabilities = T.alloc_shared((group, bk), "float32")
            queries = registers((terms,))
            load_queries(queries, q, slot, kv_head * group + head, channel_group)
            maximum, normalizer, acc = T.alloc_var("float32"), T.alloc_var("float32"), T.alloc_var("float32")
            maximum, normalizer, acc = -T.infinity("float32"), 0, 0
            for tile in T.serial(T.ceildiv(T.max(end - begin, 0), bk)):
                base = begin + tile * bk
                for token, channel in T.Parallel(bk, d):
                    keys[channel, token] = T.if_then_else(base + token < end,
                        read(kc, ks, slot, kv_head, base + token, channel), 0)
                    values[token, channel] = T.if_then_else(base + token < end,
                        read(vc, vs, slot, kv_head, base + token, channel), 0)
                T.sync_threads()
                score = T.alloc_var("float32")
                score = 0
                dot_keys(score, queries, keys, key, channel_group)
                for step in T.unroll(lanes.bit_length() - 1):
                    score += exchange(score, lanes >> (step + 1))
                if channel_group == 0:
                    probabilities[head, key] = T.if_then_else(base + key < end,
                        score * 0.125, -T.infinity("float32"))
                T.sync_threads()
                probability = T.alloc_var("float32")
                probability = probabilities[head, local % bk]
                peak = T.alloc_var("float32")
                peak = probability
                for step in T.unroll(bk.bit_length() - 1):
                    peak = T.max(peak, exchange(peak, bk >> (step + 1)))
                next_max = T.max(maximum, peak)
                correction = T.if_then_else(maximum == -T.infinity("float32"),
                                             0, T.exp(maximum - next_max))
                probability = T.if_then_else(base + local % bk < end,
                                              T.exp(probability - next_max), 0)
                norm = T.alloc_var("float32")
                norm = probability
                for step in T.unroll(bk.bit_length() - 1):
                    norm += exchange(norm, bk >> (step + 1))
                normalizer = normalizer * correction + norm
                maximum = next_max
                if local < bk:
                    probabilities[head, local] = probability
                acc *= correction
                T.sync_threads()
                dot_values(acc, probabilities, values, head, local)
                T.sync_threads()
            offset = ((slot * h + kv_head * group + head) * splits + split) * 66
            out[offset + local] = acc
            if local == 0:
                out[offset + 64], out[offset + 65] = maximum, normalizer
        return out

    return compute
