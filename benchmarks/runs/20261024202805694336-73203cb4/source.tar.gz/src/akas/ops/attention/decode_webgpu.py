"""Register-tiled decode attention for native floating caches."""

from akas.kernels.kernel import Tensor, kernel, output


def blocked_partial(spec, schedule):
    """Batch independent key dots before updating online softmax state."""
    import tilelang.language as T
    from tensor.compiler.webgpu.schedules.registers import registers
    from akas.ops.attention.kernel import cache_reader

    p = {**spec.parameters, **schedule}
    r, h, kh, d, cap = (p[n] for n in ("r", "h", "kh", "d", "capacity"))
    splits, unroll = p.get("splits", 16), p.get("key_unroll", 4)
    if d != 64 or h % kh or unroll not in (2, 4, 8):
        raise ValueError("unsupported register-tiled attention")
    storage, read = cache_reader(p)

    @T.macro
    def exchange(value, offset):
        return T.call_extern("float32", "subgroupShuffleXor", value, T.uint32(offset))

    @T.macro
    def score_key(score: T.Ref, q0, q1, kc, ks, slot, head, token, lane, end):
        score = T.if_then_else(
            token < end,
            q0 * read(kc, ks, slot, head, token, lane)
            + q1 * read(kc, ks, slot, head, token, lane + 32), 0)
        for step in T.unroll(5):
            score += exchange(score, 16 >> step)
        score = T.if_then_else(token < end, score * 0.125, -T.infinity("float32"))

    def score_keys(scores, q0, q1, kc, ks, slot, head, base, lane, end):
        for j in range(unroll):
            score_key(scores[j,][0], q0, q1, kc, ks, slot, head,
                      base + j * 4, lane, end)

    @T.macro
    def max_key(peak: T.Ref, score):
        peak = T.max(peak, score)

    def maximum_key(peak, scores):
        for j in range(unroll):
            max_key(peak, scores[j,][0])

    @T.macro
    def accumulate(a0: T.Ref, a1: T.Ref, norm: T.Ref, score, peak,
                   vc, vs, slot, head, token, lane, end):
        probability = T.if_then_else(token < end, T.exp(score - peak), 0)
        a0 += probability * T.if_then_else(
            token < end, read(vc, vs, slot, head, token, lane), 0)
        a1 += probability * T.if_then_else(
            token < end, read(vc, vs, slot, head, token, lane + 32), 0)
        norm += probability

    def accumulate_keys(a0, a1, norm, scores, peak, vc, vs, slot, head, base, lane, end):
        for j in range(unroll):
            accumulate(a0, a1, norm, scores[j,][0], peak, vc, vs, slot,
                       head, base + j * 4, lane, end)

    @kernel
    def compute(
        q: Tensor((r, h * d), "float32"),
        kc: Tensor(storage.values.shape, storage.values.dtype),
        vc: Tensor(storage.values.shape, storage.values.dtype),
        ks: Tensor(storage.metadata[0].shape, "float32"),
        vs: Tensor(storage.metadata[0].shape, "float32"),
        positions: Tensor(r, "int32"), enabled: Tensor(r, "int32"),
    ) -> Tensor(r * h * splits * 66, "float32"):
        out = output(r * h * splits * 66, "float32", position=5)
        with T.Kernel(h * r, splits, threads=128) as (index, split):
            head, slot = index % h, index // h
            tx = T.get_thread_binding()
            lane, warp = tx % 32, tx // 32
            length = T.if_then_else(enabled[slot] != 0, T.min(positions[slot] + 1, cap), 0)
            span = T.ceildiv(length, splits)
            begin, end = split * span, T.min((split + 1) * span, length)
            maxima = T.alloc_shared((4,), "float32")
            sums = T.alloc_shared((4,), "float32")
            values = T.alloc_shared((4, 64), "float32")
            maximum, normalizer = T.alloc_var("float32"), T.alloc_var("float32")
            a0, a1 = T.alloc_var("float32"), T.alloc_var("float32")
            maximum, normalizer, a0, a1 = -T.infinity("float32"), 0, 0, 0
            q0, q1 = q[slot, head * d + lane], q[slot, head * d + lane + 32]
            scores = registers((unroll,))
            for tile in T.serial(T.ceildiv(T.max(end - begin, 0), 4 * unroll)):
                base = begin + tile * 4 * unroll + warp
                score_keys(scores, q0, q1, kc, ks, slot, head // (h // kh), base, lane, end)
                peak = T.alloc_var("float32")
                peak = maximum
                maximum_key(peak, scores)
                correction = T.if_then_else(maximum == -T.infinity("float32"),
                                             0, T.exp(maximum - peak))
                normalizer, a0, a1 = normalizer * correction, a0 * correction, a1 * correction
                accumulate_keys(a0, a1, normalizer, scores, peak, vc, vs, slot,
                                head // (h // kh), base, lane, end)
                maximum = peak
            values[warp, lane], values[warp, lane + 32] = a0, a1
            if lane == 0:
                maxima[warp], sums[warp] = maximum, normalizer
            T.sync_threads()
            if warp == 0:
                merged = T.max(T.max(maxima[0], maxima[1]), T.max(maxima[2], maxima[3]))
                norm, result0, result1 = T.alloc_var("float32"), T.alloc_var("float32"), T.alloc_var("float32")
                norm, result0, result1 = 0, 0, 0
                for other in T.unroll(4):
                    factor = T.if_then_else(end > begin, T.exp(maxima[other] - merged), 0)
                    norm += sums[other] * factor
                    result0 += values[other, lane] * factor
                    result1 += values[other, lane + 32] * factor
                offset = (index * splits + split) * 66
                out[offset + lane], out[offset + lane + 32] = result0, result1
                if lane == 0:
                    out[offset + 64], out[offset + 65] = merged, norm
        return out

    return compute
