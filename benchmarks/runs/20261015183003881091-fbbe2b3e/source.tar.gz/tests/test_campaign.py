"""Matrix fairness, budgets, precision requirements and retained baseline rows."""

from dataclasses import replace
import json
from pathlib import Path

import pytest

from akas.benchmarking.history import write
from akas.optimization.context import Context
from akas.optimization.planning import recipes
from tools.baselines import common
from tools import campaign


def test_required_mode_and_cache_are_context_not_schedule_options():
    context = Context(
        "weights",
        "model:Model",
        dict(batches=[1], prefix_tokens=[32], output_tokens=128),
        mode="mtp",
        kv_dtype="fp8",
    )
    assert context.metadata()["kv_dtype"] == "fp8"
    with pytest.raises(ValueError):
        replace(context, mode="draft")
    probe = dict(
        status="ok",
        provider="cuda",
        device=dict(arch="sm_89"),
        chunks=[32],
        policies=[{}],
        model_options={},
        option_variants=[],
        windows=[2, 4],
        deferred_windows=[],
        head="family:Head",
    )
    plans = recipes(context.metadata(), [probe])
    assert plans[0]["window"] is None  # Independent AR output reference.
    assert all(p["window"] for p in plans[1:])


def test_qwen_diagnostics_compare_last_active_tokens_across_chunk_sizes():
    from types import SimpleNamespace
    import numpy as np
    from akas.optimization.evaluation import diagnostic_values

    frame = SimpleNamespace(
        rows=2,
        chunk=4,
        lengths=np.array([4, 2]),
        feature=lambda _: SimpleNamespace(shape=(8, 3)),
    )
    prefill = np.arange(24).reshape(2, 12)
    observed = diagnostic_values(prefill, frame, "hidden")
    np.testing.assert_array_equal(observed, [[9, 10, 11], [15, 16, 17]])
    frame.chunk = 1
    frame.lengths[:] = 1
    frame.feature = lambda _: SimpleNamespace(shape=(2, 3))
    decode = diagnostic_values(observed, frame, "hidden")
    assert np.stack([observed, decode, decode]).shape == (3, 2, 3)


def test_partial_baseline_survives_later_oom_and_prompts_match_optimizer(
    tmp_path, monkeypatch
):
    from akas.optimization.evaluation import prompts

    assert common.synthetic_prompts(400, 4, 32) == prompts(400, 4, 32)
    monkeypatch.setattr(common, "_output", tmp_path / "result.json")
    config = dict(shapes=[[1, 32], [4, 32]], output_tokens=2, warmup=0, repeats=2)
    report = dict(cases=[])

    def invoke(batch, prefix):
        if batch == 4:
            raise MemoryError("GPU capacity")
        return [[1, 2]], {}

    with pytest.raises(MemoryError):
        common.measurements(config, invoke, report)
    stored = json.loads((tmp_path / "result.json").read_text())
    assert [r["status"] for r in stored["cases"]] == ["passed", "failed"]
    assert len(stored["cases"][0]["samples"]) == 2


def test_matrix_resumes_without_repeating_completed_entries(tmp_path, monkeypatch):
    root = Path(__file__).resolve().parents[1]
    spec = tmp_path / "spec.json"
    write(
        spec,
        dict(
            models=["lfm2.5-230m"],
            formats=["bf16"],
            backends=["cuda", "webgpu"],
            caches=["default"],
            workload="standard-v1",
        ),
    )
    calls = []

    def optimize(context, out, **kwargs):
        calls.append((context.backend, kwargs["budget"]))
        return dict(status="complete", deployment=str(out / "deployment.json"))

    monkeypatch.setattr(campaign, "optimize", optimize)
    state = campaign.run(
        spec,
        tmp_path / "out",
        budget=60,
        slice_seconds=10,
        history=tmp_path / "history",
    )
    assert state["status"] == "complete"
    assert calls == [("cuda", 10), ("webgpu", 10)]
    campaign.run(
        spec,
        tmp_path / "out",
        budget=60,
        slice_seconds=10,
        history=tmp_path / "history",
    )
    assert len(calls) == 2
    with pytest.raises(ValueError, match="budget changed"):
        campaign.run(
            spec,
            tmp_path / "out",
            budget=61,
            slice_seconds=10,
            history=tmp_path / "history",
        )


def test_mtp_cannot_establish_its_own_ar_reference(tmp_path, monkeypatch):
    from akas.optimization import supervisor
    import akas.cli

    calls = []
    monkeypatch.setattr(akas.cli, "checkpoint_digest", lambda _: "weights")
    monkeypatch.setattr(supervisor, "software", lambda: {})
    probe = dict(
        status="ok",
        provider="cuda",
        device=dict(name="test", arch="sm_89"),
        chunks=[1],
        policies=[{}],
        model_options={},
        windows=[2],
        head="family:Head",
    )

    def execute(job, directory, **kwargs):
        if job["action"] == "probe":
            return probe
        calls.append(job["recipe"]["window"])
        return dict(status="failed", error="AR model reference failed")

    monkeypatch.setattr(supervisor, "execute", execute)
    context = Context(
        "weights",
        "family:Model",
        dict(batches=[1], prefix_tokens=[32], output_tokens=128),
        backend="cuda",
        mode="mtp",
    )
    result = supervisor.optimize(
        context, tmp_path / "out", budget=30, history=tmp_path / "history"
    )
    assert calls == [None]
    assert result["status"] == "failed" and not result["deployment"]
