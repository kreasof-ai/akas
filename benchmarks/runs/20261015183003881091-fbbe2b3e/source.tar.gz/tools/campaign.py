"""Run a declared benchmark matrix serially, with a cumulative time ceiling."""

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import sys
import time

from akas.benchmarking.history import digest, source_identity, utc, write
from akas.optimization.context import Context, discover, duration, identity, workload
from akas.optimization.supervisor import lock, optimize


def entries(spec, root):
    result = []
    for name in spec["models"]:
        model = json.loads((root / "benchmarks/models" / (name + ".json")).read_text())
        for precision in spec["formats"]:
            path = (root / model["weights"][precision]["path"]).resolve()
            for backend in spec["backends"]:
                for cache in spec["caches"]:
                    for mode in model["modes"]:
                        context = Context(
                            str(path),
                            discover(path),
                            workload(spec["workload"]),
                            backend=backend,
                            kv_dtype=None if cache == "default" else cache,
                            mode=mode,
                        )
                        key = "-".join((name, precision, backend, cache, mode))
                        result.append(dict(id=key, context=asdict(context)))
    return result


def run(specification, out, *, budget, slice_seconds, history):
    root = Path(__file__).resolve().parents[1]
    spec = json.loads(Path(specification).read_text())
    out = Path(out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    fingerprint = identity(dict(spec=spec, source=source_identity(root)["tree_sha256"]))
    with lock(out / ".lock"):
        path = out / "campaign.json"
        if path.exists():
            state = json.loads(path.read_text())
            if state["identity"] != fingerprint or state["budget_seconds"] != budget:
                raise ValueError(
                    "campaign source, specification or total budget changed; use a new output directory"
                )
        else:
            state = dict(
                schema="akas.matrix-campaign.v1",
                identity=fingerprint,
                specification=spec,
                source=source_identity(root),
                created_at=utc(),
                budget_seconds=budget,
                spent_seconds=0,
                entries=entries(spec, root),
            )
        started = time.monotonic()
        previous_spent = state["spent_seconds"]

        def save():
            state.update(
                spent_seconds=previous_spent + time.monotonic() - started,
                updated_at=utc(),
            )
            write(path, state)

        state["status"] = "running"
        save()
        try:
            while time.monotonic() - started + previous_spent < budget:
                if (
                    source_identity(root)["tree_sha256"]
                    != state["source"]["tree_sha256"]
                ):
                    state["status"] = "invalidated"
                    raise ValueError("campaign source changed during execution")
                pending = [
                    e
                    for e in state["entries"]
                    if e.get("status") not in ("complete", "unsupported", "failed")
                ]
                if not pending:
                    state["status"] = "complete"
                    break
                # Give every checkpoint/backend/cache/mode a first pass before
                # deepening any one deployment. The inner optimizer resumes.
                entry = min(pending, key=lambda e: e.get("spent_seconds", 0))
                remaining = budget - (time.monotonic() - started + previous_spent)
                allowance = min(slice_seconds, remaining)
                print(entry["id"], f"allowance={allowance:.1f}s", flush=True)
                tick = time.monotonic()
                try:
                    result = optimize(
                        Context(**entry["context"]),
                        out / entry["id"],
                        budget=allowance,
                        history=history,
                    )
                    entry.update(
                        status=result["status"],
                        deployment=result.get("deployment"),
                        winner=result.get("winner"),
                    )
                except KeyboardInterrupt:
                    raise
                except Exception as error:
                    entry.update(
                        status="failed", error=f"{type(error).__name__}: {error}"
                    )
                entry["spent_seconds"] = (
                    entry.get("spent_seconds", 0) + time.monotonic() - tick
                )
                entry["updated_at"] = utc()
                save()
            else:
                state["status"] = "budget_exhausted"
        except KeyboardInterrupt:
            state["status"] = "interrupted"
            raise
        finally:
            save()
        return state


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--spec", type=Path, default=Path("benchmarks/campaigns/standard-v1.json")
    )
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--budget",
        required=True,
        help="cumulative allowance, e.g. 4d; downtime is excluded",
    )
    parser.add_argument(
        "--slice",
        default="30m",
        help="maximum grant per configuration before moving to the next",
    )
    parser.add_argument("--history", type=Path, default=Path("benchmarks"))
    parser.add_argument(
        "--list",
        action="store_true",
        help="show the requested matrix without running GPU work",
    )
    args = parser.parse_args()
    if args.list:
        print(
            json.dumps(entries(json.loads(args.spec.read_text()), Path.cwd()), indent=2)
        )
        return
    state = run(
        args.spec,
        args.out,
        budget=duration(args.budget),
        slice_seconds=duration(args.slice),
        history=args.history,
    )
    print(
        json.dumps(
            dict(
                status=state["status"],
                spent_seconds=state["spent_seconds"],
                configurations=len(state["entries"]),
            ),
            indent=2,
        )
    )
    if any(e.get("status") == "failed" for e in state["entries"]):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
