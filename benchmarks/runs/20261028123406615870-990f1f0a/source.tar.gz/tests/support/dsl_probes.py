"""Small producer-only numerical probes for the package's DSL rounding macros."""


def half_conversion_kernel(n, unpack=False):
    import tilelang.language as T
    from akas.quantization._shared.rounding import half_bits
    from akas.quantization._shared.rounding import round_half

    convert = half_bits() if unpack else round_half()

    @T.prim_func
    def kernel(
        x: T.Tensor((n,), "uint32" if unpack else "float32"),
        out: T.Tensor((n,), "float32"),
    ):
        with T.Kernel(T.ceildiv(n, 128), threads=128) as block:
            for lane in T.Parallel(128):
                i = block * 128 + lane
                if i < n:
                    out[i] = convert(x[i])

    return kernel


def kernel_with_subgroup_size(kind, parameters, size):
    """Exercise the actual small-subgroup branch, without editing Python source."""
    import tvm
    from akas.kernels.definition import define

    ir = tvm.tirx
    kernel = define(dict(kind=kind, parameters=parameters, contract="packed"),
                    capabilities={"provider": "webgpu"})

    def subgroup_call(node):
        return (
            isinstance(node, ir.Call)
            and getattr(node.op, "name", None) == "tirx.call_extern"
            and node.args[0].value == "tensor_subgroup_size"
        )

    def replace(node):
        if kind == "attention":
            # Force the score-computation guard only. Workgroup-wide subgroup
            # sum/max reductions still need the actual physical subgroup size.
            if isinstance(node, ir.GE) and subgroup_call(node.a):
                return ir.const(False, "bool")
        elif subgroup_call(node):
            return ir.const(size, "uint32")

    body = ir.stmt_functor.ir_transform(
        kernel.body, None, replace, ["tirx.Call", "tirx.GE"]
    )
    return kernel.with_body(body)


def subgroup_source(kind, parameters, size):
    from support.migration import source as export_source

    return export_source(
        __name__,
        "kernel_with_subgroup_size",
        kind,
        parameters,
        size,
        dependencies=(
            "akas.kernels.definition",
            "akas.checkpoints.gguf",
            "akas.kernels.definition",
            "tensor.compiler.frontend.source",
            "tensor.compiler.webgpu.schedules.gemv",
            "tensor.compiler.webgpu.schedules.outer_product",
            "tensor.compiler.webgpu.schedules.packed_integer",
            "tensor.compiler.webgpu.schedules.packed_outer_product",
            "tensor.compiler.webgpu.schedules.partitioned",
            "tensor.compiler.webgpu.schedules.register_matmul",
            "tensor.compiler.webgpu.schedules.registers",
            "akas.ops.normalization.kernel",
        ),
    )
