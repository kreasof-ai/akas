"""passes components."""
