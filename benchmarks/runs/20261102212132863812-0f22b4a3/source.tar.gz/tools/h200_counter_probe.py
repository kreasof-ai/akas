"""Mark selected AKAS kernels with valid operands for Nsight Compute."""
import argparse
import ctypes
import json
from pathlib import Path


def run(args):
    import tensor
    from akas.models.lfm2 import LFM2MoE
    from akas.benchmarking.session import Session
    from tools.baselines.common import synthetic_prompts

    driver = ctypes.CDLL('libcuda.so.1')
    cases = [('prefill', 16, 2048, 'fp8_expert_swiglu'),
             ('prefill', 16, 2048, 'expert_partial'),
             ('prefill', 16, 2048, 'linear'),
             ('decode', 256, 1, 'fp8_expert_swiglu'),
             ('decode', 1, 1, 'expert_pair_partial')]
    observations = []
    with tensor.Device() as device, LFM2MoE('/data/checkpoint', args.program, device,
            graphs=False, checkpoint_options={'tokenizer': False}) as model:
        for phase, batch, chunk, kind in cases:
            with Session(model, batch=batch, chunk=2048) as session:
                session.reset()
                prompts = synthetic_prompts(model.config.vocab, batch, 2048)
                if chunk == 1:
                    tokens = session.prefill(prompts)
                    sequences = [[token] for token in tokens]
                else:
                    sequences = prompts
                frame = model.batch(batch, chunk)
                frame.prepare(session.slots, sequences, model.positions)
                index = next(i for i,c in enumerate(frame.forward.definition.calls) if c.kind == kind)
                for entry in frame.forward.plan[:index]:
                    device._launch(entry[0], entry[1])
                device.synchronize()
                executable, call, *_ = frame.forward.plan[index]
                metadata = frame.forward.definition.calls[index]
                observations.append(dict(phase=phase, batch=batch, chunk=chunk, kind=kind,
                                         key=metadata.key, parameters=metadata.parameters,
                                         launch=executable.manifest['launch']))
                args.out.write_text(json.dumps(observations, indent=2))
                print('COUNTER KERNEL', phase, batch, kind, flush=True)
                if driver.cuProfilerStart() != 0:
                    raise RuntimeError('CUDA profiler start failed')
                try:
                    device._launch(executable, call)
                    device.synchronize()
                finally:
                    if driver.cuProfilerStop() != 0:
                        raise RuntimeError('CUDA profiler stop failed')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--program', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    run(parser.parse_args())
