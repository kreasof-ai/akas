"""AKAS-only H200 optimization jobs; upstream baseline records are never rerun."""
from pathlib import Path
import modal
from tools.h200_modal import ROOT, aimage, volume

app = modal.App('akas-h200-akas-only')


@app.function(image=aimage, gpu='H200', volumes={'/data': volume}, timeout=1200,
              cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def prefill_pilot(program: str, groups: list[int] | None = None):
    import hashlib
    import json
    import time
    import numpy as np
    import tensor
    from akas.models.lfm2 import LFM2MoE
    from akas.benchmarking.session import Session
    from tools.baselines.common import synthetic_prompts

    directory = Path('/data/results')/f'prefill-batch-pilot-{time.time_ns()}'
    directory.mkdir(parents=True)
    bundle = Path('/data/programs')/program
    report = dict(protocol='native-synchronized-prefill-pilot-v1', program=program,
                  program_sha256=hashlib.sha256((bundle/'program.json').read_bytes()).hexdigest(),
                  prefix=2048, concurrency=256, warmup=1, repeats=2, cases=[])

    def save():
        (directory/'raw.json').write_text(json.dumps(report, indent=2))

    reference = None
    reference_tokens = None
    with tensor.Device() as device, LFM2MoE('/data/checkpoint', bundle, device,
            checkpoint_options={'tokenizer': False}) as model:
        report['device'] = device.info
        prompts = synthetic_prompts(model.config.vocab, 256, 2048)
        for group in groups or [4, 8, 16, 32]:
            model.prefill_group_size = group
            samples = []
            print('PREFILL GROUP', group, 'aggregate_tokens', group*2048, flush=True)
            for repeat in range(3):
                with Session(model, batch=256, chunk=2048) as session:
                    session.reset()
                    device.synchronize()
                    tick = time.perf_counter()
                    tokens = session.prefill(prompts)
                    device.synchronize()
                    seconds = time.perf_counter()-tick
                    logits = session.read_feature('logits')[-4:]
                    if reference is None:
                        reference, reference_tokens = logits.copy(), list(tokens)
                        np.savez_compressed(directory/'reference-logits.npz', logits=reference)
                    diff = logits-reference
                    nrms = float(np.sqrt(np.mean(diff**2))/(np.sqrt(np.mean(reference**2))+1e-20))
                    correlation = float(np.corrcoef(logits.reshape(-1), reference.reshape(-1))[0,1])
                    equal = sum(a == b for a,b in zip(tokens,reference_tokens))
                    qualified = bool(np.isfinite(logits).all() and nrms < .01 and correlation > .999)
                    row = dict(seconds=seconds, prefill_tokens_per_second=256*2048/seconds,
                               normalized_logit_rms=nrms, logit_correlation=correlation,
                               first_token_agreement=equal/256, qualified=qualified,
                               first_tokens=tokens, allocated_bytes=session.allocated_bytes)
                    if repeat:
                        samples.append(row)
                    print('PREFILL SAMPLE', group, repeat, round(row['prefill_tokens_per_second']),
                          'NRMS', nrms, 'agreement', equal, 'qualified', qualified, flush=True)
            report['cases'].append(dict(group=group, aggregate_tokens=group*2048, samples=samples,
                                        qualified=all(s['qualified'] for s in samples)))
            save()
            volume.commit()
    report['status'] = 'passed' if all(c['qualified'] for c in report['cases']) else 'failed'
    save()
    volume.commit()
    return dict(out=str(directory), status=report['status'])


@app.function(image=aimage, gpu='H200', volumes={'/data': volume}, timeout=1800,
              cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def epilogue_experiment(program: str, sweep: str):
    import argparse
    import time
    from tools.h200_kernel_sweep import benchmark

    pilot = prefill_pilot.local(program, [4, 32])
    out = Path('/data/results')/f'packed-epilogue-sweep-{time.time_ns()}.json'
    benchmark(argparse.Namespace(checkpoint=Path('/data/checkpoint'),
        program=Path('/data/programs')/program, sweep=Path('/data')/sweep, out=out))
    volume.commit()
    return dict(pilot=pilot, sweep=str(out))


@app.function(image=aimage, gpu='H200', volumes={'/data': volume}, timeout=1200,
              cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def kernel_tune(program: str, sweep: str):
    import argparse
    import time
    from tools.h200_kernel_sweep import benchmark
    out = Path('/data/results')/f'akas-kernel-tune-{time.time_ns()}.json'
    benchmark(argparse.Namespace(checkpoint=Path('/data/checkpoint'),
        program=Path('/data/programs')/program, sweep=Path('/data')/sweep, out=out))
    volume.commit()
    return dict(sweep=str(out))


@app.function(image=aimage, gpu='H200', volumes={'/data': volume}, timeout=600,
              cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def phase_compare(program: str):
    import json
    import time
    import hashlib
    import numpy as np
    import tensor
    from akas.models.lfm2 import LFM2MoE
    from akas.benchmarking.session import Session
    from tools.baselines.common import synthetic_prompts
    from tools.h200_native import elapsed

    out=Path('/data/results')/f'akas-phase-compare-{time.time_ns()}.json'
    report=dict(protocol='native-gpu-prefill-ar127-v1',reference='final-best',candidate=program,cases=[])
    references={}
    with tensor.Device() as device:
        for name in ['final-best',*program.split(',')]:
            path=Path('/data/programs')/name
            with LFM2MoE('/data/checkpoint',path,device,checkpoint_options={'tokenizer':False}) as model:
                for batch,group in ([(256,4)] if name=='final-best' else [(256,4),(256,16)]):
                    model.prefill_group_size=group
                    prompts=synthetic_prompts(model.config.vocab,batch,2048)
                    case=dict(program=name,batch=batch,group=group,program_sha256=hashlib.sha256((path/'program.json').read_bytes()).hexdigest(),samples=[])
                    report['cases'].append(case)
                    for repeat in range(3):
                        with Session(model,batch=batch,chunk=2048) as session:
                            session.reset()
                            first,prefill=elapsed(device,lambda:session.prefill(prompts))
                            logits=session.read_feature('logits').astype('float32')
                            # The last native prefill group owns this diagnostic buffer.
                            reference_key=(batch,group)
                            if name=='final-best':
                                references[(batch,4)]=(logits.copy(),list(first))
                            ref,tokens=references[(batch,4)]
                            checked=min(len(logits),len(ref))
                            actual,expected=logits[-checked:],ref[-checked:]
                            nrms=float(np.sqrt(np.mean((actual-expected)**2))/(np.sqrt(np.mean(expected**2))+1e-20))
                            agreement=sum(x==y for x,y in zip(first,tokens))/batch
                            valid=bool(np.isfinite(logits).all() and nrms<.01 and agreement>=.99)
                            if not valid:
                                case.update(status='failed',normalized_logit_rms=nrms,first_token_agreement=agreement)
                                out.write_text(json.dumps(report,indent=2));volume.commit()
                                raise RuntimeError('candidate model prefill qualification failed')
                            _,decode=elapsed(device,lambda:session.decode(127,read=False))
                            last=session.executor.last_frame.buffers[session.executor.last_frame.prediction].to_numpy()[:batch].astype(int).tolist()
                            row=dict(prefill_seconds=prefill,decode_seconds=decode,
                                prefill_tokens_per_second=batch*2048/prefill,decode_tokens_per_second=batch*127/decode,
                                normalized_logit_rms=nrms,checked_logit_rows=checked,
                                first_token_agreement=agreement,first_tokens=first,last_tokens=last)
                            if repeat:case['samples'].append(row)
                            print('PHASE COMPARE',name,batch,group,repeat,round(row['prefill_tokens_per_second']),round(row['decode_tokens_per_second']),'NRMS',nrms,'agreement',agreement,flush=True)
                        out.write_text(json.dumps(report,indent=2));volume.commit()
                    case['status']='passed'
    report['status']='passed';out.write_text(json.dumps(report,indent=2));volume.commit()
    return dict(out=str(out),status=report['status'])


@app.function(image=aimage, gpu='H200', volumes={'/data': volume}, timeout=600,
              cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def standard_candidate(program: str):
    from tools.h200_standard import standard_akas
    return standard_akas.local(program_name=program,prefill_group_size=16)


@app.function(image=aimage, gpu='H200', volumes={'/data': volume}, timeout=600,
              cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def counter_profile(program: str):
    import subprocess
    import time

    out = Path('/data/results')/f'ncu-akas-{time.time_ns()}'
    out.mkdir(parents=True)
    command = ['ncu', '--profile-from-start', 'off', '--replay-mode', 'kernel',
               '--clock-control', 'none',
               '--section', 'SpeedOfLight', '--section', 'MemoryWorkloadAnalysis',
               '--section', 'LaunchStats', '--section', 'Occupancy',
               '--export', str(out/'profile'), '--force-overwrite',
               'python', '-u', '-m', 'tools.h200_counter_probe',
               '--program', str(Path('/data/programs')/program), '--out', str(out/'kernels.json')]
    with (out/'profile.log').open('w') as log:
        process = subprocess.Popen(command, cwd='/workspace/akas', stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True)
        for line in process.stdout:
            print(line, end='', flush=True)
            log.write(line)
        code = process.wait()
    if (out/'profile.ncu-rep').exists():
        with (out/'profile.csv').open('w') as csv:
            subprocess.run(['ncu', '--import', str(out/'profile.ncu-rep'), '--csv'], stdout=csv)
    volume.commit()
    return dict(returncode=code, out=str(out))


@app.local_entrypoint()
def main(action: str = 'prefill-pilot', program: str = 'prefill-large-candidate',
         sweep: str = 'sweep-packed-epilogues'):
    import json
    import time
    if action not in ('prefill-pilot', 'epilogues', 'counters', 'tune', 'phases', 'standard'):
        raise ValueError('unsupported AKAS-only action')
    ledger_path = ROOT/'build/h200/cost-ledger.json'
    ledger = json.loads(ledger_path.read_text())
    rate = .001261 + 4*.0000131 + 64*.00000222
    bound = 1800 if action == 'epilogues' else 600 if action in ('counters','phases','standard') else 1200
    if sum(r['conservative_usd'] for r in ledger)+bound*rate > 28:
        raise RuntimeError('Insufficient remaining campaign budget')
    for candidate in program.split(','):
        names = {Path(e.path).name for e in volume.listdir('/programs/'+candidate)}
        if 'program.json' not in names:
            raise RuntimeError('Compiled program must be uploaded before GPU allocation')
    row = dict(action='akas-'+action, program=program, started_at=time.time(),
               conservative_usd=bound*rate, status='reserved')
    ledger.append(row)
    ledger_path.write_text(json.dumps(ledger, indent=2))
    tick = time.monotonic()
    try:
        result = (counter_profile.remote(program) if action == 'counters'
                  else standard_candidate.remote(program) if action == 'standard'
                  else phase_compare.remote(program) if action == 'phases'
                  else kernel_tune.remote(program, sweep) if action == 'tune'
                  else epilogue_experiment.remote(program, sweep) if action == 'epilogues'
                  else prefill_pilot.remote(program))
        row.update(status='completed', result=result)
        print(json.dumps(result), flush=True)
    finally:
        row['elapsed_seconds'] = time.monotonic()-tick
        if row['status']=='completed':
            row['conservative_usd']=(row['elapsed_seconds']+30)*rate
        ledger_path.write_text(json.dumps(ledger, indent=2))
