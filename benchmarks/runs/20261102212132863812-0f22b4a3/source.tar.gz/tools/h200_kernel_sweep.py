"""Offline compilation and real-operand GPU qualification of H200 schedules."""
import argparse,hashlib,json,itertools,time,traceback
from pathlib import Path

def graph_timing(device,callback,reset,*,samples=7):
    """Timestamp nodes inside a captured graph; exclude host enqueue gaps."""
    import ctypes as c,statistics
    from tensor.providers.cuda.graph import CudaGraph
    begin,end=c.c_void_p(),c.c_void_p()
    device.driver.lib.cuEventRecordWithFlags.argtypes=[c.c_void_p,c.c_void_p,c.c_uint]
    device.driver.lib.cuEventRecordWithFlags.restype=c.c_int
    device.driver.call('cuEventCreate',c.byref(begin),0)
    device.driver.call('cuEventCreate',c.byref(end),0)
    def submit():
        device.driver.call('cuEventRecordWithFlags',begin,device.stream,1)
        callback()
        device.driver.call('cuEventRecordWithFlags',end,device.stream,1)
    try:
        with CudaGraph(device,submit) as graph:
            result=[]
            for i in range(samples+3):
                reset();graph.launch()
                device.driver.call('cuEventSynchronize',end)
                ms=c.c_float();device.driver.call('cuEventElapsedTime',c.byref(ms),begin,end)
                if i>=3:result.append(ms.value/1000)
            return dict(gpu_seconds=result,median=statistics.median(result))
    finally:
        device.driver.call('cuEventDestroy',begin);device.driver.call('cuEventDestroy',end)


def candidates(kind,p,base):
    yield base
    r=p['r']
    if kind in ('expert_swiglu','fp8_expert_swiglu'):
        for m,t,st,layout in itertools.product((16,32,64,128),(128,256,512),(1,2,3),('wide','separate')):
            if m==128 and t<256 or m==16 and t==512: continue
            if r<=4 and m>32: continue
            if r>=2048 and m==16: continue
            if st==3 and (m,t) not in ((32,128),(64,256),(64,512)): continue
            if layout=='separate' and st!=2:continue
            cfg={**base,'block_m':m,'threads':t,'stages':st,'pair_layout':layout,'mma_dtype':'float8_e4m3fn'}
            if kind=='expert_swiglu':
                for n in (32,64,128):
                    if m//16*(n//8)<t//32:continue
                    yield {**cfg,'columns':n}
            else:yield cfg
    elif kind=='expert_partial':
        for m,n,t,st in itertools.product((16,32,64,128),(32,64,128),(128,256),(1,2,3)):
            if m//16*(n//8)<t//32 or m==128 and t==128:continue
            if r<=4 and m>32 or r>=2048 and m==16:continue
            if st==3 and (m,n,t)!=(64,128,256):continue
            yield {**base,'block_m':m,'columns':n,'threads':t,'stages':st,'mma_dtype':'float8_e4m3fn'}


def compile_one(job):
    from akas.kernels.definition import definition
    from akas.compilation.selection import selected_source
    from akas.compilation.emit import compile_kernel
    from akas.artifacts.schema import Kernel
    import subprocess,re,zipfile
    out=Path(job['out']);cfg=job['schedule'];spec=dict(kind=job['kind'],parameters=job['parameters'],contract='reference',phase=job['phase'])
    caps=dict(provider='cuda',target='sm_90a')
    try:
        impl,schedule=definition(spec,cfg,caps)
        source=selected_source(spec,schedule,caps,impl)
        if job.get("mapping"):
            from akas.compilation.state import mapped_source
            source=mapped_source(source,job["mapping"])
        record=compile_kernel(out,Kernel(job['id'],job['kind'],job['parameters'],source,schedule=cfg),target='sm_90a',source_directory='sources',artifact_directory='kernels')
        z=zipfile.ZipFile(out/record['path']);m=json.loads(z.read('manifest.json'))
        cubin=out/'kernels'/f"{job['id']}.cubin";cubin.write_bytes(z.read('kernel.cubin'))
        sass=subprocess.check_output(['nvdisasm','-c',str(cubin)],text=True)
        spills={k:len(re.findall(r'\b'+k+r'\b',sass)) for k in ('LDL','STL')}
        cubin.unlink()
        return {**job,'status':'compiled','artifact':record['path'],'launch':m['launch'],'spills':spills}
    except Exception as e:return {**job,'status':'failed','error':f'{type(e).__name__}: {e}'}


def compile_all(args):
    import concurrent.futures,multiprocessing
    program=json.loads((args.program/'program.json').read_text());jobs=[];groups=[]
    for phase in program['phases']:
        if phase['phase'] not in ('decode','prefill'):continue
        f=json.loads((args.program/phase['path']).read_text())
        for key,k in f['kernels'].items():
            if k['kind'] not in ('expert_swiglu','fp8_expert_swiglu','expert_partial'):continue
            gid=f"{phase['phase']}-b{phase['rows']}-{k['kind']}"
            group=dict(id=gid,phase=phase['phase'],batch=phase['rows'],chunk=phase['chunk'],key=key,kind=k['kind'],parameters=k['parameters'],baseline=k['schedule'])
            groups.append(group);seen=set()
            for cfg in candidates(k['kind'],k['parameters'],k['schedule']):
                ident=hashlib.sha256(json.dumps([k['kind'],k['parameters'],cfg],sort_keys=True).encode()).hexdigest()[:20]
                if ident in seen:continue
                seen.add(ident)
                jobs.append(dict(id=ident,group=gid,kind=k['kind'],parameters=k['parameters'],schedule=cfg,phase=phase['phase'],out=str(args.out)))
    args.out.mkdir(parents=True,exist_ok=True)
    manifest=dict(program_sha256=hashlib.sha256((args.program/'program.json').read_bytes()).hexdigest(),groups=groups,jobs=[],started_at=time.time())
    (args.out/'sweep.json').write_text(json.dumps(manifest,indent=2))
    print('COMPILE',len(jobs),'variants',len(groups),'groups',flush=True)
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.jobs,mp_context=multiprocessing.get_context('spawn')) as pool:
        futures=[pool.submit(compile_one,j) for j in jobs]
        for f in concurrent.futures.as_completed(futures):
            result=f.result();manifest['jobs'].append(result)
            (args.out/'sweep.json').write_text(json.dumps(manifest,indent=2))
            print('BUILT',len(manifest['jobs']),len(jobs),result['group'],result['status'],result.get('spills',{}),flush=True)
    manifest['completed_at']=time.time();(args.out/'sweep.json').write_text(json.dumps(manifest,indent=2))


def benchmark(args):
    import tensor,numpy as np,statistics
    from akas.models.lfm2 import LFM2MoE
    from akas.execution.plan import call_bindings,bind_named
    from tensor.compiler.tuning import measure_cuda
    from tools.baselines.common import synthetic_prompts
    from akas.quantization._shared.e4m3 import decode_storage
    sweep=json.loads((args.sweep/'sweep.json').read_text());report=dict(program_sha256=sweep['program_sha256'],groups=[])
    def save():args.out.write_text(json.dumps(report,indent=2))
    with tensor.Device() as device,LFM2MoE(args.checkpoint,args.program,device,checkpoint_options={'tokenizer':False}) as model:
        report['device']=device.info
        # Independent 128 MiB streaming copy conditions L2 outside each event interval.
        flush_kernel=device.load(args.sweep/'flush.tbin')
        src=device.from_numpy(np.arange(32*1024*1024,dtype='uint32'));dst=device.empty(src.shape,'uint32')
        flush=flush_kernel.bind(src,dst)
        for group in sweep['groups']:
            b,t=group['batch'],group['chunk'];slots=[model.admit() for _ in range(b)];state_backup=None
            try:
                prompts=synthetic_prompts(model.config.vocab,b,2048 if t==1 else t)
                tokens=model.prefill(slots,prompts,chunk=2048) if t==1 else None
                frame=model.batch(b,t);frame.prepare(slots,[[v] for v in tokens] if tokens else prompts,model.positions)
                index=next(i for i,c in enumerate(frame.forward.definition.calls) if c.key==group['key'])
                for entry in frame.forward.plan[:index]:device._launch(entry[0],entry[1])
                original,call,*_=frame.forward.plan[index]
                values=call_bindings(original,call)
                original_cb=lambda:device._launch(original,call)
                original_cb();device.synchronize()
                if group['kind']=='conv':
                    state_backup=device.from_numpy(values['state'].to_numpy(),dtype=values['state'].dtype)
                    original_cb();device.synchronize()
                def reset():
                    if state_backup is not None:values['state'].copy_from(state_backup)
                    flush.launch()
                outputs=['gate','up'] if group['kind']=='expert_pair_partial' else ['out','output_scales'] if group['kind']=='fp8_expert_swiglu' else ['out','scales'] if group['kind']=='quantize' else ['out']
                reference={name:values[name].to_numpy().copy() for name in outputs}
                active=None
                if group['parameters'].get('packed_output'):
                    counts=values['counts'].to_numpy();offsets=values['expert_offsets'].to_numpy()
                    active=np.concatenate([np.arange(int(o),int(o)+int(n)) for o,n in zip(offsets,counts)])
                def normalize(arrays):
                    if group['kind']=='quantize':
                        return arrays
                    if group['kind']=='expert_pair_partial':
                        return np.concatenate([arrays[name].astype('float32').reshape(-1) for name in outputs])
                    if 'output_scales' in arrays or group['kind']=='quantize':
                        a=arrays['out'];sc=arrays.get('output_scales',arrays.get('scales'))
                        if active is not None:a=a[active];sc=sc[active]
                        return decode_storage(a).astype('float32')*np.repeat(sc,128,axis=-1)
                    a=arrays['out']
                    return (a[active] if active is not None else a).astype('float32')
                expected=normalize(reference);base=graph_timing(device,original_cb,reset)
                row=dict(**group,baseline_seconds=statistics.median(base['gpu_seconds']),candidates=[])
                report['groups'].append(row);save()
                for j in [j for j in sweep['jobs'] if j['group']==group['id'] and j['status']=='compiled' and (j.get('allow_spills') or not any(j['spills'].values()))]:
                    try:
                        with device.load(args.sweep/j['artifact']) as k:
                            _,bound=bind_named(device,k,values);cb=bound.launch
                            reset();cb();device.synchronize();actual=normalize({name:values[name].to_numpy() for name in outputs})
                            if group['kind']=='quantize':
                                qual=all(np.array_equal(actual[name],expected[name]) for name in outputs)
                                nrms=0.0 if qual else float('inf')
                            else:
                                diff=actual-expected
                                nrms=float(np.sqrt(np.mean(diff**2))/(np.sqrt(np.mean(expected**2))+1e-10))
                                finite=bool(np.isfinite(actual).all());qual=finite and (bool(np.array_equal(actual,expected)) if group['kind']=='argmax' else nrms<.025)
                            if state_backup is not None:qual=qual and bool(np.array_equal(values['state'].to_numpy(),state_backup.to_numpy()))
                            result=dict(id=j['id'],schedule=j['schedule'],normalized_rms=nrms,correct=qual,compiler_options=j.get('compiler_options',{}))
                            if qual:
                                timing=graph_timing(device,cb,reset)
                                result.update(seconds=statistics.median(timing['gpu_seconds']),samples=timing['gpu_seconds'])
                            row['candidates'].append(result)
                    except Exception as e:row['candidates'].append(dict(id=j['id'],error=f'{type(e).__name__}: {e}'))
                    save()
                valid=[r for r in row['candidates'] if r.get('correct') and r.get('seconds')]
                row['winner']=min(valid,key=lambda r:r['seconds']) if valid else None
                print('WINNER',group['id'],row['baseline_seconds'],row['winner'],flush=True);save()
            finally:
                if state_backup is not None:state_backup.release()
                for s in slots:model.release(s)
        src.release();dst.release();flush_kernel.release()
    save()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['compile','benchmark']);p.add_argument('--program',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--checkpoint',type=Path,default=Path('/data/checkpoint'));p.add_argument('--sweep',type=Path);p.add_argument('--jobs',type=int,default=2)
    a=p.parse_args();compile_all(a) if a.action=='compile' else benchmark(a)
