"""LFM3 composition over shared operations and the common request executor."""

from akas.models.definition import Composition, Definition
from akas.models.lfm3.weights import LFM3Checkpoint, rotary_parameters


def compose(
    checkpoint,
    *,
    rows,
    chunk,
    max_requests,
    max_context,
    provider="cuda",
    phase=None,
    kv_dtype="float16",
    prefill_chunk=512,
    optimized_attention=True,
    weight_arena=True,
):
    from dataclasses import replace
    from akas.graph import Graph

    c = checkpoint.config
    if provider != "cuda" or kv_dtype != "float16":
        raise ValueError("LFM3 currently requires CUDA and float16 KV")
    if (
        phase not in (None, "decode", "prefill")
        or not 1 <= rows <= max_requests
        or not 1 <= chunk <= max_context <= c.max_context
        or chunk > prefill_chunk
    ):
        raise ValueError("invalid LFM3 request geometry or phase")
    g = Graph(contract="reference", phase="forward")
    b, w = rows * chunk, c.width
    weights = checkpoint.graph_weights(g, provider=provider)
    stride = min(1024, max_context)
    blocks = (max_context + stride - 1) // stride
    tables = {}
    for i, key in enumerate(rotary_parameters(c)):
        tables[key] = (
            g.buffer(f"rope.{i}.fine", (stride, key[1]), "float32", role="weight"),
            g.buffer(f"rope.{i}.coarse", (blocks, key[1]), "float32", role="weight"),
        )
    tokens = g.buffer("tokens", (rows,), "int32", role="input")
    pos = g.buffer("positions", (max_requests,), "int32", role="state")
    active = g.buffer("active", (rows,), "int32", role="input")
    mapping = g.buffer("mapping", (rows,), "int32", role="input")
    source, row_pos, row_active = tokens, pos, active
    if chunk > 1:
        source = g.buffer("prefill_tokens", (b,), "int32", role="input")
        row_pos = g.buffer("row_positions", (b,), "int32")
        row_active = g.buffer("row_active", (b,), "int32")
        g("chunk_controls", dict(r=rows, chunk=chunk), pos, active, row_pos, row_active)

    def scratch(name, width, count=b):
        return g.buffer(name, (count * width,), "float32")

    def project(name, x, weight, k, o, count=b):
        out = scratch(name, o, count)
        if weight in getattr(weights, "scales", {}):
            lhs = g.view(name + ".input_matrix", x, (count, k))
            matrix = g.view(name + ".output_matrix", out, (count, o))
            g(
                "quantized_linear",
                dict(
                    r=count,
                    k=k,
                    o=o,
                    weight_format="fp8",
                    weight_options={"scale_layout": "block"},
                ),
                lhs,
                weights[weight],
                weights.scales[weight],
                matrix,
            )
        else:
            for wb, start, n in weights.matrix(weight):
                g(
                    "linear",
                    dict(
                        r=count,
                        k=k,
                        o=n,
                        optimized=True,
                        short_packed=True,
                        tiled_packed=True,
                        vector_q8=True,
                        **weights.parameters(weight),
                    ),
                    x,
                    wb,
                    out,
                )
        return out

    def norm(name, x, weight, count=b, width=w):
        out = scratch(name, width, count)
        g("rms", dict(r=count, c=width, eps=c.epsilon), x, weights[weight], out)
        return out

    def add(name, x, y):
        out = scratch(name, w)
        g("add", dict(r=b, c=w), x, y, out)
        return out

    hidden = scratch("hidden", w)
    for wb, start, n in weights.matrix("token_embd.weight"):
        g(
            "embedding",
            dict(r=b, c=w, v=n, start=start, **weights.parameters("token_embd.weight")),
            source,
            wb,
            hidden,
        )
    resets = ["positions"]
    for i, kind in enumerate(c.layers):
        p = f"blk.{i}."
        normal = norm(p + "normalized", hidden, p + "attn_norm.weight")
        if kind == "conv":
            projection = project(
                p + "projection", normal, p + "shortconv.in_proj.weight", w, 3 * w
            )
            state = g.buffer(
                p + "conv_state", (max_requests, c.conv - 1, w), "float32", role="state"
            )
            resets.append(state.name)
            mixed = scratch(p + "mixed", w)
            g(
                "conv",
                dict(r=rows, c=w, length=c.conv, chunk=chunk),
                projection,
                weights[p + "shortconv.conv.weight"],
                state,
                mixed,
                active,
            )
            mixed = project(
                p + "operator_output", mixed, p + "shortconv.out_proj.weight", w, w
            )
        else:
            d, h, kh = c.head_dim, c.heads, c.kv_heads
            q = project(p + "q", normal, p + "attn_q.weight", w, h * d)
            k = project(p + "k", normal, p + "attn_k.weight", w, kh * d)
            v = project(p + "v_flat", normal, p + "attn_v.weight", w, kh * d)
            v = g.view(p + "v", v, (b, kh * d))
            q = norm(p + "qn", q, p + "attn_q_norm.weight", b * h, d)
            k = norm(p + "kn", k, p + "attn_k_norm.weight", b * kh, d)
            qr = g.buffer(p + "qr", (b, h * d), "float32")
            kr = g.buffer(p + "kr", (b, kh * d), "float32")
            for x, out, heads in ((q, qr, h), (k, kr, kh)):
                g(
                    "rotary_compact",
                    dict(
                        r=b,
                        h=heads,
                        d=d,
                        theta=c.theta[i],
                        rotary=c.rotary[i],
                        full_head_pairs=True,
                        capacity=max_context,
                        stride=stride,
                        blocks=blocks,
                    ),
                    x,
                    out,
                    row_pos,
                    *tables[c.theta[i], c.rotary[i]],
                )
            window = c.window if kind == "sliding_attention" else 0
            # Cache writes precede attention. Preserve every query's full window.
            capacity = (
                min(max_context, window + prefill_chunk) if window else max_context
            )
            shape = (max_requests, kh, capacity, d)
            kc, vc = [
                g.buffer(p + n, shape, "float16", role="state") for n in ("kc", "vc")
            ]
            ap = dict(
                r=b, h=h, kh=kh, d=d, capacity=capacity, chunk=chunk, window=window
            )
            g("window_cache", ap, kr, v, kc, vc, row_pos, row_active)
            splits = (4 if window else 32) if chunk == 1 else 1
            ap["splits"] = splits
            if optimized_attention and chunk > 1:
                ap.update(query_rows=64, key_rows=32, contiguous=not window)
            parts = scratch(p + "attention_parts", h * splits * (d + 2))
            attended = scratch(p + "attended", h * d)
            g(
                "window_grouped"
                if optimized_attention and chunk == 1
                else "window_attention",
                ap,
                qr,
                kc,
                vc,
                row_pos,
                row_active,
                parts,
            )
            g("window_merge", ap, parts, attended, row_active)
            gate = project(p + "attention_gate", normal, p + "attn_gate.weight", w, h)
            gated = scratch(p + "gated", h * d)
            g("head_gate", dict(r=b, h=h, d=d), attended, gate, gated)
            mixed = project(
                p + "operator_output", gated, p + "attn_output.weight", h * d, w
            )
        if c.sandwich:
            mixed = norm(p + "post_operator", mixed, p + "post_attention_norm.weight")
        hidden = add(p + "residual", hidden, mixed)
        normal = norm(p + "ffn_normalized", hidden, p + "ffn_norm.weight")
        gate = project(p + "gate", normal, p + "ffn_gate.weight", w, c.ff)
        up = project(p + "up", normal, p + "ffn_up.weight", w, c.ff)
        activated = scratch(p + "activated", c.ff)
        g("swiglu", dict(r=b, c=c.ff), gate, up, activated)
        mixed = project(p + "ffn_output", activated, p + "ffn_down.weight", c.ff, w)
        if c.sandwich:
            mixed = norm(p + "post_ffn", mixed, p + "post_ffw_norm.weight")
        hidden = add(p + "output", hidden, mixed)
    if chunk > 1:
        last = scratch("last_hidden", w, rows)
        g("chunk_last", dict(r=rows, c=w, chunk=chunk), hidden, last, active)
        hidden = last
    hidden = norm("normalized_output", hidden, "output_norm.weight", rows)
    head = "token_embd.weight" if c.tied else "output.weight"
    logits = project("logits", hidden, head, w, c.vocab, rows)
    g.buffers["logits"] = replace(logits, role="output")
    sampled = g.buffer("sampled", (rows,), "int32", role="output")
    g("argmax", dict(r=rows, c=c.vocab), logits, sampled, active)
    g("next_tokens", dict(r=rows), sampled, tokens)
    g("advance", dict(r=rows, **({"chunk": chunk} if chunk > 1 else {})), pos, active)
    g.bind_requests(
        inputs={"tokens": source.name, "mapping": mapping.name, "lengths": active.name},
        prediction="sampled",
        features={"logits": "logits"},
        reset=resets,
    )
    from akas.compilation.rewrites import optimize

    return Composition(optimize(g))


class LFM3(Definition):
    checkpoint_architectures = ("lfm3",)
    checkpoint_type = LFM3Checkpoint
    model_defaults = {"kv_dtype": "float16", "prefill_chunk": 512}
    optimization_chunks = (512, 1024, 2048, 256, 128, 32, 1)
