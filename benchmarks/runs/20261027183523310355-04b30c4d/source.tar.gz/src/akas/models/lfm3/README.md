# LFM3

`LFM3` loads the official LiquidAI/LFM3-1.7B BF16 safetensors,
LFM3-1.7B-FP8 safetensors, or LFM3 GGUF through one declaration:

```python
from akas.models.lfm3 import LFM3
from akas.compilation import compile_checkpoint

compile_checkpoint(
    LFM3, "build/checkpoints/lfm3-1.7b/q4_0.gguf", "build/lfm3/program",
    checkpoint_options={"tokenizer": False},
    geometries=[(1, 1), (1, 32), (1, 512)],
    max_requests=1, max_context=131072,
    model_options={"prefill_chunk": 512},
    provider="cuda", target="sm_89",
)
```

CUDA execution uses FP16 KV, FP32 residuals and normalization, and FP16
projection operands with FP32 accumulation. BF16 source matrices are imported
into FP16 execution. FP8 matrices remain E4M3 bytes with their original BF16
128×128 block scales; consuming projections decode tiles locally. Dynamic W8A8
activation quantization is not enabled. GGUF matrices retain their original
individual encodings, including the QAD Q4_0 file's Q6_K tied embedding/head.
There is no persistent floating copy of quantized matrices.

The architecture combines seven-tap gated short convolutions, Q/K RMSNorm,
headwise sigmoid attention gates, SwiGLU, and optional sandwich norms. Sliding
attention retains a bounded ring plus one prefill chunk; full attention retains
the requested context. Partial RoPE rotates pairs across the full head halves,
using the full head dimension in its frequency exponent. The GGUF frequency
factors and safetensors rotary configuration map to the same operation.
Compact fine/coarse rotary tables preserve long-position phases. Request reuse
resets positions and convolution histories; attention masks hide stale KV.

The tokenizer supports literal user text and the official single-user chat
format with the template's default thinking mode. Tool calls, packed documents,
media inputs and additional conversation-template options are outside this text
adapter. The published model context limit is 262,144 tokens.

## Single-user comparison

The pinned [model sources](../../../../benchmarks/models/lfm3-1.7b.json) include
all three formats. The [campaign](../../../../benchmarks/campaigns/lfm3-1.7b-single-user-v1.json)
benchmarks only QAD Q4_0 against llama.cpp CUDA, on identical checkpoint bytes
and deterministic prompt IDs. Prefix lengths are 32, 512, 2,048, 8,192, 16,384,
32,768, 65,536 and 130,944. Each request starts empty and generates 128 tokens:
prefill predicts token one, and decode commits the remaining 127 tokens.

```sh
export TENSOR_NVRTC_HOME="$PWD/build/nvrtc-12.9"
python -m tools.lfm3_benchmark compile --chunk 512 --out build/lfm3/compile.json
python -m tools.lfm3_benchmark akas --chunk 512 --out build/lfm3/akas.json
python -m tools.lfm3_benchmark llama --chunk 512 --out build/lfm3/llama.json
python -m tools.lfm3_benchmark report --runs AKAS_RUN LLAMA_RUN --out build/lfm3/report
```

Use a llama.cpp build with LFM3 support; the retained run pins its source and
binary digests. Defaults retain three repetitions after one warmup per shape.
Both phase rates and output agreement are reported. AKAS synchronized native
phases and llama-server eval phases have different timing boundaries; phase
rate comparisons do not establish identical kernel or complete-request timings.
Output capture restarts the request to restore all recurrent histories.

Independent model qualification covers BF16, FP8 and GGUF, causal convolution,
full-head partial rotary pairs, sliding-ring wrap, ragged lengths, reordered
requests and reuse. Run it with:

```sh
AKAS_LFM3_CUDA=1 python -m pytest tests/test_lfm3.py
```
