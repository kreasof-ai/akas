"""Assemble only independently qualified built-in search artifacts."""
import hashlib
import json
from pathlib import Path
import shutil


def assemble(source, destination, reports):
    from akas.artifacts.read import artifact_path, read_program
    from tensor.artifacts.format import read_artifact

    source, destination = Path(source), Path(destination)
    source_digest = hashlib.sha256((source / 'program.json').read_bytes()).hexdigest()
    if destination.exists():
        raise ValueError('destination must be a new program')
    selections = {}
    evidence = []
    for report_path in map(Path, reports):
        report = json.loads(report_path.read_text())
        if report['program_sha256'] != source_digest:
            raise ValueError('qualification belongs to another program')
        evidence.append(report)
        for case in report['cases']:
            if case['status'] != 'passed':
                continue
            # Exact original artifact identity permits reuse by prefill_state.
            identity = (case['source_artifact_sha256'], case['kind'],
                        json.dumps(case['parameters'], sort_keys=True))
            selected = case['qualification']['operations'][0]['selected']
            if not (0 < selected['score'] <= 1):
                raise ValueError('selected candidate regressed from its qualified baseline')
            previous = selections.get(identity)
            if previous is None or selected['score'] < previous[1]['score']:
                selections[identity] = (case, selected)

    shutil.copytree(source, destination)
    manifest = json.loads((destination / 'program.json').read_text())
    applied = []
    for phase in manifest['phases']:
        path = destination / phase['path']
        forward = json.loads(path.read_text())
        qualified = []
        for key, original in list(forward['kernels'].items()):
            identity = (original['sha256'], original['kind'],
                        json.dumps(original['parameters'], sort_keys=True))
            choice = selections.get(identity)
            if choice is None:
                continue
            case, selected = choice
            record = dict(case['kernel'])
            candidate = artifact_path(case['artifact_root'], record)
            incumbent = artifact_path(destination, original)
            old, _ = read_artifact(incumbent)
            new, _ = read_artifact(candidate)
            abi = lambda m: [(v['name'], v['dtype'], v['shape']) for v in m['arguments']]
            if abi(old) != abi(new):
                raise ValueError(f'qualified kernel changes ABI: {key}')
            if record['kind'] != original['kind'] or record['parameters'] != original['parameters']:
                raise ValueError('qualified kernel changes operation semantics')
            target = destination / 'qualified-kernels' / (record['sha256'] + '.tbin')
            target.parent.mkdir(exist_ok=True)
            shutil.copyfile(candidate, target)
            generated = candidate.with_suffix('.py')
            if generated.exists():
                shutil.copyfile(generated, target.with_suffix('.py'))
            record['path'] = target.relative_to(destination).as_posix()
            forward['kernels'][key] = record
            qualified.append(key)
            applied.append(dict(phase=phase['phase'], rows=phase['rows'], chunk=phase['chunk'],
                                key=key, kind=record['kind'], source_sha256=original['sha256'],
                                artifact_sha256=record['sha256'], score=selected['score']))
        forward['builtin_qualification'] = dict(qualified_keys=qualified,
            total_operations=len(forward['kernels']),
            status='passed' if len(qualified) == len(forward['kernels']) else 'partial')
        path.write_text(json.dumps(forward, indent=2))
        phase['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    manifest['builtin_qualification'] = dict(source_program_sha256=source_digest,
        scope='Exact qualified operation artifacts; full-model qualification is separate',
        phases=[dict(phase=p['phase'], rows=p['rows'], chunk=p['chunk'],
            **json.loads((destination / p['path']).read_text())['builtin_qualification'])
            for p in manifest['phases']])
    (destination / 'program.json').write_text(json.dumps(manifest, indent=2))
    (destination / 'builtin-search-evidence.json').write_text(json.dumps(evidence, indent=2))
    (destination / 'builtin-selection.json').write_text(json.dumps(applied, indent=2))
    read_program(destination)
    return dict(program=str(destination), applied=len(applied),
                program_sha256=hashlib.sha256((destination/'program.json').read_bytes()).hexdigest(),
                qualified_phases=sum(p['status']=='passed' for p in manifest['builtin_qualification']['phases']))
