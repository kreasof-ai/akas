"""WebGPU decode candidates preserve incumbent arithmetic and operation ABIs."""

import hashlib
import os
from contextlib import ExitStack

import numpy as np
import pytest


@pytest.fixture
def compile_candidate(tmp_path):
    def compile_one(kind, parameters, implementation, schedule=None):
        from akas.compilation.emit import build_artifact
        from akas.compilation.selection import selected_source
        from akas.kernels.definition import definition
        from tensor.artifacts.format import read_artifact

        spec = dict(
            kind=kind, parameters=parameters, contract="reference", phase="forward"
        )
        capabilities = dict(provider="webgpu", target="webgpu-portable-v1")
        selected, schedule = definition(
            spec, {**(schedule or {}), "implementation": implementation}, capabilities
        )
        digest = hashlib.sha256(
            repr((implementation, selected, schedule)).encode()
        ).hexdigest()[:24]
        source = tmp_path / (digest + ".py")
        artifact = source.with_suffix(".tbin")
        source.write_text(
            selected_source(spec, schedule, capabilities, selected).render()
        )
        build_artifact(source, artifact, **capabilities)
        manifest, _ = read_artifact(artifact)
        return manifest, artifact

    return compile_one


def execute(device, artifact, case, stack):
    from akas.execution.plan import ExecutionPlan

    buffers = {}
    for name, value in case.arguments.items():
        buffer = device.from_numpy(value)
        stack.callback(buffer.release)
        buffers[name] = buffer
    kernel = stack.enter_context(device.load(artifact))
    arguments = [buffers[row["name"]] for row in kernel.manifest["arguments"]]
    plan = ExecutionPlan(device)
    plan.bind(kernel, arguments)
    prepared = plan.capture(resources=(kernel, *arguments))
    stack.callback(prepared.close)
    prepared.launch()
    device.synchronize()
    return {name: buffer.to_numpy() for name, buffer in buffers.items()}


def check_reference(result, case):
    for name, expected in case.expected.items():
        if name in case.comparators:
            case.comparators[name](result[name], expected)
        elif result[name].dtype.kind in "biu":
            np.testing.assert_array_equal(result[name], expected)
        else:
            np.testing.assert_allclose(
                result[name], expected, rtol=case.rtol, atol=case.atol
            )


@pytest.mark.skipif(
    os.environ.get("AKAS_FORWARD_WEBGPU") != "1",
    reason="opt-in native Vulkan candidate qualification",
)
@pytest.mark.parametrize("threads", [128])
@pytest.mark.parametrize("segmented", [False, True])
def test_q8_subgroup_projection_preserves_shared_gemv(
    compile_candidate, threads, segmented
):
    from akas.kernels.registry import validation
    from tools.context_sweep import vulkan_device

    parts = (
        dict(format="ggml", rows=16, options=dict(encoding=8)),
        dict(format="ggml", rows=16, options=dict(encoding=8)),
        dict(format="ggml", rows=16, options=dict(encoding=8)),
        dict(format="ggml", rows=16, options=dict(encoding=8)),
    )
    parameters = dict(
        r=1,
        k=256,
        o=sum(part["rows"] for part in parts) if segmented else 16,
        input_dtype="float32",
        weight_parts=parts if segmented else parts[:1],
    )
    incumbent, original = compile_candidate(
        "quantized_projection", parameters, "akas.ops.linear.webgpu:projection:decode"
    )
    candidate, artifact = compile_candidate(
        "quantized_projection",
        parameters,
        "linear.webgpu.q8-subgroup",
        {"threads": threads},
    )
    assert candidate["arguments"] == incumbent["arguments"]
    case = validation("quantized_projection", parameters, candidate["arguments"])
    with vulkan_device() as device, ExitStack() as stack:
        expected = execute(device, original, case, stack)
        result = execute(device, artifact, case, stack)
    for name in case.expected:
        np.testing.assert_array_equal(result[name], expected[name])
    check_reference(result, case)


@pytest.mark.skipif(
    os.environ.get("AKAS_FORWARD_WEBGPU") != "1",
    reason="opt-in native Vulkan candidate qualification",
)
@pytest.mark.parametrize("groups", [2, 4])
@pytest.mark.parametrize("index", [3, 4, 5])
def test_batched_residual_preserves_shared_score_reduction(
    compile_candidate, groups, index
):
    from akas.kernels.registry import validation
    from tools.context_sweep import vulkan_device

    parameters = dict(r=1, c=1024, capacity=index + 3, index=index, eps=1e-5)
    incumbent, original = compile_candidate(
        "attention_residual", parameters, "akas.ops.residual.kernel:attention_residual"
    )
    candidate, artifact = compile_candidate(
        "attention_residual",
        parameters,
        "residual.webgpu.batched-scores",
        {"groups": groups},
    )
    assert candidate["arguments"] == incumbent["arguments"]
    case = validation("attention_residual", parameters, candidate["arguments"])
    with vulkan_device() as device, ExitStack() as stack:
        expected = execute(device, original, case, stack)
        result = execute(device, artifact, case, stack)
    for name in case.expected:
        np.testing.assert_array_equal(result[name], expected[name])
    check_reference(result, case)
