"""WebGPU specializations and shared bindings for residual."""

from .kernel import add
from .definition import IMPLEMENTATIONS as _CHOICES

IMPLEMENTATIONS = tuple((choice for choice in _CHOICES if choice.provider == "webgpu"))


def batched_attention_residual(spec, schedule):
    """Evaluate independent residual scores through shared reduction barriers."""
    import tilelang.language as T
    from akas.kernels.kernel import Tensor, kernel, output

    p = {**spec.parameters, **schedule}
    rows, width, capacity, index, epsilon = (
        p[key] for key in ("r", "c", "capacity", "index", "eps")
    )
    if rows != 1 or index < 3:
        raise ValueError("batched residual scoring requires one row and four scores")
    groups = p.get("groups", min(4, (index + 1) // 2))
    threads = p.get("threads", 128)
    if groups not in (2, 4) or threads != 128:
        raise ValueError(
            "batched residual scoring requires two or four 128-lane groups"
        )
    rounds = (index + 1 + groups - 1) // groups

    @kernel
    def compute(
        bank: Tensor((capacity, rows, width), "float32"),
        source: Tensor((rows, width), "float32"),
        query: Tensor((width,), "float32"),
    ) -> tuple[
        Tensor((capacity, rows, width), "float32"), Tensor((rows, width), "float32")
    ]:
        out = output((rows, width), "float32")
        with T.Kernel(rows, threads=threads) as row:
            lane = T.get_thread_binding()
            scores = T.alloc_shared((index + 1,), "float32")
            norms = T.alloc_shared((groups, threads), "float32")
            dots = T.alloc_shared((groups, threads), "float32")
            peak = T.alloc_shared((1,), "float32")
            denominator = T.alloc_shared((1,), "float32")
            sum_sq0, sum_sq1 = T.alloc_var("float32"), T.alloc_var("float32")
            sum_sq2, sum_sq3 = T.alloc_var("float32"), T.alloc_var("float32")
            dot0, dot1 = T.alloc_var("float32"), T.alloc_var("float32")
            dot2, dot3 = T.alloc_var("float32"), T.alloc_var("float32")
            for stripe in T.serial(T.ceildiv(width, threads)):
                column = stripe * threads + lane
                if column < width:
                    bank[index, row, column] = source[row, column]
            T.sync_threads()
            for batch in T.serial(rounds):
                sum_sq0, sum_sq1, sum_sq2, sum_sq3 = 0, 0, 0, 0
                dot0, dot1, dot2, dot3 = 0, 0, 0, 0
                for stripe in T.serial(T.ceildiv(width, threads)):
                    column = stripe * threads + lane
                    if column < width:
                        entry0 = bank[batch * groups, row, column]
                        sum_sq0 += entry0 * entry0
                        dot0 += entry0 * query[column]
                        if groups > 1 and batch * groups + 1 <= index:
                            entry1 = bank[batch * groups + 1, row, column]
                            sum_sq1 += entry1 * entry1
                            dot1 += entry1 * query[column]
                        if groups > 2 and batch * groups + 2 <= index:
                            entry2 = bank[batch * groups + 2, row, column]
                            sum_sq2 += entry2 * entry2
                            dot2 += entry2 * query[column]
                        if groups > 3 and batch * groups + 3 <= index:
                            entry3 = bank[batch * groups + 3, row, column]
                            sum_sq3 += entry3 * entry3
                            dot3 += entry3 * query[column]
                norms[0, lane], dots[0, lane] = sum_sq0, dot0
                if groups > 1:
                    norms[1, lane], dots[1, lane] = sum_sq1, dot1
                if groups > 2:
                    norms[2, lane], dots[2, lane] = sum_sq2, dot2
                if groups > 3:
                    norms[3, lane], dots[3, lane] = sum_sq3, dot3
                T.sync_threads()
                for step in T.unroll(7):
                    stride = 64 >> step
                    if lane < stride:
                        norms[0, lane] = norms[0, lane] + norms[0, lane + stride]
                        dots[0, lane] = dots[0, lane] + dots[0, lane + stride]
                        if groups > 1:
                            norms[1, lane] = norms[1, lane] + norms[1, lane + stride]
                            dots[1, lane] = dots[1, lane] + dots[1, lane + stride]
                        if groups > 2:
                            norms[2, lane] = norms[2, lane] + norms[2, lane + stride]
                            dots[2, lane] = dots[2, lane] + dots[2, lane + stride]
                        if groups > 3:
                            norms[3, lane] = norms[3, lane] + norms[3, lane + stride]
                            dots[3, lane] = dots[3, lane] + dots[3, lane + stride]
                    T.sync_threads()
                if lane == 0:
                    scores[batch * groups] = dots[0, 0] * T.rsqrt(
                        norms[0, 0] / width + epsilon
                    )
                    if groups > 1 and batch * groups + 1 <= index:
                        scores[batch * groups + 1] = dots[1, 0] * T.rsqrt(
                            norms[1, 0] / width + epsilon
                        )
                    if groups > 2 and batch * groups + 2 <= index:
                        scores[batch * groups + 2] = dots[2, 0] * T.rsqrt(
                            norms[2, 0] / width + epsilon
                        )
                    if groups > 3 and batch * groups + 3 <= index:
                        scores[batch * groups + 3] = dots[3, 0] * T.rsqrt(
                            norms[3, 0] / width + epsilon
                        )
            if lane == 0:
                peak[0] = scores[0]
                for i in T.serial(1, index + 1):
                    peak[0] = T.max(peak[0], scores[i])
                denominator[0] = 0
                for i in T.serial(index + 1):
                    scores[i] = T.exp(scores[i] - peak[0])
                    denominator[0] += scores[i]
            T.sync_threads()
            for stripe in T.serial(T.ceildiv(width, threads)):
                column = stripe * threads + lane
                if column < width:
                    total = T.alloc_var("float32")
                    total = 0
                    for i in T.serial(index + 1):
                        total += bank[i, row, column] * (scores[i] / denominator[0])
                    out[row, column] = total
        return bank, out

    return compute
