"""Matrix fairness, budgets, precision requirements and retained baseline rows."""

from dataclasses import replace
import json
from pathlib import Path

import pytest

from akas.benchmarking.history import write
from akas.optimization.context import Context
from akas.optimization.planning import recipes
from tools.baselines import common
from tools import campaign


def test_required_mode_and_cache_are_context_not_schedule_options():
    context = Context(
        "weights",
        "model:Model",
        dict(batches=[1], prefix_tokens=[32], output_tokens=128),
        mode="mtp",
        kv_dtype="fp8",
    )
    assert context.metadata()["kv_dtype"] == "fp8"
    with pytest.raises(ValueError):
        replace(context, mode="draft")
    probe = dict(
        status="ok",
        provider="cuda",
        device=dict(arch="sm_89"),
        chunks=[32],
        policies=[{}],
        model_options={},
        option_variants=[],
        windows=[2, 4],
        deferred_windows=[],
        head="family:Head",
    )
    plans = recipes(context.metadata(), [probe])
    assert plans[0]["window"] is None  # Independent AR output reference.
    assert all(p["window"] for p in plans[1:])


def test_partial_baseline_survives_later_oom_and_prompts_match_optimizer(
    tmp_path, monkeypatch
):
    from akas.optimization.evaluation import prompts

    assert common.synthetic_prompts(400, 4, 32) == prompts(400, 4, 32)
    monkeypatch.setattr(common, "_output", tmp_path / "result.json")
    config = dict(shapes=[[1, 32], [4, 32]], output_tokens=2, warmup=0, repeats=2)
    report = dict(cases=[])

    def invoke(batch, prefix):
        if batch == 4:
            raise MemoryError("GPU capacity")
        return [[1, 2]], {}

    with pytest.raises(MemoryError):
        common.measurements(config, invoke, report)
    stored = json.loads((tmp_path / "result.json").read_text())
    assert [r["status"] for r in stored["cases"]] == ["passed", "failed"]
    assert len(stored["cases"][0]["samples"]) == 2


def test_matrix_resumes_without_repeating_completed_entries(tmp_path, monkeypatch):
    root = Path(__file__).resolve().parents[1]
    spec = tmp_path / "spec.json"
    write(
        spec,
        dict(
            models=["lfm2.5-230m"],
            formats=["bf16"],
            backends=["cuda", "webgpu"],
            caches=["default"],
            workload="standard-v1",
        ),
    )
    calls = []

    def optimize(context, out, **kwargs):
        calls.append((context.backend, kwargs["budget"]))
        return dict(status="complete", deployment=str(out / "deployment.json"))

    monkeypatch.setattr(campaign, "optimize", optimize)
    state = campaign.run(
        spec,
        tmp_path / "out",
        budget=60,
        slice_seconds=10,
        history=tmp_path / "history",
    )
    assert state["status"] == "complete"
    assert calls == [("cuda", 10), ("webgpu", 10)]
    campaign.run(
        spec,
        tmp_path / "out",
        budget=60,
        slice_seconds=10,
        history=tmp_path / "history",
    )
    assert len(calls) == 2
    with pytest.raises(ValueError, match="budget changed"):
        campaign.run(
            spec,
            tmp_path / "out",
            budget=61,
            slice_seconds=10,
            history=tmp_path / "history",
        )
