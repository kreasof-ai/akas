# Baseline preflight

These are short execution checks for vLLM, SGLang and llama.cpp. Each worker
implements `run(config) -> report` using its own runtime. The launcher owns the
deadline, source capture and [benchmark history](../../benchmarks/README.md).
These probes do not establish optimized baseline throughput.

[Model declarations](../../benchmarks/models/) hold checkpoint paths, pinned
sources, generation modes and runtime options. Add a model by adding one JSON
file; the workers contain no model-name dispatch. Cache weights under
`build/checkpoints/<model-id>/`. A declaration may point to an existing local
cache; copying large files is unnecessary.

Create separate Python 3.12 environments under `build/baselines/vllm` and
`build/baselines/sglang`. The validated versions are vLLM 0.31.0 and SGLang 0.5.21;
install each with `uv pip install --python <environment>/bin/python`. Use a
complete CUDA toolkit and set `CUDA_HOME` and `PATH` to it. An environment with
`nvcc` but missing CUDA headers is insufficient for first-use JIT compilation.

Build llama.cpp commit `620d2225cc436ab0b001e3200e590e3b286ef9ab` under
`build/baselines/llama.cpp`, with separate `build-cuda` and `build-vulkan`
directories. Enable `GGML_CUDA` or `GGML_VULKAN` and build `llama-server`.
Use the GPU's actual CUDA architecture. Vulkan needs the loader and matching
NVIDIA graphics libraries; a software Vulkan adapter is not a GPU baseline.

Run one probe at a time from the repository root:

```sh
uv run --no-sync python -m tools.baselines vllm lfm
uv run --no-sync python -m tools.baselines vllm qwen
uv run --no-sync python -m tools.baselines vllm qwen --mtp
uv run --no-sync python -m tools.baselines sglang lfm
uv run --no-sync python -m tools.baselines sglang qwen
uv run --no-sync python -m tools.baselines sglang qwen --mtp
uv run --no-sync python -m tools.baselines llama qwen --format q4_k_m --provider vulkan
```

Native probes check B1/P32, B4/P32 and B1/P2048 with 128 total output tokens.
The llama.cpp server probe checks B1 at both prompt lengths; server concurrency
is not a controlled native batch. MTP checks compare token IDs against the
matching AR probe, which must be run first. Every probe uses one warmup and one
measured repeat, with a ten-minute process deadline by default. Cold JIT
compilation can consume several minutes; keep its cache for subsequent runs.

The launcher archives its exact model/configuration files, runtime dependencies,
checkpoint hash, raw output and log. `purpose=preflight` keeps these records
separate from final measurements. Failures and time limits remain in history.

For Qwen F16, the model declaration specifies conversion from the pinned original
safetensors checkpoint with llama.cpp `--outtype f16 --no-mtp`; a vision projector
is not the text model. The other GGUF variants reference their pinned repositories.
Use identical resulting bytes when measuring AKAS and llama.cpp.
