"""Worker protocol shared by isolated third-party runtime environments."""

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import traceback


def main(run):
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    report = dict(started_at=datetime.now(timezone.utc).isoformat())
    try:
        report.update(run(config))
        report["status"] = "passed"
    except Exception as error:
        report.update(
            status="failed",
            error=f"{type(error).__name__}: {error}",
            traceback=traceback.format_exc(),
        )
        print(report["traceback"], flush=True)
    report["completed_at"] = datetime.now(timezone.utc).isoformat()
    args.out.write_text(json.dumps(report, indent=2, default=str) + "\n")
    if report["status"] != "passed":
        raise SystemExit(1)


def prompt_tokens(tokenizer, count):
    seed = tokenizer.encode(
        "The capital of France is Paris. Explain the history of this city briefly. ",
        add_special_tokens=False,
    )
    return (seed * ((count + len(seed) - 1) // len(seed)))[:count]
