"""Transport the standard AKAS campaign to Modal; selection stays in AKAS."""
from pathlib import Path
import modal
from tools.h200_modal import ROOT, cimage, volume

SPEC = Path('benchmarks/campaigns/lfm2.5-24b-a2b-fp8-h200.json')
BASELINE_LOCK = Path('benchmarks/runs/20261102212730368879-95d732f7/frozen-baselines.lock.json')
HISTORY = '/data/standard-benchmarks'
VOLUME_HISTORY = 'standard-benchmarks'
app = modal.App('akas-h200-standard-campaign')
image = (cimage.add_local_dir(ROOT/'benchmarks/models', '/workspace/akas/benchmarks/models')
         .add_local_file(ROOT/SPEC, '/workspace/akas/'+str(SPEC))
         .add_local_file(ROOT/BASELINE_LOCK, '/workspace/akas/'+str(BASELINE_LOCK)))


def command(seconds, out, *, python='python'):
    if not 1 <= seconds <= 1800:
        raise ValueError('campaign allowance must be 1..1800 seconds')
    return [python, '-u', '-m', 'tools.campaign', '--spec', str(SPEC),
            '--budget', f'{seconds}s', '--slice', f'{seconds}s',
            '--out', str(out), '--history', HISTORY]


@app.function(image=image, gpu='H200', volumes={'/data':volume}, timeout=1890,
              cpu=8, memory=65536, scaledown_window=2, max_containers=1)
def run(seconds: int, name: str):
    import json, os, subprocess, sys
    from akas.benchmarking.history import rebuild_index

    os.chdir('/workspace/akas')
    if os.environ.get('AKAS_SKIP_AUTOTUNE') == '1':
        raise RuntimeError('qualification/search bypass is forbidden for this campaign')
    alias=Path('build/checkpoints/lfm2.5-24b-a2b-fp8')
    alias.parent.mkdir(parents=True,exist_ok=True)
    if not alias.exists():alias.symlink_to('/data/checkpoint',target_is_directory=True)
    rebuild_index(Path(HISTORY))
    out=Path('/data/campaigns')/name;out.mkdir(parents=True,exist_ok=True)
    argv=command(seconds,out,python=sys.executable)
    (out/'command.json').write_text(json.dumps(argv,indent=2))
    print('STANDARD CAMPAIGN',argv,flush=True)
    try:
        with (out/'launcher.log').open('w') as log:
            process=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            for line in process.stdout:print(line,end='',flush=True);log.write(line);log.flush()
            code=process.wait()
        state=json.loads((out/'campaign.json').read_text())
        return dict(returncode=code,status=state['status'],campaign=str(out/'campaign.json'),
                    deployments=[e['deployment'] for e in state['entries'] if e.get('deployment')])
    finally:
        volume.commit()


@app.local_entrypoint()
def main(seconds: int=300, name: str='lfm2.5-h200-standard'):
    import hashlib,json,time

    command(seconds,Path('/data/campaigns')/name)
    if Path(name).name!=name or name in ('.','..'):raise ValueError('campaign name must be a directory name')
    ledger_path=ROOT/'build/h200/cost-ledger.json'
    ledger=json.loads(ledger_path.read_text())
    rate=.001261+8*.0000131+64*.00000222;reserve=(seconds+90)*rate
    if sum(r['conservative_usd'] for r in ledger)+reserve>28:raise RuntimeError('campaign credit reserve exceeded')
    # Stage the exact pinned records for the standard report exporter, without
    # starting either vendor runtime or modifying the retained measurements.
    lock=json.loads((ROOT/BASELINE_LOCK).read_text())
    with volume.batch_upload(force=True) as upload:
        for entry in lock['runs'].values():
            source=ROOT/entry['record']
            if hashlib.sha256(source.read_bytes()).hexdigest()!=entry['sha256']:
                raise ValueError('frozen baseline record changed')
            for filename,sha in entry['artifact_checksums'].items():
                if hashlib.sha256((source.parent/filename).read_bytes()).hexdigest()!=sha:
                    raise ValueError('frozen baseline artifact changed: '+filename)
            upload.put_directory(source.parent,VOLUME_HISTORY+'/runs/'+entry['run_id'])
    row=dict(action='akas-standard-campaign',seconds=seconds,campaign=name,status='reserved',
             started_at=time.time(),conservative_usd=reserve)
    ledger.append(row);ledger_path.write_text(json.dumps(ledger,indent=2));tick=time.monotonic()
    try:
        result=run.with_options(timeout=seconds+90).remote(seconds,name)
        row.update(status='completed',result=result);print(json.dumps(result,indent=2))
    finally:
        row['elapsed_seconds']=time.monotonic()-tick
        if row['status']=='completed':row['conservative_usd']=(row['elapsed_seconds']+30)*rate
        ledger_path.write_text(json.dumps(ledger,indent=2))
