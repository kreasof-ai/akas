"""H200 transportation must preserve the standard campaign's requirements."""
import json
from pathlib import Path
import pytest


def test_h200_uses_standard_campaign_and_exact_requested_workload():
    from tools.h200_akas_optimize import SPEC, BASELINE_LOCK, HISTORY, VOLUME_HISTORY, command
    from akas.optimization.context import workload
    root=Path(__file__).resolve().parents[1]
    spec=json.loads((root/SPEC).read_text())
    requested=workload(spec['workload'])
    assert requested['batches']==[1,4,16,64,256]
    assert requested['prefix_tokens']==[2048]
    assert requested['output_tokens']==128
    assert spec['formats']==['fp8'] and spec['caches']==['float16']
    assert SPEC.parent==Path('benchmarks/campaigns')
    assert spec['baseline_lock']==str(BASELINE_LOCK)
    assert (root/BASELINE_LOCK).is_file()
    assert not (root/'benchmarks/configs').exists()
    assert HISTORY=='/data/'+VOLUME_HISTORY
    args=command(300,'/data/campaigns/test',python='python')
    assert args[:5]==['python','-u','-m','tools.campaign','--spec']
    assert '--no-autotune' not in args
    assert '--program' not in args and '--policy' not in args and '--schedules' not in args
    for seconds in (0,1801):
        with pytest.raises(ValueError):command(seconds,'/data/campaigns/test')


def test_matrix_freezes_lock_contents_and_detects_changes(tmp_path,monkeypatch):
    from tools import campaign,campaign_report
    lock=tmp_path/'lock.json';lock.write_text(json.dumps(dict(schema='akas.baseline-lock.v1',runs={})))
    spec=tmp_path/'campaign.json';spec.write_text(json.dumps(dict(models=['lfm2.5-230m'],
        formats=['bf16'],backends=['cuda'],caches=['default'],workload='standard-v1',
        baseline_lock=str(lock))))
    monkeypatch.setattr(campaign,'discover',lambda _: 'example:Model')
    monkeypatch.setattr(campaign,'optimize',lambda *a,**kw:dict(status='complete',deployment=None))
    captured=[]
    def export(path,**kwargs):
        captured.append(json.loads(path.read_text())['baseline_lock']);return tmp_path/'report'
    monkeypatch.setattr(campaign_report,'export',export)
    state=campaign.run(spec,tmp_path/'out',budget=5,slice_seconds=5,history=tmp_path/'history')
    assert state['baseline_lock']==captured[0]==json.loads(lock.read_text())
    lock.write_text(json.dumps(dict(schema='akas.baseline-lock.v1',runs={'vllm':{'run_id':'changed'}})))
    with pytest.raises(ValueError,match='changed'):
        campaign.run(spec,tmp_path/'out',budget=5,slice_seconds=5,history=tmp_path/'history')
