"""Compiler-free execution of the ZONOS3 text-to-speech pipeline."""

from contextlib import ExitStack, contextmanager
from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np

from akas.benchmarking.history import digest
from akas.execution.forward import Forward
from akas.graph import Graph
from akas.memory.transfer import write_many
from akas.models.zonos3.audio import (
    SILENCE_FRAMES,
    codebook_logits,
    feedback_embedding,
    feedback_ids,
    generate_codes,
    silence_prefix,
    waveform,
)
from akas.models.zonos3.backbone import Zonos3Mini
from akas.models.zonos3.codec import HEAD_DIM, SPECTRUM_ROWS_PER_FRAME
from akas.models.zonos3.model import compose
from akas.models.zonos3.weights import (
    CODEBOOK_EMBEDDING,
    TOKEN_EMBEDDING,
    Zonos3MiniCheckpoint,
)


@dataclass(frozen=True)
class Speech:
    samples: np.ndarray
    sample_rate: int
    frames: int
    terminated: bool


class Zonos3MiniSynthesis:
    """Run non-streaming predefined-voice synthesis with compiled AKAS phases."""

    checkpoint_type = Zonos3MiniCheckpoint
    compose = staticmethod(compose)

    def __init__(self, checkpoint, directory, device):
        self.checkpoint, self.config, self.device = (
            checkpoint,
            checkpoint.config,
            device,
        )
        self._resources = ExitStack()
        self._codecs = {}
        directory = Path(directory).resolve()
        program = json.loads((directory / "speech.json").read_text(encoding="utf-8"))
        if (
            program["schema"] != "akas.speech-program.v1"
            or program["provider"] != device.info["provider"]
        ):
            raise ValueError("incompatible ZONOS3 speech bundle")

        def phase_paths(name):
            paths = {}
            for rows, entry in program["phases"][name].items():
                filename = entry["path"]
                path = (directory / filename).resolve()
                if (
                    not path.is_relative_to(directory)
                    or digest(path) != entry["sha256"]
                ):
                    raise ValueError("invalid ZONOS3 speech phase manifest")
                paths[int(rows)] = filename
            return paths

        try:
            self.backbone = self._resources.enter_context(
                Zonos3Mini(
                    checkpoint, directory, device, phases=phase_paths("backbone")
                )
            )
            self._feedback_table = checkpoint.projector.array(CODEBOOK_EMBEDDING)
            self._head_path = phase_paths("audio_head")[1]
            self._codec_paths = phase_paths("codec")
            self._directory = directory
            weights = set()
            for filename in (self._head_path, *self._codec_paths.values()):
                graph = self._graph(filename)
                weights.update(
                    name
                    for name, spec in graph.buffers.items()
                    if spec.role == "weight" and spec.alias_of is None
                )
            self._weights = checkpoint.upload(device, sorted(weights))
            for buffer in self._weights.values():
                self._resources.callback(buffer.release)
            self._head = self._open(self._head_path)
            for count, filename in self._codec_paths.items():
                self._codecs[count] = self._open(filename)
        except BaseException:
            self.close()
            raise

    def _graph(self, filename):
        manifest = json.loads((self._directory / filename).read_text(encoding="utf-8"))
        return Graph.from_metadata(manifest["forward"])

    def _open(self, filename):
        graph = self._graph(filename)
        supplied = {
            name: value
            for name, value in self._weights.items()
            if name in graph.buffers
        }
        for name, spec in graph.buffers.items():
            if spec.alias_of is not None or spec.role not in ("input", "output"):
                continue
            if name.startswith("codec_"):
                control, _, size = name.partition(".")
                if control in ("codec_active", "codec_unit"):
                    value = np.ones(spec.shape, dtype=spec.dtype)
                elif control == "codec_positions":
                    value = np.arange(int(size), dtype="int32")
                else:
                    positions = np.arange(int(size))[:, None]
                    angle = positions * 10000 ** (-np.arange(0, HEAD_DIM, 2) / HEAD_DIM)
                    value = np.concatenate(
                        (np.cos(angle), np.sin(angle)), axis=1
                    ).astype("float32")
                buffer = self.device.from_numpy(value)
            else:
                buffer = self.device.empty(spec.shape, spec.dtype)
            supplied[name] = buffer
            self._resources.callback(buffer.release)
        return self._resources.enter_context(
            Forward(
                self._directory, self.device, supplied, filename=filename, graphs=True
            )
        )

    def _predict(self, hidden):
        write_many(self.device, ((self._head.buffers["hidden"], hidden.reshape(-1)),))
        self._head.run()
        return codebook_logits(
            self.config, self._head.buffers["projection"].to_numpy()
        )[0]

    def _embedding(self, codes):
        ids = feedback_ids(self.config, codes)
        return feedback_embedding(self.config, self._feedback_table[ids])

    def generate_codes(self, text, *, voice=None, seed=17, temperature=0.75, limit=384):
        """Generate aligned ZAC frames, including the initial codec silence."""
        self.backbone.reset()
        ids = self.checkpoint.prompt_ids(text)
        text_rows = [
            self.checkpoint.backbone.row(TOKEN_EMBEDDING, token) for token in ids
        ]
        prefix = np.concatenate(
            (
                self.checkpoint.voice_rows(voice),
                np.stack(text_rows),
                self._embedding(silence_prefix(self.config)),
            )
        )
        if len(prefix) + limit - 1 > self.backbone.context:
            raise ValueError("ZONOS3 text and frame limit exceed the compiled context")
        size = self.backbone.prefill_rows
        hidden = None
        for start in range(0, len(prefix), size):
            end = start + size
            hidden = self.backbone.advance(prefix[start:end], read=end >= len(prefix))

        def next_logits(row):
            return self._predict(self.backbone.advance(self._embedding(row))[-1])

        return generate_codes(
            self.config,
            self._predict(hidden[-1]),
            next_logits,
            seed=seed,
            temperature=temperature,
            limit=limit,
        )

    def decode(self, frames):
        count = len(frames)
        if count <= SILENCE_FRAMES:
            raise ValueError("ZONOS3 generated no complete speech frames")
        candidates = [n for n in self._codecs if n >= count]
        if not candidates:
            raise ValueError("ZONOS3 audio exceeds the compiled codec frame capacities")
        capacity = min(candidates)
        forward = self._codecs[capacity]
        codes = np.pad(frames, ((0, capacity - count), (0, 0)))
        write_many(
            self.device,
            (
                (forward.buffers["semantic"], codes[:, 0]),
                (forward.buffers["residual_codes"], codes[:, 1:]),
            ),
        )
        forward.run()
        spectrum = forward.buffers["spectrum"].to_numpy()[
            : count * SPECTRUM_ROWS_PER_FRAME
        ]
        return waveform(self.checkpoint, spectrum)

    def synthesize(self, text, **options):
        frames = self.generate_codes(text, **options)
        samples = self.decode(frames.frames)
        return Speech(
            samples,
            self.config.sample_rate,
            len(frames.frames) - SILENCE_FRAMES,
            frames.terminated,
        )

    def close(self):
        self._resources.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


@contextmanager
def service(checkpoint, projector, bundle, *, device=0):
    """Open a compiled model on the speech server's device-owner thread."""
    from akas.serving.speech import SpeechService
    from akas.tensor.device import vulkan_device

    loaded = Zonos3MiniCheckpoint(checkpoint, projector)
    with (
        vulkan_device(device) as adapter,
        Zonos3MiniSynthesis(loaded, bundle, adapter) as model,
    ):
        name = adapter.info["adapter"]["device"]
        yield SpeechService(
            model.synthesize,
            dict(
                device=dict(adapter.info, name=name),
                program_sha256=digest(Path(bundle) / "speech.json"),
                sample_rate_hz=loaded.config.sample_rate,
            ),
        )
