"""Shared execution implementation."""
