"""Shared memory implementation."""
