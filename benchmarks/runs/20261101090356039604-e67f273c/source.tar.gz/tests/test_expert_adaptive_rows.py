"""AOT row-tile branches preserve the shared routed-projection contract."""
import os
import pytest


@pytest.mark.skipif(os.getenv('AKAS_LFM_FP8_CUDA')!='1',reason='CUDA adaptive routed tile qualification')
@pytest.mark.parametrize('rows',[33,65,129,301,337,421])
@pytest.mark.parametrize('kind',['expert_partial','fp8_expert_swiglu'])
def test_adaptive_expert_rows_cover_tail_regions_and_nonzero_offsets(tmp_path,rows,kind):
    from test_lfm_moe_native import test_native_operations_match_independent_references as check
    check(tmp_path,kind,dict(r=rows,rows=rows,k=384,o=256,experts=7,top=3,partitions=1,
          block_m=128,max_block_m=128,compact=True,tile_map=True,columns=128,
          threads=512,stages=1,pair_layout='separate',activation_vector=16,
          packed_input=True,packed_output=kind=='fp8_expert_swiglu',
          routed_input=kind=='expert_partial',product_dtype='bfloat16',activation_dtype='bfloat16',
          dynamic_m=True))


def test_adaptive_rows_require_a_boolean_choice():
    from akas.ops.moe.cuda import _bucketed
    with pytest.raises(ValueError,match='boolean'):
        _bucketed(dict(r=33,rows=33,k=256,o=256,experts=7,top=3,
                      partitions=1,block_m=32,columns=128,threads=128,
                      compact=True,tile_map=True,dynamic_m=1))
