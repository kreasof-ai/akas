# ZONOS3-Mini

`Zonos3MiniSynthesis` loads the published Q8_0 backbone and F32
`keep2_plain` projector. The model declaration in `model.py` selects
the backbone, codebook projection, and ZAC decoder geometries. The `speech`
profile builds them through the common graph compiler and publishes `speech.json`.
The backbone shares its Gated DeltaNet and attention cache state across prefill
and single-row phases. The synthesis runtime uses the common `Forward` executor
and handles text and voice conditioning, delayed codebook sampling, and
conversion from the decoded spectrum to 44.1 kHz mono audio.

The WebGPU path runs on hardware Vulkan. This path accepts normalized English
text and the predefined voices in the projector. Compile frame capacities large
enough for the expected output. The runtime selects the smallest compiled codec
capacity that fits the generated code frames.

```sh
WGPU_BACKEND_TYPE=Vulkan uv run --no-sync akas compile \
  --definition akas.models.zonos3:Zonos3MiniSynthesis --profile speech \
  --checkpoint build/checkpoints/zonos3-mini/ZONOS3-Mini-Q8_0.gguf \
  --checkpoint-options '{"projector":"build/checkpoints/zonos3-mini/mmproj-ZONOS3-Mini-F32.gguf"}' \
  --config '{"context":1024,"prefill_rows":64,"codec_frames":[32,64]}' \
  --out build/zonos3-mini/speech
```

Set `$env:WGPU_BACKEND_TYPE = 'Vulkan'` before the command in PowerShell.
Use the [speech benchmark commands](../../../../tools/baselines/README.md#speech-synthesis-demo)
to run the same request and audio-delivery protocol against llama.cpp Vulkan.
