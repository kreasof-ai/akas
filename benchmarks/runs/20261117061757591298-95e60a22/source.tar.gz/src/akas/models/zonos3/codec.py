"""Compose the keep2_plain ZAC decoder for one cold-start utterance."""

from akas.graph import Graph


HEAD_DIM = 64
STAGE_WINDOWS = (150, 300, 480, 480, 480)
SPECTRUM_ROWS_PER_FRAME = 1 << (len(STAGE_WINDOWS) - 1)


def compose_codec(checkpoint, *, frames, provider):
    if provider != "webgpu":
        raise ValueError("ZONOS3 codec requires WebGPU")
    config = checkpoint.config
    graph = Graph(contract="reference")
    table = checkpoint.projector.tensors
    root = "a.gen.wav."
    head_unit = graph.buffer("codec_unit", (HEAD_DIM,), "float32", role="input")

    def weight(name):
        if name not in graph.buffers:
            if table[name].type != 0:
                raise ValueError(f"ZONOS3 codec weight must be F32: {name}")
            checkpoint.graph_weight(graph, name, provider=provider)
        return graph.buffers[name]

    def dense(x, name):
        tensor_name = name + ".weight"
        columns, depth = table[tensor_name].shape
        rows = x.shape[0]
        out = graph.buffer(name, (rows, columns), "float32")
        graph(
            "linear",
            dict(r=rows, k=depth, o=columns, tiled_f32=True),
            x.view((rows * depth,)),
            weight(tensor_name),
            out.view((rows * columns,)),
        )
        return out

    def activated(x, name, *, bias=None, gelu=False, role="scratch"):
        rows, width = x.shape
        out = graph.buffer(name, x.shape, "float32", role=role)
        p = dict(r=rows, c=width)
        if bias is None:
            graph("gelu", p, x, out)
        else:
            graph("gelu_bias" if gelu else "column_bias", p, x, weight(bias), out)
        return out

    def norm(x, prefix, epsilon):
        rows, width = x.shape
        out = graph.buffer(prefix + ".normal", x.shape, "float32")
        graph(
            "affine_layer_norm",
            dict(r=rows, c=width, eps=epsilon),
            x,
            weight(prefix + ".weight"),
            weight(prefix + ".bias"),
            out,
        )
        return out

    def add(x, y, name, *, scale=None):
        rows, width = x.shape
        out = graph.buffer(name, x.shape, "float32")
        parameters = dict(r=rows, c=width)
        if scale is None:
            flat = (rows * width,)
            graph("add", parameters, x.view(flat), y.view(flat), out.view(flat))
        else:
            graph("scaled_residual", parameters, x, y, weight(scale), out)
        return out

    def convnext(x, prefix):
        rows, width = x.shape
        dw = prefix + ".dw.weight"
        taps = table[dw].shape[-1]
        filtered = graph.buffer(prefix + ".filtered", x.shape, "float32")
        graph(
            "causal_depthwise",
            dict(r=rows, c=width, taps=taps),
            x,
            weight(dw).view((width, taps)),
            weight(prefix + ".dw.bias"),
            filtered,
        )
        h = norm(filtered, prefix + ".norm", 1e-6)
        h = activated(
            dense(h, prefix + ".pw1"),
            prefix + ".gelu",
            bias=prefix + ".pw1.bias",
            gelu=True,
        )
        h = activated(
            dense(h, prefix + ".pw2"), prefix + ".biased", bias=prefix + ".pw2.bias"
        )
        return add(x, h, prefix + ".residual")

    def attention(x, prefix, window, controls):
        rows, width = x.shape
        heads, d = width // HEAD_DIM, HEAD_DIM
        positions, active, rope = controls
        normal = norm(x, prefix + ".norm1", 1e-5)
        qkv = dense(normal, prefix + ".qkv")
        q = graph.buffer(prefix + ".q", (rows * width,), "float32")
        k = graph.buffer(prefix + ".k", (rows * width,), "float32")
        v = graph.buffer(prefix + ".v", (rows, width), "float32")
        p = dict(r=rows, h=heads, kh=heads, d=d)
        graph("qkv_split", p, qkv.view((rows * 3 * width,)), q, k, v)
        qr, kr = (
            graph.buffer(prefix + name, (rows, width), "float32")
            for name in (".qr", ".kr")
        )
        for source, out in ((q, qr), (k, kr)):
            graph(
                "head_rms_rotary",
                dict(p, capacity=rows, scale_heads=1, normalize=False),
                source.view((rows, width)),
                head_unit,
                rope,
                positions,
                out,
            )
        shape = (1, heads, rows, d)
        kc, vc = (
            graph.buffer(prefix + name, shape, "float16") for name in (".kc", ".vc")
        )
        params = dict(p, capacity=rows, chunk=rows, window=window, splits=1)
        graph("window_cache", params, kr, v, kc, vc, positions, active)
        parts = graph.buffer(prefix + ".parts", (rows * heads * (d + 2),), "float32")
        graph(
            "window_attention",
            dict(params, query_rows=4 if rows % 4 == 0 else 1, key_rows=32),
            qr,
            kc,
            vc,
            positions,
            active,
            parts,
        )
        flat = graph.buffer(prefix + ".attended", (rows * width,), "float32")
        graph("window_merge", params, parts, flat, active)
        projected = dense(flat.view((rows, width)), prefix + ".wo")
        h = add(x, projected, prefix + ".attn_residual", scale=prefix + ".attn_scale")
        z = norm(h, prefix + ".norm2", 1e-5)
        z = activated(dense(z, prefix + ".ffn1"), prefix + ".ffn_gelu", gelu=True)
        z = dense(z, prefix + ".ffn2")
        return add(h, z, prefix + ".ffn_residual", scale=prefix + ".ffn_scale")

    semantic = graph.buffer("semantic", (frames,), "int32", role="input")
    residual = graph.buffer(
        "residual_codes", (frames, config.codebooks - 1), "int32", role="input"
    )
    semantic_table = root + "sem.table"
    vocab, width = table[semantic_table].shape
    if vocab != config.codes:
        raise ValueError("ZONOS3 semantic codebook size differs from its audio head")
    embedded = graph.buffer("semantic_embedding", (frames * width,), "float32")
    graph(
        "embedding",
        dict(r=frames, c=width, v=vocab),
        semantic,
        weight(semantic_table),
        embedded,
    )
    x = activated(
        embedded.view((frames, width)), "semantic_input", bias=root + "sem.bias"
    )
    for block in range(4):
        x = convnext(x, root + f"sem.{block}")
    x = activated(
        dense(x, root + "sem.out"), "semantic_output", bias=root + "sem.out.bias"
    )
    latent = graph.buffer("latent", x.shape, "float32")
    graph(
        "codebook_residual",
        dict(r=frames, c=x.shape[1], groups=config.codebooks - 1, vocab=vocab),
        x,
        residual,
        weight(root + "res.table"),
        weight(root + "res.bias"),
        latent,
    )
    x = latent
    for stage, window in enumerate(STAGE_WINDOWS):
        prefix = root + f"stage.{stage}"
        x = dense(x, prefix + ".in")
        rows, width = x.shape
        controls = (
            graph.buffer(f"codec_positions.{rows}", (rows,), "int32", role="input"),
            graph.buffer(f"codec_active.{rows}", (rows,), "int32", role="input"),
            graph.buffer(
                f"codec_rope.{rows}", (rows, HEAD_DIM), "float32", role="input"
            ),
        )
        for block in range(2):
            x = attention(x, prefix + f".blk.{block}", window, controls)
        if stage + 1 < len(STAGE_WINDOWS):
            x = dense(x, prefix + ".out")
            shuffled = graph.buffer(
                prefix + ".upsampled", (2 * rows, width // 2), "float32"
            )
            graph("interleave_rows", dict(r=rows, c=width, factor=2), x, shuffled)
            x = shuffled
    for block in range(8):
        x = convnext(x, root + f"head.{block}")
    x = norm(x, root + "head.norm", 1e-6)
    activated(
        dense(x, root + "head.out"),
        "spectrum",
        bias=root + "head.out.bias",
        role="output",
    )
    return graph
