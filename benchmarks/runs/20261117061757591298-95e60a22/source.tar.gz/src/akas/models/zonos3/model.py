"""Compose ZONOS3-Mini embedding and projection stages over AKAS operations."""

from akas.graph import Graph
from akas.models.zonos3.synthesis import Synthesis
from akas.models.zonos3.weights import (
    CODEBOOK_EMBEDDING,
    CODEBOOK_HEAD,
    TOKEN_EMBEDDING,
    Zonos3MiniCheckpoint,
)


def compose(checkpoint, *, phase, rows=1, provider="webgpu", context=1024):
    """Declare a compiled forward stage using the GGUF pair's native storage."""
    if type(rows) is not int or rows < 1 or provider not in ("cuda", "webgpu"):
        raise ValueError("ZONOS3 requires positive row counts and CUDA or WebGPU")
    if phase == "backbone":
        from akas.models.zonos3._composition import compose_backbone

        return compose_backbone(
            checkpoint, rows=rows, context=context, provider=provider
        )
    if phase == "codec":
        from akas.models.zonos3.codec import compose_codec

        return compose_codec(checkpoint, frames=rows, provider=provider)
    config = checkpoint.config
    width = config.width
    code_count = config.codebooks * config.code_vocab
    graph = Graph(contract="reference")

    if phase in ("text_embedding", "audio_feedback"):
        is_audio = phase == "audio_feedback"
        count = rows * config.codebooks if is_audio else rows
        table = CODEBOOK_EMBEDDING if is_audio else TOKEN_EMBEDDING
        ids = graph.buffer("ids", (count,), "int32", role="input")
        weight = checkpoint.graph_weight(graph, table, provider=provider)
        embedded = graph.buffer("embedding", (count * width,), "float32", role="output")
        params = dict(r=count, c=width, v=code_count if is_audio else config.vocab)
        if not is_audio:
            params.update(ggml=True, type=8)
        graph("embedding", params, ids, weight, embedded)
    elif phase in ("gdn_input", "audio_head"):
        is_audio = phase == "audio_head"
        if not is_audio and not config.recurrent[0]:
            raise ValueError("ZONOS3's first layer is not recurrent")
        name = CODEBOOK_HEAD if is_audio else "blk.0.attn_qkv.weight"
        columns = code_count if is_audio else 3 * config.delta_width
        x = graph.buffer("hidden", (rows * width,), "float32", role="input")
        weight = checkpoint.graph_weight(graph, name, provider=provider)
        out = graph.buffer("projection", (rows * columns,), "float32", role="output")
        params = dict(r=rows, k=width, o=columns)
        if is_audio:
            params["optimized"] = True
        else:
            params.update(ggml=True, type=8, optimized=True)
        graph("linear", params, x, weight, out)
    else:
        raise ValueError(f"unknown ZONOS3 forward phase: {phase}")
    return graph


class Zonos3MiniSynthesis(Synthesis):
    """Declare the checkpoint, compiled phases, and runtime for ZONOS3-Mini."""

    checkpoint_type = Zonos3MiniCheckpoint
    compose = staticmethod(compose)
    forward_index = ("speech.json", "akas.speech-program.v1")

    @classmethod
    def forward_phases(
        cls,
        checkpoint,
        *,
        provider,
        context=1024,
        prefill_rows=64,
        codec_frames=(16, 32, 64, 128),
    ):
        if (
            type(prefill_rows) is not int
            or type(context) is not int
            or not 1 <= prefill_rows <= context
            or not codec_frames
            or any(type(n) is not int or n < 1 for n in codec_frames)
        ):
            raise ValueError("invalid ZONOS3 phase geometries")
        geometries = (
            ("codec", sorted(set(codec_frames))),
            ("backbone", sorted({1, prefill_rows})),
            ("audio_head", (1,)),
        )
        return dict(context=context), (
            (
                phase,
                rows,
                cls.compose(
                    checkpoint,
                    phase=phase,
                    rows=rows,
                    provider=provider,
                    context=context,
                ),
            )
            for phase, sizes in geometries
            for rows in sizes
        )
