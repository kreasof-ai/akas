"""Plot retained medians and ranges for selected H200 configurations."""
import argparse,json,statistics
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('build/h200'));a=p.parse_args()
c=json.loads((a.root/'comparison.json').read_text())
paths={**c['baselines'],'akas':c['selected']}
fig,axs=plt.subplots(1,3,figsize=(14,4.6),layout='constrained')
colors={'akas':'#167d8d','vllm':'#dd8c32','sglang':'#9467bd'}
for ax,(title,key) in zip(axs,[('Prefill','prefill_tokens_per_second'),('Decode','decode_tokens_per_second'),('Complete burst','output_tokens_per_second')]):
 for rt,path in paths.items():
  report=json.loads((a.root/path).read_text());rs=sorted(report['cases'],key=lambda r:r['batch'])
  x=[r['batch'] for r in rs];samples=[[s[key] for s in r['samples']] for r in rs]
  y=[statistics.median(v) for v in samples]
  ax.errorbar(x,y,yerr=[[m-min(v) for m,v in zip(y,samples)],[max(v)-m for m,v in zip(y,samples)]],label=rt.upper() if rt!='vllm' else 'vLLM',color=colors[rt],marker='o',capsize=3,lw=2)
 ax.set_xscale('log',base=4);ax.set_xticks([1,4,16,64,256],['1','4','16','64','256']);ax.set_xlabel('Concurrent requests');ax.set_ylabel('Aggregate tokens/s');ax.set_title(title);ax.grid(alpha=.2)
axs[0].legend(frameon=False)
fig.suptitle('LFM2.5-24B-A2B-FP8 · One H200 · Input 2048 / output 128\nMedian and observed range of 3 repetitions · matched streaming protocol',fontsize=13)
fig.savefig(a.root/'throughput.svg');fig.savefig(a.root/'throughput.png',dpi=180)
