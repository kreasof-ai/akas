"""Qualify generic Hopper tensor-map ABI support on independent GEMM operands."""

import json, ctypes as c
from pathlib import Path
import numpy as np
import tensor
from tools.h200_kernel_sweep import graph_timing


def run():
    report = {"protocol": "generic-tma-abi-v1", "cases": []}
    with tensor.Device() as device, device.load("/data/tma-probe.tbin") as kernel:
        report["device"] = device.info
        for seed in range(3):
            rng = np.random.default_rng(seed)
            a = (rng.normal(size=(128, 256)) * 0.25).astype("float16")
            b = (rng.normal(size=(128, 256)) * 0.25).astype("float16")
            expected = a.astype("float32") @ b.astype("float32").T
            x, w, out = (
                device.from_numpy(a),
                device.from_numpy(b),
                device.empty((128, 128), "float32"),
            )
            try:
                bound = kernel.bind(x, w, out)
                bound.launch()
                actual = out.to_numpy()
                np.testing.assert_allclose(actual, expected, rtol=2e-4, atol=2e-5)
                report["cases"].append(
                    {
                        "seed": seed,
                        "max_absolute_error": float(np.max(np.abs(actual - expected))),
                        "timing": graph_timing(device, bound.launch, lambda: None),
                    }
                )
            finally:
                for v in (x, w, out):
                    v.release()
    report["status"] = "passed"
    Path("/data/results/tma-qualification.json").write_text(
        json.dumps(report, indent=2)
    )
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    run()
