"""Fetch evidence files via the installed Modal CLI client's volume API."""
from pathlib import Path
import modal
v=modal.Volume.from_name('akas-h200-evidence')
for entry in v.listdir('/results',recursive=True):
    if entry.type.value != 1: continue
    dest=Path('build/h200')/entry.path
    if dest.exists() and dest.stat().st_size==entry.size: continue
    dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('wb') as stream:
        for chunk in v.read_file(entry.path): stream.write(chunk)
    print(dest,flush=True)
