"""Apply qualified same-ABI AOT winners and export exact producer selectors."""
import argparse,json,hashlib,shutil
from pathlib import Path
from tensor.artifacts.format import read_artifact
from tensor.compiler.search import ScheduleProfile
from akas.artifacts.read import read_program

def run(a):
    root=Path('build/h200');jobs={}
    for p in root.glob('sweep-*/sweep.json'):
        try:x=json.loads(p.read_text())
        except (ValueError,OSError):continue
        for j in x.get('jobs',[]):
            if j['status']=='compiled' and 'out' in j:
                old=jobs.get(j['id'])
                if not old or j.get('mapping') or not old.get('mapping'):jobs[j['id']]=j
    winners={}
    for path in a.results:
        report=json.loads(path.read_text())
        for group in report['groups']:
            w=group.get('winner')
            if not w or not w.get('correct') or w['seconds']>=group['baseline_seconds']*.98:continue
            key=(group['phase'],group['batch'],group['chunk'],group['key'])
            winners[key]=(group,w)
    shutil.copytree(a.program,a.out,dirs_exist_ok=True)
    p=json.loads((a.out/'program.json').read_text());profile=json.loads(a.profile.read_text());profile['target']='sm_90a';applied=[]
    for phase in p['phases']:
        fpath=a.out/phase['path'];f=json.loads(fpath.read_text());changed=False
        for key,record in f['kernels'].items():
            selection=winners.get((phase['phase'],phase['rows'],phase['chunk'],key))
            if not selection:continue
            group,w=selection;j=jobs[w['id']];src=Path(j['out'])/j['artifact']
            old,_=read_artifact(a.out/record['path']);new,_=read_artifact(src)
            abi=lambda m:[(v['name'],v['dtype'],v['shape']) for v in m['arguments']]
            if abi(old)!=abi(new):raise ValueError(f'ABI changed: {key}')
            dest=a.out/'overlays'/src.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(src,dest)
            source=Path(j['out'])/'sources'/f"{j['id']}.py"
            if source.exists():shutil.copy2(source,dest.with_suffix('.py'))
            record.update(path=str(dest.relative_to(a.out)),sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),schedule=w['schedule'])
            selector=dict(operation=group['kind'],parameters=group['parameters'],schedule=w['schedule'])
            profile['entries']=[e for e in profile['entries'] if not (e['operation']==selector['operation'] and e['parameters']==selector['parameters'])]
            profile['entries'].append(selector)
            applied.append(dict(phase=phase['phase'],batch=phase['rows'],chunk=phase['chunk'],kind=group['kind'],parameters=group['parameters'],schedule=w['schedule'],kernel_id=w['id'],gain=group['baseline_seconds']/w['seconds']))
            changed=True
        if changed:
            fpath.write_text(json.dumps(f,indent=2));phase['sha256']=hashlib.sha256(fpath.read_bytes()).hexdigest()
    (a.out/'program.json').write_text(json.dumps(p,indent=2));(a.out/'selected-schedules.json').write_text(json.dumps(profile,indent=2));(a.out/'selection.json').write_text(json.dumps(applied,indent=2))
    read_program(a.out)
    producer=ScheduleProfile(profile)
    for r in applied:
        assert producer.select(r['kind'],r['parameters'],provider='cuda',target='sm_90a')==r['schedule']
    print('Verified exact selectors and same ABI for',len(applied),'phase kernels')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--program',type=Path,default=Path('build/h200/fp8-small'));p.add_argument('--out',type=Path,required=True);p.add_argument('--profile',type=Path,default=Path('build/h200/fp8-small-schedules.json'));p.add_argument('results',type=Path,nargs='+');run(p.parse_args())
