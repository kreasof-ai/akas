"""Summarize retained H200 evidence; distinguish phase and complete-burst rates."""
import argparse, json, statistics, csv, hashlib
from pathlib import Path

def rows(report):
    return {r['batch']:r for r in report.get('cases',[]) if r.get('samples')}

def metric(row,key):
    return statistics.median(s[key] for s in row['samples'])

def analyze(root,selected):
    reports={}
    for p in sorted((root/'results').rglob('*.json')):
        try: x=json.loads(p.read_text())
        except (ValueError,OSError): continue
        if x.get('runtime') and x.get('cases') and all(s.get('phase_protocol')=='client-stream-burst-v1' for r in x['cases'] for s in r.get('samples',[])):
            reports[str(p.relative_to(root))]=x
    lock=json.loads((root/'BASELINE_LOCK.json').read_text())
    baseline={}
    for runtime,record in lock['baselines'].items():
        for metadata in record['files'].values():
            path=root/metadata['path']
            if hashlib.sha256(path.read_bytes()).hexdigest()!=metadata['sha256']:
                raise ValueError(f"Frozen baseline changed: {path}")
        path=record['files']['raw.json']['path']
        report=json.loads((root/path).read_text())
        if not all(s.get('phase_protocol')==lock['protocol'] for row in report['cases'] for s in row['samples']):
            raise ValueError('Frozen baseline timing protocol changed')
        baseline[runtime]=(path,report)
    candidates={p:r for p,r in reports.items() if r['runtime']=='akas'}
    if not baseline or not candidates: raise ValueError('Need baseline and AKAS evidence')
    chosen=next((p for p in candidates if selected in p),None)
    if not chosen: raise ValueError(f'No AKAS report matches {selected}')
    selected_report=candidates[chosen]
    profiles={k:rows(r) for k,(_,r) in baseline.items()}
    profiles['akas']=rows(selected_report)
    table=[]
    for batch in [1,4,16,64,256]:
        row=dict(concurrency=batch)
        for runtime,rs in profiles.items():
            if batch not in rs: continue
            for short,key in [('prefill','prefill_tokens_per_second'),('decode','decode_tokens_per_second'),('end_to_end','output_tokens_per_second'),('ttft','ttft_seconds')]:
                row[f'{runtime}_{short}']=metric(rs[batch],key)
        for phase in ['prefill','decode','end_to_end']:
            fastest=max(row.get(f'{rt}_{phase}',0) for rt in baseline)
            if fastest and f'akas_{phase}' in row: row[f'{phase}_improvement_percent']=100*(row[f'akas_{phase}']/fastest-1)
        table.append(row)
    checks={}
    for rt,(path,ref) in baseline.items():
        probes=ref.get('reference_probes',[])
        actual=selected_report.get('reference_probes',[])
        if len(probes)==len(actual) and probes:
            assert all(a['input_ids']==b['input_ids'] for a,b in zip(probes,actual))
            checks[rt]=dict(probes=len(probes),first_token_agreement=sum(a['output_ids'][0]==b['output_ids'][0] for a,b in zip(probes,actual)),
                full_sequence_agreement=sum(a['output_ids']==b['output_ids'] for a,b in zip(probes,actual)),
                matched_tokens=sum(sum(x==y for x,y in zip(a['output_ids'],b['output_ids'])) for a,b in zip(probes,actual)))
    result=dict(selected=chosen,baselines={k:p for k,(p,_) in baseline.items()},table=table,qualification=checks,
                baseline_unstable_shapes={k:[row['batch'] for row in r.get('cases',[]) if not row.get('deterministic',True)] for k,(_,r) in baseline.items()},
                candidates=list(candidates),cost_ledger=json.loads((root/'cost-ledger.json').read_text()))
    (root/'comparison.json').write_text(json.dumps(result,indent=2))
    with (root/'comparison.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for row in table for k in row)))
        w.writeheader();w.writerows(table)
    achieved=all(row.get('end_to_end_improvement_percent',-100)>=10 for row in table)
    outcome='The 10% complete-burst throughput target was achieved at every measured concurrency.' if achieved else 'The 10–30% throughput-lead target was not achieved against the tuned baselines.'
    lines=['# LFM2.5-24B-A2B-FP8 on one Modal H200','',f'**Outcome: {outcome}**','',
        '2,048 input tokens and exactly 128 output tokens per request. One warmup and three retained repetitions; medians below. Original checkpoint revision `f54bf39547fd5b7955abb9fe8d1b151e31fbbddb`. Pure autoregressive greedy generation, no prefix reuse, no early EOS or speculative decoding. AKAS FP16 KV; baselines BF16 KV.', '',
        'All engines use `client-stream-burst-v1`. Prefill = C×2048 / maximum observed TTFT; decode = C×127 / maximum request decode interval. End-to-end = C×128 / completed burst wall time. These are distinct metrics; phase gains do not imply equal complete-burst gains. Compilation, loading and language probes are untimed.', '',
        '| C | AKAS prefill | vLLM prefill | SGLang prefill | AKAS decode | vLLM decode | SGLang decode | Prefill gain | Decode gain |',
        '|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for r in table:
        keys=['akas_prefill','vllm_prefill','sglang_prefill','akas_decode','vllm_decode','sglang_decode']
        lines.append('| '+str(r['concurrency'])+' | '+' | '.join(f"{r.get(k,0):,.1f}" for k in keys)+f" | {r.get('prefill_improvement_percent',0):+.1f}% | {r.get('decode_improvement_percent',0):+.1f}% |")
    lines += ['', 'Gains compare against the faster baseline separately at each concurrency. Rates are aggregate tokens/second.', '',
        '| C | AKAS complete burst tok/s | vLLM | SGLang | Gain |','|---:|---:|---:|---:|---:|']
    for r in table:
        lines.append('| '+str(r['concurrency'])+' | '+' | '.join(f"{r.get(k+'_end_to_end',0):,.1f}" for k in ['akas','vllm','sglang'])+f" | {r.get('end_to_end_improvement_percent',0):+.1f}% |")
    lines += ['', '## Output checks', '', 'Untimed BOS-prefixed language probes use identical IDs. First-token agreement is a limited check, not an accuracy evaluation. Full autoregressive sequences can diverge with FP8 rounding and different 16-bit KV formats.', '', '```json',json.dumps(checks,indent=2),'```','',f"Baseline shapes with different greedy sequences across repetitions: {result['baseline_unstable_shapes']}. These timings remain visible; output counts are checked separately. The raw records label those cases failed for determinism.",'', '## Evidence', '', f'Selected AKAS: [{chosen}]({chosen}).']
    for rt,(p,_) in baseline.items(): lines.append(f'- {rt}: [{p}]({p})')
    lines += ['', 'Raw records retain all repetitions, output IDs, per-token arrival timestamps, delivery chunk sizes and runtime settings. Worker logs retain cold-start diagnostics. `comparison.csv` and `comparison.json` contain portable summary data.', '',
        '## Cost', '', f"Conservative campaign cost estimate/reservations: ${sum(r['conservative_usd'] for r in result['cost_ledger']):.2f}; see [cost ledger](cost-ledger.json). This is not an account billing reading. List prices: H200 $0.001261/s, CPU $0.0000131/core/s, RAM $0.00000222/GiB/s ([Modal pricing](https://modal.com/pricing)). Single GPU jobs, 4 CPU cores, 64 GiB memory, two-second idle shutdown. Offline compilation uses the local machine."]
    (root/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('build/h200'));p.add_argument('--selected',default='akas-l40s-')
    a=p.parse_args();analyze(a.root,a.selected)
