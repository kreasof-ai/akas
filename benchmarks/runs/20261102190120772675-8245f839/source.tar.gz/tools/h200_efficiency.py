"""Algorithmic MFU and traffic estimates, never hardware-counter measurements."""
import argparse,json,math,statistics
from pathlib import Path

DTYPE_BYTES={'float32':4,'float16':2,'bfloat16':2,'uint8':1,'int32':4}
L40S_PREFILL=[26018.8,31975.3,31990.3,31888.5,31797.5]
L40S_DECODE=[140.2,201.2,722.5,1627.9,3698.0]

def analyze(raw,program):
    r=json.loads(raw.read_text());c=r['program']['config']
    width,heads,kv,d=c['width'],c['heads'],c['kv_heads'],c['width']//c['heads']
    attention=c['layers'].count('attention');convolution=c['layers'].count('conv')
    dense=c['dense_layers'];moe=len(c['layers'])-dense
    fp8_params=attention*(width*(heads+2*kv)*d+width*width)+dense*3*width*c['ff']+moe*c['top_k']*3*width*c['expert_width']
    half_params=convolution*4*width*width
    router_params=moe*width*c['experts']
    n=2048
    # Useful causal QK/PV pairs. Ignore padding, elementwise ops, quantization and lookups.
    f8=2*n*fp8_params
    f16=2*n*half_params+2*width*c['vocab']+4*attention*heads*d*n*(n+1)//2
    f32=2*n*router_params
    h200_ideal=f8/1.979e15+f16/.9895e15+f32/66.9e12
    l40s_ideal=f8/733e12+f16/366.5e12+f32/91.6e12
    manifest=json.loads((program/'program.json').read_text())
    phase=next(p for p in manifest['phases'] if p['phase']=='decode' and p['rows']==1)
    buffers=json.loads((program/phase['path']).read_text())['forward']['buffers']
    dense_bytes=0;expert_bytes={}
    for b in buffers:
        if b.get('role')!='weight' or b.get('alias_of'): continue
        size=math.prod(b['shape'])*DTYPE_BYTES[b['dtype']]
        if '_exps.weight' in b['name']:
            layer='.'.join(b['name'].split('.')[:2]);expert_bytes[layer]=expert_bytes.get(layer,0)+size/c['experts']
        else: dense_bytes+=size
    out=[]
    for i,row in enumerate(r['cases']):
        if not row.get('samples'): continue
        batch=row['batch'];p=statistics.median(s['prefill_tokens_per_second'] for s in row['samples']);dec=statistics.median(s['decode_tokens_per_second'] for s in row['samples'])
        # Uniform independent requests, without replacement inside top-k. Same model on both GPUs.
        expected=c['experts']*(1-(1-c['top_k']/c['experts'])**batch)
        kv_bytes=batch*2*attention*kv*d*2*(2048+63)
        model_bytes=dense_bytes+sum(expert_bytes.values())*expected+kv_bytes
        result=dict(concurrency=batch,estimated_mixed_prefill_mfu_percent=100*h200_ideal*p/n,
            l40s_reference_mixed_prefill_mfu_percent=100*l40s_ideal*L40S_PREFILL[i]/n,
            uniform_model_traffic_bytes_per_decode_step=model_bytes,
            estimated_uniform_decode_mbu_percent=100*model_bytes*dec/batch/4.8e12,
            l40s_reference_uniform_decode_mbu_percent=100*model_bytes*L40S_DECODE[i]/batch/864e9,
            prefill_tok_s_for_l40s_mfu=L40S_PREFILL[i]*l40s_ideal/h200_ideal,
            decode_tok_s_for_l40s_mbu=L40S_DECODE[i]*4.8e12/864e9)
        snapshot=r.get('routing_snapshots',{}).get(str(batch),{})
        if snapshot:
            unique={'.'.join(name.split('.')[:2]):len(set(t for tokens in ids for t in tokens)) for name,ids in snapshot.items()}
            traffic=dense_bytes+sum(expert_bytes[layer]*count for layer,count in unique.items())+kv_bytes
            result.update(observed_first_decode_unique_experts=unique,snapshot_model_traffic_bytes=traffic,
                          estimated_snapshot_decode_mbu_percent=100*traffic*dec/batch/4.8e12)
        out.append(result)
    payload=dict(method=__doc__,flops_per_prefill=dict(fp8=f8,fp16=f16,fp32=f32),dense_weight_bytes=dense_bytes,rows=out,
        assumptions=['Mixed MFU is ideal useful math time divided by observed phase time, weighted by arithmetic peak.',
        'H200 dense FP8 1979 TF/s, FP16 989.5 TF/s, FP32 66.9 TF/s; L40S 733/366.5/91.6 TF/s. No sparsity multiplier.',
        'Model traffic counts one read of unique weights plus 16-bit KV reads at mean decode position 2111. It omits activation, scratch, repeated tile loads and cache effects.',
        'Uniform MBU assumes independent uniform expert choices; snapshot MBU uses one retained real decode routing snapshot. Neither is measured HBM traffic.',
        'L40S reference rates come from the repository November 1 showcase; these are historical measurements, not rerun in this campaign.'],
        sources=['https://www.nvidia.com/en-us/data-center/h200/','https://www.nvidia.com/en-us/data-center/l40s/'])
    return payload

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('raw',type=Path);p.add_argument('--program',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();result=analyze(a.raw,a.program);a.out.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
