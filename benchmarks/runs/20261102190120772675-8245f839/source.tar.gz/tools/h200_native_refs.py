"""GPU-event baseline phases, with isolated prefill and full-C AR decode windows."""

import argparse, asyncio, json, hashlib, statistics, os, time
from pathlib import Path
from tools.baselines.common import synthetic_prompts


async def benchmark(runtime, out):
    prefix = 2048
    report = {"protocol": "gpu-execution-intervals-v1", "runtime": runtime, "cases": []}
    control = Path(os.environ["AKAS_GPU_EVENT_CONTROL"])
    out.mkdir(parents=True, exist_ok=True)
    vocab = json.load(open("/data/checkpoint/config.json"))["vocab_size"]
    if runtime == "vllm":
        from vllm import SamplingParams
        from vllm.engine.arg_utils import AsyncEngineArgs
        from vllm.v1.engine.async_llm import AsyncLLM
        import vllm

        settings = dict(
            model="/data/checkpoint",
            dtype="bfloat16",
            max_model_len=2176,
            max_num_seqs=256,
            max_num_batched_tokens=8192,
            gpu_memory_utilization=0.85,
            enforce_eager=False,
            enable_prefix_caching=False,
            skip_tokenizer_init=True,
            seed=17,
            compilation_config=dict(cudagraph_capture_sizes=[1, 4, 16, 64, 256]),
        )
        engine = AsyncLLM.from_engine_args(AsyncEngineArgs(**settings))
        report["version"] = vllm.__version__

        async def generate(ids, count, rid):
            params = SamplingParams(
                temperature=0, max_tokens=count, ignore_eos=True, detokenize=False
            )
            result = []
            async for row in engine.generate(dict(prompt_token_ids=ids), params, rid):
                result = list(row.outputs[0].token_ids)
            return result

        def close():
            engine.shutdown()

    else:
        import sglang

        settings = dict(
            model_path="/data/checkpoint",
            dtype="bfloat16",
            context_length=2184,
            max_running_requests=256,
            chunked_prefill_size=8192,
            mem_fraction_static=0.85,
            disable_cuda_graph=False,
            cuda_graph_bs_decode=[1, 4, 16, 64, 256],
            disable_radix_cache=True,
            skip_tokenizer_init=True,
            random_seed=17,
            log_level="warning",
            stream_interval=1,
        )
        engine = sglang.Engine(**settings)
        report["version"] = sglang.__version__

        async def generate(ids, count, rid):
            result = await engine.async_generate(
                input_ids=ids,
                sampling_params=dict(
                    temperature=0, max_new_tokens=count, ignore_eos=True
                ),
                stream=False,
            )
            return list(result["output_ids"])

        def close():
            engine.shutdown()

    report["settings"] = settings

    def save():
        (out / "requests.json").write_text(json.dumps(report, indent=2))

    try:
        for mode, count in [("prefill", 1), ("ar", 128)]:
            for b in [1, 4, 16, 64, 256]:
                prompts = synthetic_prompts(vocab, b, prefix)
                for rep in [-1, 0, 1, 2]:
                    ctx = dict(mode=mode, batch=b, rep=rep, prefix=prefix, output=count)
                    temp = control.with_suffix(".tmp")
                    temp.write_text(json.dumps(ctx))
                    temp.replace(control)
                    outputs = await asyncio.gather(
                        *(
                            generate(ids, count, f"native-{mode}-c{b}-r{rep}-q{i}")
                            for i, ids in enumerate(prompts)
                        )
                    )
                    assert len(outputs) == b and all(
                        len(row) == count for row in outputs
                    )
                    report["cases"].append(
                        {
                            **ctx,
                            "output_count": True,
                            "output_sha256": hashlib.sha256(
                                json.dumps(outputs).encode()
                            ).hexdigest(),
                            "first_tokens": [row[0] for row in outputs],
                            "last_tokens": [row[-1] for row in outputs],
                        }
                    )
                    save()
                    print("NATIVE_REFERENCE", runtime, mode, b, rep, flush=True)
        ctx = dict(mode="drain", batch=1, rep=-2, prefix=prefix, output=1)
        temp = control.with_suffix(".tmp")
        temp.write_text(json.dumps(ctx))
        temp.replace(control)
        await generate(synthetic_prompts(vocab, 1, prefix)[0], 1, "native-drain")
    finally:
        close()
        control.unlink(missing_ok=True)
    records = []
    for path in out.glob("events-*.jsonl"):
        records.extend(json.loads(line) for line in path.read_text().splitlines())
    report["hook_modules"] = sorted(
        {x["module"] for x in records if x.get("type") == "hook_installed"}
    )
    events = [x for x in records if "gpu_seconds" in x]
    report["gpu_event_cases"] = []
    for b in [1, 4, 16, 64, 256]:
        samples = []
        for rep in [0, 1, 2]:
            pre = [
                x
                for x in events
                if x["batch"] == b and x["rep"] == rep and x["mode"] == "prefill"
            ]
            dec = [
                x
                for x in events
                if x["batch"] == b
                and x["rep"] == rep
                and x["mode"] == "ar"
                and x["pure_decode"]
                and x["num_requests"] == b
            ]
            forward = lambda rows: [
                x for x in rows if x["stage"] in ("forward", "forward_sampling")
            ]
            tokens = sum(x["prefix_tokens"] for x in forward(pre))
            steps = len(forward(dec))
            assert tokens == b * prefix, (
                runtime,
                b,
                rep,
                "prefill token count",
                tokens,
            )
            assert steps >= 8, (
                runtime,
                b,
                rep,
                "too few full-C GPU decode intervals",
                steps,
            )
            if runtime == "vllm":
                assert sum(x["stage"] == "sampling" for x in dec) == steps
            ps = sum(x["gpu_seconds"] for x in pre)
            ds = sum(x["gpu_seconds"] for x in dec)
            samples.append(
                dict(
                    rep=rep,
                    prefill_gpu_seconds=ps,
                    prefill_tokens=tokens,
                    prefill_tokens_per_second=tokens / ps,
                    decode_gpu_seconds=ds,
                    decode_steps=steps,
                    decode_tokens=steps * b,
                    decode_tokens_per_second=steps * b / ds,
                )
            )
        report["gpu_event_cases"].append(dict(batch=b, samples=samples))
        print(
            "GPU_REFERENCE",
            runtime,
            b,
            round(statistics.median(x["prefill_tokens_per_second"] for x in samples)),
            round(statistics.median(x["decode_tokens_per_second"] for x in samples)),
            flush=True,
        )
    report["status"] = "passed"
    (out / "summary.json").write_text(json.dumps(report, indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--runtime", choices=["vllm", "sglang"], required=True)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    asyncio.run(benchmark(a.runtime, a.out))
