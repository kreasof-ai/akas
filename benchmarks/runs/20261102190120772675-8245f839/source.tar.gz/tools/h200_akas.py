"""Compile H200 programs offline, then measure matched autoregressive bursts."""
import argparse, asyncio, json, time, os, hashlib, subprocess
from pathlib import Path
from datetime import datetime, timezone

BATCHES = [1,4,16,64,256]
def compile_program(args):
    from akas.compilation import compile_checkpoint
    from akas.models.lfm2 import LFM2MoE
    from tensor.compiler.search import ScheduleProfile
    profile = json.loads(args.schedules.read_text()) if args.schedules else None
    if profile:
        profile['target'] = args.target
    geometries = [(b,1) for b in BATCHES]
    geometries += [(b,2048) for b in args.prefill_batches]
    start=time.monotonic()
    compile_checkpoint(LFM2MoE,args.checkpoint,args.program,checkpoint_options={'tokenizer':False},
        geometries=geometries,max_requests=256,max_context=2176,target=args.target,
        model_options={}, search=False,
        policy=json.loads(args.policy.read_text()), schedules=ScheduleProfile(profile) if profile else None)
    (args.program/'build.json').write_text(json.dumps(dict(seconds=time.monotonic()-start, arguments=vars(args)),default=str,indent=2))

def measure(args):
    import tensor
    from akas import Engine,EngineConfig
    from akas.models.lfm2 import LFM2MoE
    from akas.benchmarking.streaming import engine_burst
    from tools.baselines.common import measurements
    import tools.baselines.common as common
    common._output=args.out
    args.out.parent.mkdir(parents=True,exist_ok=True)
    config=dict(prefill_chunk=2048,prefill_requests=256,prefill_token_budget=256*2048,decode_prefill_token_budget=256)
    report=dict(runtime='akas',started_at=datetime.now(timezone.utc).isoformat(),cases=[],
        program_sha256=hashlib.sha256((args.program/'program.json').read_bytes()).hexdigest(),
        engine_config=config,program=json.loads((args.program/'program.json').read_text()),
        gpu=subprocess.check_output(['nvidia-smi','-q'],text=True))
    with tensor.Device() as device:
        report['device']=device.info
        print('LOAD',device.info,flush=True)
        with Engine.from_checkpoint(LFM2MoE,args.checkpoint,args.program,device,
                config=EngineConfig(**config),checkpoint_options={'tokenizer':False}) as engine:
            from tools.baselines.common import synthetic_prompts
            def invoke(batch,prefix):
                return asyncio.run(engine_burst(engine,synthetic_prompts(engine.model.config.vocab,batch,prefix),128))
            measurements(dict(shapes=[[b,2048] for b in args.batches],output_tokens=128,warmup=1,repeats=args.repeats),invoke,report)
            # Separate natural language demonstration, outside benchmark timings.
            from akas.text.tokenizer import Tokenizer
            tok=Tokenizer.from_pretrained(args.checkpoint)
            texts=['The capital of France is', 'One plus one equals',
                'The largest planet in the solar system is', 'Water freezes at',
                'A simple Python function to add two numbers:\n', 'The opposite of hot is',
                'The first three prime numbers are', 'The chemical symbol for gold is']
            report['reference_probes']=[]
            for text in texts:
                prompt=tok.encode(text,add_bos=True)
                result,_=asyncio.run(engine_burst(engine,[prompt],128))
                report['reference_probes'].append(dict(input_ids=prompt,output_ids=result[0],text=tok.decode(result[0])))
            common.save(report)
            text='The capital of France is'
            ids=tok.encode(text,add_bos=True)
            generated,_=asyncio.run(engine_burst(engine,[ids],32))
            report['demonstration']=dict(prompt=text,input_ids=ids,output_ids=generated[0],text=tok.decode(generated[0]))
            print('DEMONSTRATION',report['demonstration'],flush=True)
            common.save(report)
            if args.profile:
                from tools.cuda_profile import phase_profile
                import torch
                torch.cuda.init()
                report['routing_snapshots']={}
                for batch,chunk,position in [(1,1,2048),(4,1,2048),(16,1,2048),(64,1,2048),(256,1,2048),(4,2048,0)]:
                    options=argparse.Namespace(batch=batch,chunk=chunk,position=position,
                        samples=2,captured=True,counter_range=False,observe=[],
                        program=args.program,out=args.out.with_name(args.out.stem+f'-profile-b{batch}-t{chunk}.json'))
                    phase_profile(engine.model,options)
                    if chunk==1:
                        frame=engine.model.batch(batch,chunk)
                        report['routing_snapshots'][str(batch)]={
                            name:buffer.to_numpy().tolist()
                            for name,buffer in frame.forward.buffers.items() if name.endswith('.moe.ids')}
                        common.save(report)
    report['completed_at']=datetime.now(timezone.utc).isoformat()
    report['status']='passed' if all(row['status']=='passed' for row in report['cases']) else 'failed'
    common.save(report)
    if report['status']!='passed':
        raise SystemExit(1)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['compile','measure'])
    p.add_argument('--checkpoint',type=Path,default=Path('/data/checkpoint'))
    p.add_argument('--program',type=Path,required=True);p.add_argument('--out',type=Path)
    p.add_argument('--policy',type=Path);p.add_argument('--schedules',type=Path)
    p.add_argument('--target',default='sm_90a');p.add_argument('--repeats',type=int,default=3)
    p.add_argument('--prefill-batches',type=int,nargs='+',default=[1,4])
    p.add_argument('--batches',type=int,nargs='+',default=BATCHES)
    p.add_argument('--profile',action='store_true')
    a=p.parse_args(); compile_program(a) if a.action=='compile' else measure(a)
