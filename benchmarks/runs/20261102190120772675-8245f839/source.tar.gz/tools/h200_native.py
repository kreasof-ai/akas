"""Fixed-concurrency GPU phases, with autoregressive device token feedback."""
import argparse,json,time,ctypes as c,statistics,hashlib
from pathlib import Path

def elapsed(device,callback):
    begin,end=c.c_void_p(),c.c_void_p()
    device.driver.call('cuEventCreate',c.byref(begin),0);device.driver.call('cuEventCreate',c.byref(end),0)
    try:
        device.synchronize();device.driver.call('cuEventRecord',begin,device.stream)
        result=callback()
        device.driver.call('cuEventRecord',end,device.stream);device.driver.call('cuEventSynchronize',end)
        ms=c.c_float();device.driver.call('cuEventElapsedTime',c.byref(ms),begin,end)
        return result,ms.value/1000
    finally:
        device.driver.call('cuEventDestroy',begin);device.driver.call('cuEventDestroy',end)

def run(a):
    import tensor
    from akas.models.lfm2 import LFM2MoE
    from akas.benchmarking.session import Session
    from tools.baselines.common import synthetic_prompts
    report=dict(protocol='native-gpu-prefill-ar127-v1',runtime='akas',cases=[],
        program_sha256=hashlib.sha256((a.program/'program.json').read_bytes()).hexdigest(),program=json.loads((a.program/'program.json').read_text()))
    def save():a.out.write_text(json.dumps(report,indent=2))
    with tensor.Device() as device,LFM2MoE(a.checkpoint,a.program,device,checkpoint_options={'tokenizer':False}) as model:
        report['device']=device.info;save()
        if a.profile_only:
            import torch
            from tools.cuda_profile import phase_profile
            torch.cuda.init()
            for b,t,pos in [(1,1,2048),(4,1,2048),(16,1,2048),(64,1,2048),(256,1,2048),(4,2048,0)]:
                phase_profile(model,argparse.Namespace(batch=b,chunk=t,position=pos,samples=2,
                    captured=True,counter_range=False,observe=[],program=a.program,
                    out=a.out.with_name(a.out.stem+f'-profile-b{b}-t{t}.json')))
            return
        for b in a.batches:
            prompts=synthetic_prompts(model.config.vocab,b,2048);samples=[]
            for rep in range(a.repeats+1):
                with Session(model,batch=b,chunk=2048) as session:
                    session.reset()
                    first,prefill=elapsed(device,lambda:session.prefill(prompts))
                    _,decode=elapsed(device,lambda:session.decode(127,read=False))
                    last=session.executor.last_frame.buffers[session.executor.last_frame.prediction].to_numpy()[:b].astype(int).tolist()
                    assert all(model.positions[slot]==2175 for slot in session.slots)
                    if rep:
                        samples.append(dict(prefill_seconds=prefill,decode_seconds=decode,
                            prefill_tokens_per_second=b*2048/prefill,decode_tokens_per_second=b*127/decode,
                            first_tokens=first,last_tokens=last))
                print('NATIVE',b,rep,round(b*2048/prefill),round(b*127/decode),flush=True)
            row=dict(batch=b,prefix=2048,output=128,samples=samples,
                deterministic=all(s['last_tokens']==samples[0]['last_tokens'] for s in samples))
            report['cases'].append(row);save()
    report['status']='passed' if all(x['deterministic'] for x in report['cases']) else 'failed';save()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--program',type=Path,required=True);p.add_argument('--checkpoint',type=Path,default=Path('/data/checkpoint'));p.add_argument('--out',type=Path,required=True);p.add_argument('--repeats',type=int,default=3);p.add_argument('--profile-only',action='store_true');p.add_argument('--batches',type=int,nargs='+',default=[1,4,16,64,256]);run(p.parse_args())
