"""passes components."""
