"""Contracts and implementation choices for residual."""

from akas.kernels.contracts import OutputABI
from akas.kernels.contracts import Implementation
from akas.ops.residual.validation import validation


def lower(graph, commit, settings, *, provider, target):
    """Choose private residual storage independently from FP32 arithmetic."""
    from dataclasses import replace

    if set(settings) - {"intermediate_dtype"}:
        raise ValueError("unknown residual policy")
    dtype = settings.get("intermediate_dtype", "float32")
    if dtype not in ("float32", "float16", "bfloat16"):
        raise ValueError("invalid residual intermediate dtype")
    if dtype == "float32":
        return graph, commit
    if graph.contract != "reference":
        raise ValueError("private residual storage requires the reference contract")

    fields = {"add": ("x", "y", "out"), "rms": ("x", "w", "out"),
              "add_rms": ("x", "mixed", "residual", "w", "out"),
              "chunk_last": ("x", "out", "lengths")}

    def bindings(call):
        if call.bindings:
            return dict(call.bindings)
        names = fields.get(call.kind, ())
        return dict(zip(names, call.arguments)) if len(names) == len(call.arguments) else {}

    families, exposed = graph.storage_families(), graph.exposed_buffers()
    chosen = set()
    for index, call in enumerate(graph.calls):
        names = bindings(call)
        output_key = "residual" if call.kind == "add_rms" else "out"
        if call.kind not in ("add", "add_rms") or set(names) != set(fields[call.kind]):
            continue
        family = families[graph.storage_owner(names[output_key])]
        if family & exposed or any(graph.buffers[name].dtype != "float32" for name in family):
            continue
        eligible = True
        for user_index, user in enumerate(graph.calls):
            referenced = family.intersection((*user.arguments, *user.bindings.values()))
            if not referenced:
                continue
            inputs = bindings(user)
            allowed = ({"x", "y"} if user.kind == "add" else
                       {"x", "mixed"} if user.kind == "add_rms" else {"x"})
            if (user_index == index and any(value in family for key, value in inputs.items() if key != output_key)
                    or user_index != index and (user_index <= index or user.kind not in fields
                        or any(value in family and key not in allowed for key, value in inputs.items())
                        or not referenced <= set(inputs.values()))):
                eligible = False
                break
        if eligible:
            chosen.update(family)
    for name in chosen:
        value = replace(graph.buffers[name], dtype=dtype)
        object.__setattr__(value, "_graph", graph)
        graph.buffers[name] = value
    calls = []
    for call in graph.calls:
        names = bindings(call)
        if not chosen.intersection(names.values()):
            calls.append(call)
            continue
        p = dict(call.parameters)
        p.update(input_dtype=graph.buffers[names["x"]].dtype,
                 output_dtype=graph.buffers[names["out"]].dtype)
        if call.kind == "add":
            p["other_dtype"] = graph.buffers[names["y"]].dtype
        elif call.kind == "add_rms":
            p.update(mixed_dtype=graph.buffers[names["mixed"]].dtype,
                     residual_dtype=graph.buffers[names["residual"]].dtype)
        calls.append(replace(call, parameters=p))
    graph.calls = calls
    return graph, commit


OUTPUT_ARGUMENTS = {"reference": {"add": (-1,)}}
for _contract in ("reference", "packed", "packed-baseline", "bf16", "block-fp8"):
    OUTPUT_ARGUMENTS.setdefault(_contract, {}).update(
        {"add": OutputABI((-1,), ("out",))}
    )
VALIDATIONS = {"add": validation}
IMPLEMENTATIONS = (
    Implementation(
        "add",
        "akas.ops.residual.kernel",
        "packed-baseline",
        factory="add",
        name="residual.kernel",
    ),
    Implementation(
        "add",
        "akas.ops.residual.kernel",
        "packed",
        priority=0,
        factory="add",
        name="residual.kernel",
    ),
    Implementation(
        "add",
        "akas.ops.residual.kernel",
        "packed",
        provider="webgpu",
        priority=0,
        factory="add",
        name="residual.kernel",
    ),
    Implementation(
        "add",
        "akas.ops.residual.kernel",
        "reference",
        factory="add",
        name="residual.kernel",
    ),
    Implementation(
        "add",
        "akas.ops.residual.kernel",
        "reference",
        provider="webgpu",
        factory="add",
        name="residual.kernel",
    ),
)
