"""Shared FP8 weights access and standalone dequantization."""


def reader(shape, *, provider, scale_layout="block", storage_layout="raw"):
    from akas.quantization._shared.fp8 import reader

    if scale_layout == "channel":
        return channel_reader(shape, provider=provider)
    return reader(shape, role="weights", provider=provider, storage_layout=storage_layout)


def channel_reader(shape, *, provider):
    """Read E4M3 bytes with one BF16 scale per output channel."""
    import tilelang.language as T

    if provider != "cuda" or len(shape) != 2:
        raise ValueError("channel-scaled FP8 currently requires a CUDA matrix")

    @T.macro
    def read(encoded, row, column):
        return T.call_extern(
            "float32", "tensor_decode_e4m3", T.cast(encoded[0][row, column], "uint32")
        ) * T.cast(encoded[1][row, 0], "float32")

    return read


def dequantize(spec, schedule, *, provider):
    from akas.quantization._shared.fp8 import dequantize

    return dequantize(spec, schedule, role="weights", provider=provider)


def prepare_host(bits, scales, *, provider, storage_layout="raw"):
    """Pack finite E4M3 bytes and preserve the representation's BF16 scales.

    ``bits`` has its logical matrix/expert shape; ``scales`` contains numerical
    floating-point values, not raw BF16 bytes. Returned arrays follow the named
    storage buffers and can be uploaded using each BufferSpec's dtype.
    """
    import numpy as np
    from tensor.runtime.dtypes import encode_bfloat16, decode_bfloat16
    from akas.quantization._shared.packing import pack_words
    from .definition import FORMAT

    bits = np.ascontiguousarray(bits, dtype="uint8")
    storage = FORMAT.storage(bits.shape, provider=provider, **(dict(storage_layout=storage_layout) if provider == "cuda" else {}))
    if provider != "cuda" and storage_layout != "raw":
        raise ValueError("blocked FP8 storage currently requires CUDA")
    if np.any((bits & 127) == 127):
        raise ValueError("resident FP8 storage must be finite")
    scales = np.asarray(scales, dtype="float32")
    if scales.shape != storage.named["scales"].shape:
        raise ValueError("FP8 scales differ from the declared block layout")
    scales = decode_bfloat16(encode_bfloat16(scales))
    values = (
        pack_words(bits).reshape(storage.values.shape)
        if provider == "webgpu"
        else bits.copy()
    )
    if storage_layout == "block128":
        rows, depth = bits.shape[-2:]
        values = np.ascontiguousarray(bits.reshape(*bits.shape[:-2], rows // 128, 128, depth // 128, 128).swapaxes(-3, -2))
    return dict(values=values, scales=scales)


def restore_host(values, shape, *, provider="cuda", storage_layout="raw"):
    """Restore logical byte order from the declared physical weight layout."""
    import numpy as np
    from .definition import FORMAT

    if provider != "cuda":
        raise ValueError("host FP8 layout restoration currently requires CUDA")
    storage = FORMAT.storage(shape, provider=provider, storage_layout=storage_layout)
    values = np.asarray(values, dtype="uint8")
    if values.shape != storage.values.shape:
        raise ValueError("FP8 values differ from the declared physical layout")
    if storage_layout == "block128":
        values = values.swapaxes(-3, -2)
    return np.ascontiguousarray(values.reshape(shape))
