"""Block-scaled operands declare rounding before an FP32 MMA accumulation."""
import os
import pytest
from test_lfm_moe_native import test_native_operations_match_independent_references as check_operation


@pytest.mark.skipif(os.getenv("AKAS_LFM_FP8_CUDA") != "1", reason="CUDA scaled expert qualification")
@pytest.mark.parametrize("kind,parameters", [
    ("expert_partial", dict(r=1, rows=1, k=384, o=256, experts=7, top=3, partitions=1,
        compact=True, tile_map=True, block_m=16, columns=64, threads=128, stages=1,
        activation_vector=16, routed_input=True, dequantize_dtype="float16")),
    ("expert_partial", dict(r=33, rows=33, k=768, o=256, experts=7, top=3, partitions=3,
        compact=True, tile_map=True, block_m=32, columns=128, threads=128, stages=2,
        activation_vector=16, dequantize_dtype="bfloat16")),
    ("fp8_expert_swiglu", dict(r=33, rows=33, k=384, o=256, experts=7, top=3, partitions=1,
        compact=True, tile_map=True, block_m=32, threads=128, stages=1, activation_vector=16,
        pair_layout="wide", product_dtype="bfloat16", activation_dtype="bfloat16", dequantize_dtype="float16")),
    ("expert_swiglu", dict(r=4, rows=4, k=384, o=256, experts=7, top=3, partitions=1,
        compact=True, tile_map=True, block_m=16, columns=64, threads=128, stages=1, activation_vector=16,
        pair_layout="separate", input_dtype="uint8", weight_format="fp8", output_dtype="bfloat16",
        product_dtype="bfloat16", activation_dtype="bfloat16", dequantize_dtype="bfloat16")),
])
def test_scaled_expert_operations_match_declared_rounding(tmp_path, kind, parameters):
    check_operation(tmp_path, kind, parameters)
