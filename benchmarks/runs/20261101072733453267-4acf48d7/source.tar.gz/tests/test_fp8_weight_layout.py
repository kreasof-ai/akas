"""FP8 physical storage changes preserve logical values and block scales."""
import os
import numpy as np
import pytest


@pytest.mark.parametrize('shape', [(256,384),(7,256,384)])
def test_blocked_weight_host_roundtrip(shape):
    from akas.quantization.weights.fp8.kernel import prepare_host, restore_host
    from akas.quantization.weights.fp8.definition import FORMAT

    rng = np.random.default_rng(172)
    bits = rng.integers(0,127,shape,dtype='uint8')
    scale_shape = (*shape[:-2],shape[-2]//128,shape[-1]//128)
    scales = np.ones(scale_shape,'float32')
    packed = prepare_host(bits,scales,provider='cuda',storage_layout='block128')
    assert packed['values'].shape == FORMAT.storage(shape,provider='cuda',storage_layout='block128').values.shape
    np.testing.assert_array_equal(restore_host(packed['values'],shape,storage_layout='block128'),bits)
    np.testing.assert_array_equal(packed['scales'],scales)
    np.testing.assert_array_equal(prepare_host(bits,scales,provider='cuda')['values'],bits)


@pytest.mark.parametrize('shape', [(129,256),(256,129)])
def test_blocked_weight_requires_complete_tiles(shape):
    from akas.quantization.weights.fp8.definition import FORMAT
    with pytest.raises(ValueError,match='128x128'):
        FORMAT.storage(shape,provider='cuda',storage_layout='block128')


@pytest.mark.skipif(os.getenv('AKAS_LFM_FP8_CUDA')!='1',reason='CUDA FP8 storage qualification')
@pytest.mark.parametrize('scale_product',['sequential','joint'])
@pytest.mark.parametrize('kind,packed,routed', [
    ('expert_partial',False,False),('expert_partial',True,True),
    ('fp8_expert_swiglu',True,False),('expert_swiglu',True,False),
])
def test_blocked_expert_weights_match_independent_equations(tmp_path,kind,packed,routed,scale_product):
    from test_lfm_moe_native import test_native_operations_match_independent_references as check
    p=dict(r=33,rows=33,k=384,o=256,experts=7,top=3,partitions=1,
           block_m=32,max_block_m=64,compact=True,tile_map=True,columns=128,
           threads=128,stages=1,activation_vector=16,packed_input=packed,
           packed_output=kind=='fp8_expert_swiglu',routed_input=routed,
           product_dtype='bfloat16',activation_dtype='bfloat16',weight_layout='block128',
           scale_product=scale_product)
    if kind=='expert_swiglu':
        p.update(weight_format='fp8',input_dtype='uint8',output_dtype='bfloat16')
    check(tmp_path,kind,p)


@pytest.mark.skipif(os.getenv('AKAS_LFM_FP8_CUDA')!='1',reason='CUDA FP8 storage qualification')
@pytest.mark.parametrize('shape', [(256,384),(3,256,384)])
def test_blocked_dequantization_matches_logical_values(tmp_path,shape):
    from test_lfm_moe_native import test_native_operations_match_independent_references as check
    check(tmp_path,'dequantize_weight_fp8',dict(shape=shape,storage_layout='block128'))


@pytest.mark.skipif(os.getenv('AKAS_LFM_FP8_CUDA')!='1',reason='CUDA FP8 scale qualification')
@pytest.mark.parametrize('mma_dtype',['float16','float8_e4m3fn'])
def test_joint_scales_preserve_reduction_partition_boundaries(tmp_path,mma_dtype):
    from test_lfm_moe_native import test_native_operations_match_independent_references as check
    check(tmp_path,'expert_partial',dict(r=4,rows=4,k=384,o=256,experts=7,top=3,
          partitions=3,block_m=16,max_block_m=64,compact=True,tile_map=True,
          columns=64,threads=128,stages=1,activation_vector=16,routed_input=True,
          scale_product='joint',mma_dtype=mma_dtype))
