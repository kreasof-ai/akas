"""Packed head-gate projection fused into a split attention merge."""

from akas.kernels.kernel import Tensor, kernel, output


def projected_gate_merge(spec, schedule):
    import tilelang.language as T
    from akas.kernels.webgpu import subgroup_reduce
    from akas.quantization.weights.ggml.definition import weight_storage
    from akas.quantization._shared.packing import packed_loads

    p = {**spec.parameters, **schedule}
    r, h, d, splits, k = (p[n] for n in ("r", "h", "d", "splits", "k"))
    if p["type"] != 2 or d not in (64, 128) or k % d:
        raise ValueError(
            "projected attention gate requires Q4_0 and complete D64/D128 rows"
        )
    count, _ = weight_storage(2, h * k, packed_words=True)
    lanes = min(d, k // 8)
    if k % (lanes * 8):
        raise ValueError(
            "projected attention gate requires complete packed vector tiles"
        )
    planar = p.get("weight_layout", "raw") == "planar"
    _, half_value, word_value = packed_loads()
    sum_reduce, max_reduce = subgroup_reduce(d), subgroup_reduce(d, "max")

    @T.macro
    def vector_product(acc: T.Ref, x, row, index, scale, packed, component):
        left = T.call_extern(
            "float32x4",
            "vec4<f32>",
            x[row * k + index + component * 16],
            x[row * k + index + component * 16 + 1],
            x[row * k + index + component * 16 + 2],
            x[row * k + index + component * 16 + 3],
        )
        right = T.call_extern(
            "float32x4",
            "vec4<f32>",
            T.cast(packed >> (component * 4) & 15, "float32") - 8,
            T.cast(packed >> (8 + component * 4) & 15, "float32") - 8,
            T.cast(packed >> (16 + component * 4) & 15, "float32") - 8,
            T.cast(packed >> (24 + component * 4) & 15, "float32") - 8,
        )
        acc += scale * T.call_extern("float32", "dot", left, right)

    @T.macro
    def packed_product(acc: T.Ref, x, w, row, head, tile, lane):
        block = head * (k // 32) + tile * (lanes // 4) + lane // 4
        if planar:
            scale = T.call_extern(
                "float32",
                "tensor_unpack_f16",
                w[(h * k // 32) * 4 + block // 2] >> (block % 2 * 16) & T.uint32(65535),
            )
            packed = w[block * 4 + lane % 4]
        else:
            scale = half_value(w, block * 18)
            packed = word_value(w, block * 18 + 2 + lane % 4 * 4)
        index = tile * (lanes * 8) + lane // 4 * 32 + lane % 4 * 4
        vector_product(acc, x, row, index, scale, packed, 0)
        vector_product(acc, x, row, index, scale, packed, 1)

    @kernel
    def compute(
        parts: Tensor((r * h * splits * (d + 2),), "float32"),
        x: Tensor((r * k,), "float32"),
        w: Tensor((count,), "uint32"),
        enabled: Tensor((r,), "int32"),
    ) -> Tensor((r * h * d,), "float32"):
        out = output((r * h * d,), "float32", position=3)
        with T.Kernel(r * h, threads=d) as index:
            tx = T.get_thread_binding()
            scratch = T.alloc_shared((d,), "float32")
            weights = T.alloc_shared((splits,), "float32")
            gate, coefficient = T.alloc_var("float32"), T.alloc_var("float32")
            gate = 0
            if tx < lanes:
                for tile in T.serial(k // (lanes * 8)):
                    packed_product(gate, x, w, index // h, index % h, tile, tx)
            sum_reduce(scratch, tx, gate)
            coefficient = 1 / (1 + T.exp(-scratch[0]))
            maximum, norm, result = (
                T.alloc_var("float32"),
                T.alloc_var("float32"),
                T.alloc_var("float32"),
            )
            maximum, norm, result = -1e30, 0, 0
            subgroup = T.cast(T.call_extern("uint32", "tensor_subgroup_size"), "int32")
            if T.min(subgroup, d) >= splits:
                part = tx % splits
                base = (index * splits + part) * (d + 2)
                maximum = T.call_extern("float32", "subgroupMax", parts[base + d])
                factor = T.exp(parts[base + d] - maximum)
                norm = T.call_extern(
                    "float32", "subgroupAdd", parts[base + d + 1] * factor
                )
                norm *= T.cast(splits, "float32") / T.cast(
                    T.min(subgroup, d), "float32"
                )
                if tx < splits:
                    weights[tx] = factor
                T.sync_threads()
            else:
                T.sync_threads()
                for tile in T.serial(T.ceildiv(splits, d)):
                    split = tile * d + tx
                    if split < splits:
                        maximum = T.max(
                            maximum, parts[(index * splits + split) * (d + 2) + d]
                        )
                max_reduce(scratch, tx, maximum)
                maximum = scratch[0]
                for tile in T.serial(T.ceildiv(splits, d)):
                    split = tile * d + tx
                    if split < splits:
                        offset = (index * splits + split) * (d + 2)
                        weight = T.exp(parts[offset + d] - maximum)
                        weights[split] = weight
                        norm += parts[offset + d + 1] * weight
                T.sync_threads()
                sum_reduce(scratch, tx, norm)
                norm = scratch[0]
            for part in T.serial(splits):
                result += parts[(index * splits + part) * (d + 2) + tx] * weights[part]
            out[index * d + tx] = T.if_then_else(
                enabled[index // h] != 0, result / T.max(norm, 1e-30) * coefficient, 0
            )
        return out

    return compute


def validation(kind, p, signature):
    import numpy as np
    from akas.kernels.contracts import ValidationCase
    from akas.ops.attention.validation import window_validation
    from akas.quantization.weights.ggml.validation import sample_weight
    from akas.quantization.weights.ggml.kernel import repack_host

    case = window_validation("window_merge", p, signature)
    v = case.arguments
    matrix = sample_weight(v["w"], 2, seed=31).reshape(p["h"], p["k"])
    score = (
        v["x"].reshape(p["r"], p["k"]).astype("float64") @ matrix.astype("float64").T
    )
    merged = case.expected["out"].reshape(p["r"], p["h"], p["d"]).astype("float64")
    expected = {
        **case.expected,
        "w": v["w"],
        "out": (merged / (1 + np.exp(-score[:, :, None])))
        .astype("float32")
        .reshape(-1),
    }
    if p.get("weight_layout", "raw") == "planar":
        raw = v["w"].view("uint8").reshape(-1)
        raw[:] = repack_host(raw)
    return ValidationCase(v, expected, rtol=0.002, atol=2e-5)
