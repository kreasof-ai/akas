"""Contracts and implementation choices for sequence."""

from akas.kernels.contracts import OutputABI
from akas.kernels.contracts import Implementation
from akas.ops.sequence.validation import tail_validation as tail_validation
from akas.ops.sequence.validation import VALIDATIONS, block_limit_validation

ROW_INDEPENDENT = ("add",)
OUTPUT_ARGUMENTS = {
    "reference": {
        "chunk_tail": (-1,),
        "tail_controls": (2, 3, 4),
        "chunk_last": (1,),
        "masked_copy": (1,),
        "chunk_controls": (2, 3),
        "advance": (0,),
        "next_tokens": (1,),
        "last_rows": OutputABI((-1,), ("out",)),
    }
}
for _contract in ("bf16", "block-fp8"):
    OUTPUT_ARGUMENTS.setdefault(_contract, {}).update(
        {
            "gather_hidden": OutputABI((-1,), ("out",)),
            "store_hidden": OutputABI((-1,), ("saved",)),
            "controls": OutputABI((2, 3), ("flat_position", "active")),
            "last_rows": OutputABI((-1,), ("out",)),
            "advance": OutputABI((0,), ("position",)),
        }
    )
VALIDATIONS.update({name: tail_validation for name in ("chunk_tail", "tail_controls")})
IMPLEMENTATIONS = (
    Implementation(
        "prefill_tail",
        "akas.ops.sequence.kernel",
        "packed",
        priority=20,
        factory="flat_prefill_tail",
        name="sequence.cuda.packed",
    ),
    Implementation(
        "last",
        "akas.ops.sequence.kernel",
        "packed-baseline",
        factory="baseline_last",
        name="sequence.cuda.packed_baseline",
    ),
    Implementation(
        "advance",
        "akas.ops.sequence.kernel",
        "packed-baseline",
        factory="baseline_advance",
        name="sequence.cuda.packed_baseline",
    ),
    Implementation(
        "last",
        "akas.ops.sequence.kernel",
        "packed",
        priority=0,
        factory="baseline_last",
        name="sequence.cuda.packed_baseline",
    ),
    Implementation(
        "advance",
        "akas.ops.sequence.kernel",
        "packed",
        priority=0,
        factory="baseline_advance",
        name="sequence.cuda.packed_baseline",
    ),
    Implementation(
        "last",
        "akas.ops.sequence.kernel",
        "packed",
        provider="webgpu",
        priority=0,
        factory="baseline_last",
        name="sequence.cuda.packed_baseline",
    ),
    Implementation(
        "advance",
        "akas.ops.sequence.kernel",
        "packed",
        provider="webgpu",
        priority=0,
        factory="baseline_advance",
        name="sequence.cuda.packed_baseline",
    ),
    Implementation(
        "prefill_tail",
        "akas.ops.sequence.kernel",
        "packed",
        provider="webgpu",
        priority=20,
        factory="prefill_tail",
        name="sequence.webgpu.packed",
    ),
    Implementation(
        "gather_hidden",
        "akas.ops.sequence.kernel",
        "bf16",
        factory="mapped_gather_hidden",
        name="sequence.cuda.bf16_batch",
    ),
    Implementation(
        "store_hidden",
        "akas.ops.sequence.kernel",
        "bf16",
        factory="mapped_store_hidden",
        name="sequence.cuda.bf16_batch",
    ),
    Implementation(
        "controls",
        "akas.ops.sequence.kernel",
        "bf16",
        factory="mapped_controls",
        name="sequence.cuda.bf16_batch",
    ),
    Implementation(
        "last_rows",
        "akas.ops.sequence.kernel",
        "bf16",
        factory="mapped_last_rows",
        name="sequence.cuda.bf16_batch",
    ),
    Implementation(
        "controls",
        "akas.ops.sequence.kernel",
        "block-fp8",
        phase="prefill",
        required=("slots", "chunk"),
        factory="controls_chunk_controls",
        name="sequence.cuda.prefill",
    ),
    Implementation(
        "last_rows",
        "akas.ops.sequence.kernel",
        "block-fp8",
        phase="prefill",
        required=("slots", "chunk"),
        factory="chunk_last_rows",
        name="sequence.cuda.prefill",
    ),
    Implementation(
        "advance",
        "akas.ops.sequence.kernel",
        "block-fp8",
        phase="prefill",
        required=("slots", "chunk"),
        factory="chunk_advance",
        name="sequence.cuda.prefill",
    ),
    Implementation(
        "advance",
        "akas.ops.sequence.kernel",
        "reference",
        factory="advance",
        name="sequence.reference",
    ),
    Implementation(
        "next_tokens",
        "akas.ops.sequence.kernel",
        "reference",
        factory="next_tokens",
        name="sequence.reference",
    ),
    Implementation(
        "chunk_controls",
        "akas.ops.sequence.kernel",
        "reference",
        factory="chunk_controls",
        name="sequence.reference",
    ),
    Implementation(
        "chunk_last",
        "akas.ops.sequence.kernel",
        "reference",
        factory="chunk_last",
        name="sequence.reference",
    ),
    Implementation(
        "masked_copy",
        "akas.ops.sequence.kernel",
        "reference",
        factory="masked_copy",
        name="sequence.reference",
    ),
    Implementation(
        "advance",
        "akas.ops.sequence.kernel",
        "reference",
        provider="webgpu",
        factory="advance",
        name="sequence.reference",
    ),
    Implementation(
        "next_tokens",
        "akas.ops.sequence.kernel",
        "reference",
        provider="webgpu",
        factory="next_tokens",
        name="sequence.reference",
    ),
    Implementation(
        "chunk_controls",
        "akas.ops.sequence.kernel",
        "reference",
        provider="webgpu",
        factory="chunk_controls",
        name="sequence.reference",
    ),
    Implementation(
        "chunk_last",
        "akas.ops.sequence.kernel",
        "reference",
        provider="webgpu",
        factory="chunk_last",
        name="sequence.reference",
    ),
    Implementation(
        "masked_copy",
        "akas.ops.sequence.kernel",
        "reference",
        provider="webgpu",
        factory="masked_copy",
        name="sequence.reference",
    ),
    Implementation(
        "advance",
        "akas.ops.sequence.kernel",
        "block-fp8",
        phase="commit",
        required=("all_tokens",),
        factory="chunk_advance",
        name="sequence.cuda.prefill",
    ),
    Implementation(
        "gather_hidden",
        "akas.ops.sequence.kernel",
        "block-fp8",
        factory="mapped_gather_hidden",
        name="sequence.cuda.bf16_batch",
    ),
    Implementation(
        "store_hidden",
        "akas.ops.sequence.kernel",
        "block-fp8",
        factory="mapped_store_hidden",
        name="sequence.cuda.bf16_batch",
    ),
    Implementation(
        "chunk_tail",
        "akas.ops.sequence.kernel",
        "reference",
        factory="chunk_tail",
        name="sequence.tail",
    ),
    Implementation(
        "tail_controls",
        "akas.ops.sequence.kernel",
        "reference",
        factory="tail_controls",
        name="sequence.tail",
    ),
    Implementation(
        "chunk_tail",
        "akas.ops.sequence.kernel",
        "reference",
        provider="webgpu",
        factory="chunk_tail",
        name="sequence.tail",
    ),
    Implementation(
        "tail_controls",
        "akas.ops.sequence.kernel",
        "reference",
        provider="webgpu",
        factory="tail_controls",
        name="sequence.tail",
    ),
    Implementation(
        "gather_hidden",
        "akas.ops.sequence.kernel",
        "bf16",
        provider="webgpu",
        defaults=(("dtype", "float16"),),
        factory="mapped_gather_hidden",
        name="sequence.cuda.bf16_batch",
    ),
    Implementation(
        "store_hidden",
        "akas.ops.sequence.kernel",
        "bf16",
        provider="webgpu",
        defaults=(("dtype", "float16"),),
        factory="mapped_store_hidden",
        name="sequence.cuda.bf16_batch",
    ),
    Implementation(
        "controls",
        "akas.ops.sequence.kernel",
        "bf16",
        provider="webgpu",
        factory="mapped_controls",
        name="sequence.cuda.bf16_batch",
    ),
    Implementation(
        "last_rows",
        "akas.ops.sequence.kernel",
        "bf16",
        provider="webgpu",
        defaults=(("dtype", "float16"),),
        factory="mapped_last_rows",
        name="sequence.cuda.bf16_batch",
    ),
)


OUTPUT_ARGUMENTS["reference"]["block_limits"] = (-1,)
VALIDATIONS["block_limits"] = block_limit_validation
IMPLEMENTATIONS += tuple(
    Implementation(
        "block_limits",
        "akas.ops.sequence.kernel",
        "reference",
        provider=provider,
        factory="block_limits",
        name="sequence.block_limits",
    )
    for provider in ("cuda", "webgpu")
)

IMPLEMENTATIONS += tuple(
    Implementation(
        "last_rows",
        "akas.ops.sequence.kernel",
        "reference",
        provider=provider,
        defaults=(("dtype", "float32"),),
        factory="mapped_last_rows",
        name="sequence.last_rows",
    )
    for provider in ("cuda", "webgpu")
)
