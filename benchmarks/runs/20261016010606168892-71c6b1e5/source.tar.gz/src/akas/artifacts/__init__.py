"""Shared artifacts implementation."""
