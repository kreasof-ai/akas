from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    import torch

    from zonos3_sgl.core import TTSBatch


@dataclass
class BaseAttnMetadata(ABC):
    positions: torch.Tensor

    @abstractmethod
    def get_last_indices(self, bs: int) -> torch.Tensor: ...


class BaseAttnBackend(ABC):
    @abstractmethod
    def forward(
        self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, layer_id: int, batch: TTSBatch
    ) -> torch.Tensor: ...

    @abstractmethod
    def prepare_metadata(self, batch: TTSBatch) -> None: ...

    @abstractmethod
    def init_capture_graph(self, max_seq_len: int, bs_list: List[int], frame_width: int = 1) -> None: ...

    @abstractmethod
    def prepare_for_capture(self, batch: TTSBatch) -> None: ...

    @abstractmethod
    def prepare_for_replay(self, batch: TTSBatch) -> None: ...


class HybridBackend(BaseAttnBackend):
    def __init__(
        self,
        prefill_backend: BaseAttnBackend,
        decode_backend: BaseAttnBackend,
    ) -> None:
        self.prefill_backend = prefill_backend
        self.decode_backend = decode_backend

    def forward(
        self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, layer_id: int, batch: TTSBatch
    ) -> torch.Tensor:
        backend = self.prefill_backend if batch.is_prefill else self.decode_backend
        return backend.forward(q, k, v, layer_id, batch)

    def prepare_metadata(self, batch: TTSBatch) -> None:
        backend = self.prefill_backend if batch.is_prefill else self.decode_backend
        return backend.prepare_metadata(batch)

    def init_capture_graph(self, max_seq_len: int, bs_list: List[int], frame_width: int = 1) -> None:
        self.decode_backend.init_capture_graph(max_seq_len, bs_list, frame_width)

    def prepare_for_capture(self, batch: TTSBatch) -> None:
        self.decode_backend.prepare_for_capture(batch)

    def prepare_for_replay(self, batch: TTSBatch) -> None:
        self.decode_backend.prepare_for_replay(batch)
