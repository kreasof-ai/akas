# zonos3-web — the in-browser server

ZONOS3 Mini running in the browser on hand-written WebGPU (WGSL) inside a Web Worker, serving the v2 API of
[`servers/api/openapi.yaml`](../api/openapi.yaml) through a fetch-compatible in-process transport. The studio uses it as
its `web` backend (`?api=web`, and in `auto` when no server answers). Adapted from web-zonos3. The hosted build runs
at [zyphra.com/zonos3-mini/localplayground](https://zyphra.com/zonos3-mini/localplayground) (the studio;
[`/lite`](https://zyphra.com/zonos3-mini/localplayground/lite) for
the lite page).

| Served | Off (capabilities say so; the browser cannot run their Python workers) |
| --- | --- |
| `/v2/generate` (streamed / buffered, pcm / wav), `/v1/audio/speech` | speech recognition: `/v2/edit/transcribe`, edits without `original_text` whose words are read, `verify` (503 "Speech recognition is not available on this server: …"; `edit_transcribe` false) |
| voices: default voices (shipped codes), session uploads (reference encoder + MECT speaker encoder), embedding files, slerp blends | plugins (`plugins` is empty) |
| `/v2/controls` steering-bundle controls (with set calibrations), condition rows; steer then hold (`steer_hold` / `steer_onset_seconds` / `steer_ramp_seconds` over the steer.gguf's `steer_release`, reported in capabilities and `/v2/controls`: the request-level hidden controls not exempt from it fade per generated frame on both CFG branches, a speech edit's fills counted from their first frame) | phonemize, text normalization |
| speaker, tag and controls CFG; LACI and span-follow reading; short texts (`short_text`: a word or two with a pause and filler under LACI, cut where the filler starts; `src/request/shortText.ts`); the release text rows' markers (pronunciation groups, the start marker and `start_immediately`, pause markers), encoded as `superbpe.payload_ids` does | server projects (the studio keeps projects in the browser) |
| speech editing with the clip's transcript: `/v2/edit/align` (FuseAlign, clips ≤ 30 s: `edit_align_max_seconds`), `/v2/edit` (clips ≤ 150 s; `original_text` aligns clips ≤ 30 s, longer clips need `original_words`, or `spans` within `max_context_seconds`) | accent adapters (`accents` is empty; the only adapter shipped is the speech-edit one, `edit/`, applied at runtime on the backbone's weights) |
| capabilities, health, models; `decoder` picks the audio decoder (`decoders`: the default `keep2_plain`, plus `full_mr` when the export has `zac-full_mr/`, loaded on the first request that picks it; `X-Decoder` names the one that made the audio) | |

## Layout

| Path | Contents |
| --- | --- |
| `src/client.ts` | Main-thread facade (`dist/engine.js`): `engine.init`, `localFetch`; decodes audio the worker cannot (default voices, `speaker_audio_base64` up to 60 s, the edit routes' `audio_base64` up to 150 s, sent with the upload's whole length); spawns the engine worker and the codec worker and connects them with a `MessageChannel` |
| `src/worker.ts` | The worker: loads models and companions, warms up, serves requests one at a time. Decoders: `zac/` (keep2_plain) loads at startup; each further decoder directory (`zac-full_mr/`) is listed when its manifest exists (id = meta `head.variant`) and loads, with its own GPU weights, programs and codec port, on the first request that picks it |
| `src/codec-worker.ts`, `src/spec-sink.ts` | The codec's host half (iSTFT, FIR mixer, resampler) in its own worker: the engine worker's `ZacStream` hands it each chunk's spectra, so prefix-streamed chunks overlap the following backbone steps. Each decoder has its own codec port (`codecChannel`) and host half |
| `src/api/` | The routes (port of `servers/ggml/src/server/`): `router`, `generate` (resolve + one-request scheduler), `edit` (speech editing: `zonos3.tts.edit_runtime` without speech recognition), `speakers`, `capabilities`, `validate` (spec validation, FastAPI 422 shape). Prefix streaming decodes early partial frames as `zonos3.tts.stream.PrefixDecoder` does: by default (`stream_codebooks` 1, `stream_codebooks_scope` `first`, from the registry) the first chunk leaves as soon as the first frame's semantic code arrived, its residual codebooks not yet arrived handed to the codec as -1 and left out of the RVQ sum (`zac_embed.wgsl` drops the codebook's table row and its own bias, `res.biases`); later chunks wait for complete frames. `stream_codebooks: 10` restores complete frames only; a codec export without `res.biases` (older GGUF) always decodes complete frames |
| `src/edit/` | Pure ports of the speech-edit logic (`zonos3.tts.edit`, `edit_align`, `align_text`, `textmatch`, `edit_runtime.region_doses`: edit tokens, word diff, context windows, fill lengths, edit prompt, fill extraction, splice) and the fill runner (span-end stop, `min_frames`, codes only) with the whole-clip decode |
| `src/aligner/` | FuseAlign on WebGPU (Dia text encoder, joint transformer, refinement heads), one forward per clip ≤ 30 s |
| `src/request/` | Pure ports of the ggml request logic: steering bundle, markup, LACI, span follow |
| `src/generation.ts` | The generation registry ([`model/src/zonos3/registries/generation.json`](../../model/src/zonos3/registries/generation.json)): sampling defaults, the API rate, tag-CFG range, silence prefill (default 3, at most 30 frames), decode context (30), the 900-frame reference prefix (longer reference codes keep their first 900 frames), the 2000-frame budget (shrunk to the slot rows the prompt leaves), 60 s reference clips, the early partial-frame decode defaults (`stream_codebooks`) |
| `src/backbone.ts`, `zac.ts`, `istft.ts`, `speaker.ts`, `encoder.ts`, `ssl.ts`, `rvq.ts` | The networks on WebGPU (`src/gpu/kernels/*.wgsl`) and their host parts. `Backbone.withEdit` runs the speech-edit LM on the release backbone's GPU weights: the edit vocabulary's grown rows and the speech-edit LoRA (`lora_*.wgsl`, `moe_*_lora.wgsl`, `embed_edit.wgsl`, `edit_logits.wgsl`) at runtime, as the ggml and MLX servers apply it. `ZacStream.create` times the codec gemms at load and repacks the matrices of each row class to k-major f16 (`src/gpu/h8.ts`, `gemm_h8*.wgsl`) when an h8 kernel beats the q8 one on the device |
| `src/gpu/sampler.ts`, `sample.wgsl` | Sampling on the GPU, in the decode's submission: CFG mix, stop gate, repetition penalty, temperature, top-k, top-p, min-p, the multinomial draw (MT19937 seeded as the native servers, two draws per codebook and frame) and the cold-start pads; the sampled row feeds the next decode directly, so the generation loop keeps one step in flight when no probe readout steers it. `src/sampler.ts` is its host oracle (unit tests, the API stubs, the `sampler.gpu` parity check); GPU float sums make same-seed streams differ from the ggml server's |
| `scripts/export_web_models.py` | GGUF → sharded web format (`zonos3-web-v1`; the backbone's `output.weight` becomes q8_0; the codec's per-codebook residual biases `res.{i}.bias` as `res.biases` when the GGUF has them), the backbone's text table with the release text rows appended (phoneme, start and pause rows, `--text-rows`, default `ZONOS3_RELEASE_TEXT_ROWS`, as the Python servers load them), the decoders (`zac/` from `zac-keep2.gguf`; `zac-full_mr/` from `zac.gguf` when the models directory has it), the speech-edit adapter `edit/` (grown vocabulary rows, f16 LoRA factors, shifted router biases), voices, companions, LACI heads. `scripts/check_edit_export.py` checks `edit/` against the MLX runtime adapter and writes the `backbone_edit` goldens |
| `harness/` | Headless-Chrome harness: `server.mjs` (HTTP front for conformance), `parity.mjs` (WebGPU parity checks), `bench.mjs` (desktop / Android benchmark) |
| `worker/`, `wrangler.jsonc` | Cloudflare deployment: the studio with the engine as static assets; `/models/*` redirects to the `web/` folder of [Zyphra/ZONOS3-Mini](https://huggingface.co/Zyphra/ZONOS3-Mini/tree/main/web) on the Hub |

## Build and run

```bash
# Prebuilt shards (the web/ folder of Zyphra/ZONOS3-Mini, ~5.3 GB, of which zac-full_mr ~1.1 GB) into public/models:
hf download Zyphra/ZONOS3-Mini --include 'web/*' --local-dir /tmp/zonos3-mini && mv /tmp/zonos3-mini/web servers/web/public/models
# Or export them from the GGUFs (needs the FuseAlign GGUF in the Hugging Face cache for aligner/):
hf download Zyphra/ZONOS3-Mini --include 'gguf/*' --local-dir servers/ggml
pnpm --dir servers/web export          # public/models/ (~4.5 GB; first load fetches backbone + zac (zac-keep2.gguf), ~1.0 GB; uploads add encoder + teacher, ~2.8 GB, and spk; speech editing adds edit (the speech-edit adapter on the backbone's weights, ~0.13 GB) and aligner (~0.5 GB); with zac.gguf in the models directory, zac-full_mr (the full-size decoder, fetched when a request picks decoder full_mr))
pnpm --dir servers/web build           # dist/engine.js + dist/worker.js + dist/codec-worker.js
pnpm --dir studio dev                  # http://localhost:5173/studio?api=web (or /lite?api=web)
```

The studio's dev and preview servers serve `dist/` at `/web-engine` and `public/models/` at `/models`. The worker
caches shards in Cache Storage (`zonos3-web-models-v6`; the name changes whenever an export reuses shard URLs, so a
visitor never mixes old and new shards); `?models=URL` loads them from elsewhere. Models that load
together report as one readout (`engine.init(progress)`: backbone + zac; `engine.onEncoderProgress(cb)`: spk, or
encoder + teacher on an uploaded clip's first use, edit on the first edit, aligner on the first alignment, zac-full_mr on
the first request with `decoder: "full_mr"`; default
voices ship their codes and speaker embedding beside the clip, so they load neither encoder): `{models, loaded, total, fetched}` in tensor bytes, `total` known from
the first readout (manifests are read first), at most every 100 ms; `fetched` counts the network bytes so a page can
tell a download rate from Cache Storage reads. Without WebGPU (or
with adapter limits too low) `engine.init` rejects and the studio shows the error. The speaker encoder clamps clips to
what one storage binding of the device holds (60 s on Apple Silicon); an edit's speaker row embeds the clip's first
60 s. Speech editing is offered (`speech_editing`) when the export has both `edit/` and `aligner/`.

## Tests

```bash
pnpm install                           # at the repo root, once: the pnpm workspace
pnpm --dir servers/web test            # gen:api (src/api/schema.ts, untracked), then the unit tests (Node): tokenizer, sampler, prompt, iSTFT, companions, LACI, API router and edit routes, request rules (model/tests/fixtures/request_errors.json), the speech-edit logic against tests/edit/goldens.json
.venv/bin/python servers/web/tests/edit/make_goldens.py   # regenerate tests/edit/goldens.json from the Python edit logic
pnpm --dir servers/web goldens         # CPU ggml goldens (needs a CPU ggml build at $GGML_BUILD, default /tmp/ggml-build)
pnpm --dir servers/web parity          # WebGPU parity vs the goldens in headless Chrome
pnpm --dir servers/web harness         # HTTP front on :1920, then:
uv run --package zonos3-api pytest servers/api/tests/conformance --base-url http://127.0.0.1:1920
```

The harness and parity runner launch Chrome from `CHROME_PATH`, else `harness/.chrome`
(`pnpm --dir servers/web exec npx @puppeteer/browsers install chrome@stable --path harness/.chrome`);
`HARNESS_HEADFUL=1` opens a visible window.

## Benchmark

```bash
node servers/web/harness/bench.mjs [--mode e2e|micro] [--runs 3]                  # local headless Chrome
ADB=…/platform-tools/adb node servers/web/harness/bench.mjs --android SERIAL [--browser com.android.chrome]
```

`e2e` times engine init, then streamed `/v2/generate` runs (plain and speaker CFG): `ttfa_ms` (first audio byte) and
`rtf` (wall time / audio time). `micro` times one backbone decode step (`bb_step_ms`), the CFG pair in one submission
(`bb_pair_ms`), one 16-frame codec chunk (`zac_chunk_ms`) and the host iSTFT + resampler of 256 columns (`istft_ms`),
and prints the codec gemm plan. `--android` opens the page in the phone's browser over `adb reverse`
(`http://127.0.0.1` is a secure context there); `--browser` names another browser package.

## Deploy (Cloudflare)

```bash
pnpm --dir servers/web deploy                      # studio build + engine -> Workers Static Assets
```

The models are the `web/` folder of Zyphra/ZONOS3-Mini: the deployed worker redirects `/models/*` there, so a new
export reaches the site by uploading it to the Hub (`hf upload Zyphra/ZONOS3-Mini servers/web/public/models web`; a
change that reuses shard URLs also bumps `CACHE_NAME` in `src/gpu/weights.ts`). `pnpm --dir servers/web exec wrangler
dev` runs the worker locally.
