"""Shared memory implementation."""
