"""Shared artifacts implementation."""
