"""Shared execution implementation."""
