"""Uniform codec contracts and executable conversion/fused-consumer qualification."""

import ast
from contextlib import ExitStack
from importlib import import_module
import os
from pathlib import Path

import numpy as np
import pytest

from akas.quantization import get

CODECS = [
    ("activations", "fp8"),
    ("activations", "q8"),
    ("activations", "q16"),
    ("weights", "fp8"),
    ("weights", "ggml"),
    ("kv", "fp8"),
]


@pytest.mark.parametrize("dtype", ["float16", "float32"])
def test_cuda_floating_codec_describes_matrices_above_int32_bit_count(dtype):
    from akas.kernels.definition import define
    from tensor.compiler.frontend.signature import frontend_arguments

    parameters = dict(r=128, k=2048, o=128000, optimized=True,
                      weight_dtype=dtype, input_dtype="float16")
    primitive = define(dict(kind="linear", parameters=parameters, contract="reference"))
    arguments = {a["name"]: a for a in frontend_arguments(primitive, {})}
    assert arguments["w"]["shape"] == [128000 * 2048]
    assert arguments["w"]["dtype"] == dtype


@pytest.mark.skipif(os.environ.get("AKAS_CUDA") != "1", reason="native CUDA codec execution")
@pytest.mark.parametrize("encoding,dtype", [(0, "float16"), (0, "float32"),
                                           (1, "float16"), (1, "float32"), (1, "bfloat16")])
@pytest.mark.parametrize("row,column", [(0, 0), (3, 48)])
def test_cuda_native_floating_weight_tiles_preserve_bits_and_zero_tails(
    tmp_path, encoding, dtype, row, column
):
    import tensor
    from tensor.runtime.dtypes import encode_bfloat16, decode_bfloat16
    from akas.compilation.emit import build_artifact

    rows, depth, tile_rows, tile_columns = 5, 65, 8, 32
    source_dtype = "float16" if encoding == 1 else "float32"
    values = np.random.default_rng(981).normal(size=(rows, depth)).astype(source_dtype)
    values[:, 0] = np.array([0., -0., 2**-24, -(2**-24), 2**-14], dtype=source_dtype)
    expected = np.zeros((tile_rows, tile_columns), dtype="float32")
    height, width = min(tile_rows, rows - row), min(tile_columns, depth - column)
    expected[:height, :width] = values[row:row + height, column:column + width]
    if dtype == "float16":
        expected = expected.astype("float16")
    elif dtype == "bfloat16":
        expected = decode_bfloat16(encode_bfloat16(expected))
    entry, artifact = tmp_path / "floating-tile.py", tmp_path / "floating-tile.tbin"
    entry.write_text(
        "from akas.kernels.kernel import Tensor, kernel, output\n"
        "from akas.quantization.weights.ggml.cuda import bind\n"
        "import tilelang.language as T\n"
        "def tensor_export():\n"
        f" load = bind(({rows}, {depth}), encoding={encoding}).require('read_tile')\n"
        " @kernel\n"
        f" def compute(w: Tensor(({rows * depth},), '{source_dtype}')) -> Tensor(({tile_rows}, {tile_columns}), '{dtype}'):\n"
        f"  out = output(({tile_rows}, {tile_columns}), '{dtype}')\n"
        "  with T.Kernel(1, threads=128):\n"
        f"   tile = T.alloc_shared(({tile_rows}, {tile_columns}), '{dtype}')\n"
        f"   load((w,), tile, {row}, {column})\n"
        "   T.copy(tile, out)\n"
        "  return out\n"
        " return {'kernel': compute}\n"
    )
    build_artifact(entry, artifact, provider="cuda", target="sm_89")
    with tensor.Device() as device, ExitStack() as stack:
        source = device.from_numpy(values.reshape(-1))
        result = device.empty(expected.shape, dtype)
        stack.callback(source.release)
        stack.callback(result.release)
        module = stack.enter_context(device.load(artifact))
        module.launch(source, result)
        actual = result.to_numpy()
        unsigned = "uint16" if dtype == "float16" else "uint32"
        np.testing.assert_array_equal(actual.view(unsigned), expected.view(unsigned))


@pytest.mark.parametrize(
    "depth,dtype,row,column,width",
    [
        (64, "float16", 0, 0, 64),
        (64, "float16", 3, 32, 64),
        (64, "float16", 0, 3, 32),
        (96, "float16", 0, 64, 64),
        (64, "float32", 0, 0, 64),
        (64, "bfloat16", 0, 0, 64),
    ],
)
def test_cuda_q4_tile_preserves_precision_and_boundaries(
    tmp_path, depth, dtype, row, column, width
):
    if os.environ.get("AKAS_LFM_MOE_CUDA") != "1":
        pytest.skip("opt-in packed Q4 tile qualification")
    import tensor
    from tensor.runtime.dtypes import encode_bfloat16, decode_bfloat16
    from akas.compilation.emit import build_artifact
    from akas.quantization.weights.ggml.validation import decode_rows

    rows, tile_rows = 5, 8
    rng = np.random.default_rng(918)
    blocks = rng.integers(0, 256, (rows * depth // 32, 18), dtype="uint8")
    scales = np.resize(
        np.array(
            [0.0, -0.0, 2**-24, -(2**-24), 2**-14, -(2**-14), 0.12347, -0.4321],
            dtype="float16",
        ),
        len(blocks),
    )
    blocks[:, :2] = scales.view("uint8").reshape(-1, 2)
    raw = blocks.ravel()
    expected = np.zeros((tile_rows, width), dtype="float32")
    decoded = decode_rows(raw, 2, depth, 0, rows)
    valid_rows, valid_columns = min(tile_rows, rows - row), min(width, depth - column)
    expected[:valid_rows, :valid_columns] = decoded[
        row:, column : column + valid_columns
    ]
    if dtype == "float16":
        expected = expected.astype("float16")
    elif dtype == "bfloat16":
        expected = decode_bfloat16(encode_bfloat16(expected))
    entry, artifact = tmp_path / "tile.py", tmp_path / "tile.tbin"
    entry.write_text(
        "from akas.kernels.kernel import Tensor, kernel, output\n"
        "from akas.quantization.weights import bind_parts\n"
        "import tilelang.language as T\n"
        "def tensor_export():\n"
        f" codec = bind_parts((dict(rows={rows}, format='ggml', options=dict(encoding=2)),), {depth}, provider='cuda')\n"
        " load = codec.require('read_tile')\n"
        " @kernel\n"
        f" def compute(w: Tensor(({raw.size},), 'uint8')) -> Tensor(({tile_rows}, {width}), '{dtype}'):\n"
        f"  out = output(({tile_rows}, {width}), '{dtype}')\n"
        "  with T.Kernel(1, threads=128):\n"
        f"   load((w,), out, {row}, {column})\n"
        "  return out\n"
        " return {'kernel': compute}\n"
    )
    build_artifact(entry, artifact, provider="cuda", target="sm_89")
    with tensor.Device(provider="cuda") as device, ExitStack() as stack:
        source = device.from_numpy(raw)
        result = device.empty(expected.shape, dtype)
        stack.callback(source.release)
        stack.callback(result.release)
        module = stack.enter_context(device.load(artifact))
        module.launch(source, result)
        actual = result.to_numpy()
        unsigned = "uint16" if dtype == "float16" else "uint32"
        np.testing.assert_array_equal(actual.view(unsigned), expected.view(unsigned))


@pytest.mark.parametrize("kind", ["linear", "ffn", "linear_add"])
@pytest.mark.parametrize(
    "encoding,packed_pairs", [(2, False), (2, True), (12, False), (14, False)]
)
def test_cuda_prefill_projection_uses_independent_codec_inputs(
    tmp_path, kind, encoding, packed_pairs
):
    if os.environ.get("AKAS_LFM_MOE_CUDA") != "1":
        pytest.skip("opt-in codec prefill and fused input qualification")
    import tensor
    from tensor.artifacts.format import read_artifact
    from tensor.compiler.frontend.portable import export_spec
    from akas.compilation.emit import build_artifact
    from akas.kernels.registry import validation

    p = dict(r=33, k=256, o=65, type=encoding, ggml=True, packed_pairs=packed_pairs)
    entry, artifact = tmp_path / "projection.py", tmp_path / "projection.tbin"
    entry.write_text(
        "from akas.ops.linear.cuda import _packed\n"
        "def tensor_export():\n"
        f" return {{'kernel': _packed({p!r}, paired={kind == 'ffn'}, add_residual={kind == 'linear_add'})}}\n"
    )
    definition = export_spec(entry, None)["kernel"]
    names = [str(buffer.data.name) for buffer in definition.buffer_map.values()]
    assert len(names) == len(set(names)), "codec views renamed distinct input pointers"
    build_artifact(entry, artifact, provider="cuda", target="sm_89")
    metadata, _ = read_artifact(artifact)
    case = validation(kind, p, metadata["arguments"])
    with tensor.Device(provider="cuda") as device, ExitStack() as stack:
        buffers = {
            name: device.from_numpy(value) for name, value in case.arguments.items()
        }
        for buffer in buffers.values():
            stack.callback(buffer.release)
        module = stack.enter_context(device.load(artifact))
        module.launch(*[buffers[arg["name"]] for arg in metadata["arguments"]])
        np.testing.assert_allclose(
            buffers["out"].to_numpy(),
            case.expected["out"],
            rtol=case.rtol,
            atol=case.atol,
        )


def cases():
    for name in ("q8", "q16"):
        yield f"quantize_{name}", dict(r=3, k=256), "reference"
        yield f"dequantize_{name}", dict(r=3, k=256), "reference"
    yield "quantize_q16", dict(r=3, k=256, fixed_residual=True), "reference"
    yield "quantize", dict(r=3, k=256), "block-fp8"
    yield "quantize", dict(r=2, top=3, k=128), "block-fp8"
    for kind in ("dequantize_fp8", "dequantize_weight_fp8"):
        yield kind, dict(r=3, k=256), "reference"
        yield kind, dict(shape=(2, 3, 128)), "reference"
    for encoding in (0, 1, 2, 3, 8, 12, 13, 14):
        yield "dequantize_ggml", dict(r=3, k=256, type=encoding), "reference"
    for kind in ("kv_encode", "kv_decode"):
        yield kind, dict(slots=2, chunk=2, kv_heads=3, d=256, capacity=7), "kv-pair"
    for kind in ("kv_encode", "kv_decode"):
        yield kind, dict(slots=2, chunk=2, kv_heads=1, d=64, capacity=7), "kv-pair"
    for rows in (1, 3):
        for activation in (None, "q8", "q16", "fp8"):
            for weight in ("ggml", "fp8"):
                yield (
                    "quantized_linear",
                    dict(
                        r=rows,
                        k=256,
                        o=33,
                        activation_format=activation,
                        weight_format=weight,
                        type=2,
                    ),
                    "quantized",
                )
    yield (
        "quantized_linear",
        dict(r=3, k=96, o=7, activation_format="q16", type=8),
        "quantized",
    )


CASES = list(cases())


@pytest.mark.parametrize("scope,name", CODECS)
@pytest.mark.parametrize("provider", ["cuda", "webgpu"])
def test_every_format_binds_named_storage_and_inline_access(scope, name, provider):
    format = get(scope, name)
    shape = (2, 3, 7, 256) if scope == "kv" else (3, 256)
    options = {"encoding": 2} if name == "ggml" else {}
    binding = format.bind(shape, provider=provider, **options)
    assert tuple(binding.storage.named.values()) == binding.storage.buffers
    assert binding.storage == format.storage(shape, provider=provider, **options)
    for capability in ("read", "read_tile"):
        assert capability in format.capabilities(provider)
        assert callable(binding.require(capability))
    if name in ("q8", "q16"):
        assert binding.storage.metadata_names == ("scales", "sums")
        assert binding.read_buffers == (
            binding.storage.values,
            binding.storage.named["scales"],
        )
    with pytest.raises(ValueError, match="unknown inline codec capability"):
        binding.require("missing")


def test_unsupported_geometry_fails_before_kernel_generation():
    for provider in ("cuda", "webgpu"):
        for shape in ((1, 33), (32, 1)):
            with pytest.raises(ValueError, match="whole blocks"):
                get("weights", "ggml").storage(shape, provider=provider, encoding=2)
    with pytest.raises(ValueError, match="whole blocks"):
        get("weights", "ggml").storage((2, 128), provider="cuda", encoding=12)


def test_metadata_must_be_named_at_declaration():
    from akas.memory.state import BufferSpec
    from akas.quantization import Storage

    value = BufferSpec((32,), "uint8")
    scale = BufferSpec((1,), "float32")
    with pytest.raises(ValueError, match="uniquely name every metadata buffer"):
        Storage(value, (scale,))
    with pytest.raises(ValueError, match="uniquely name every metadata buffer"):
        Storage(value, (scale,), ("values",))


@pytest.mark.parametrize("rows,depth", [(3, 256), (1, 96)])
def test_legacy_packed_q8_rejects_unsupported_geometry(rows, depth):
    from akas.kernels.registry import select
    from akas.kernels.definition import KernelSpec
    from akas.ops.linear.webgpu import linear_q8

    p = dict(r=rows, k=depth, o=8, type=2)
    with pytest.raises(ValueError, match="no compatible implementation"):
        select("linear_q8", p, contract="packed", provider="webgpu")
    with pytest.raises(ValueError, match="packed Q8 dot requires"):
        linear_q8(KernelSpec("linear_q8", p), {})


def test_word_packing_preserves_odd_block_count_and_padding():
    from akas.quantization._shared.packing import pack_words
    from akas.quantization.weights.ggml.validation import sample_weight

    storage = get("weights", "ggml").storage((3, 256), provider="webgpu", encoding=14)
    raw = np.arange(630, dtype="uint16").astype("uint8")
    packed = pack_words(raw)
    assert packed.shape == storage.values.shape == (158,)
    np.testing.assert_array_equal(packed.view("uint8")[:630], raw)
    np.testing.assert_array_equal(packed.view("uint8")[630:], 0)
    assert sample_weight(packed, 14).shape == (3 * 256,)


def test_fp8_preparation_preserves_payload_and_bf16_scales_across_providers():
    from akas.quantization.weights.fp8.kernel import prepare_host

    bits = np.arange(3 * 256, dtype="uint16").reshape(3, 256).astype("uint8") % 127
    scales = np.array([[0.12345, 0.4321]], dtype="float32")
    cuda = prepare_host(bits, scales, provider="cuda")
    webgpu = prepare_host(bits, scales, provider="webgpu")
    np.testing.assert_array_equal(cuda["values"], webgpu["values"].view("uint8"))
    np.testing.assert_array_equal(cuda["scales"], webgpu["scales"])
    assert np.any(cuda["scales"] != scales)


def test_kv_persistent_layout_keeps_provider_packing():
    format = get("kv", "fp8")
    shape = (2, 3, 7, 64)
    from akas.quantization.kv import pair_layout

    cuda, webgpu = (pair_layout("fp8", shape, provider=p) for p in ("cuda", "webgpu"))
    assert cuda[0].shape == shape and cuda[0].dtype == "uint8"
    assert webgpu[0].shape == (2, 3, 7, 16) and webgpu[0].dtype == "uint32"
    assert cuda[2:] == webgpu[2:]
    binding = format.bind(shape, provider="cuda")
    assert binding.write_pair is None
    assert callable(binding.require("write"))
    with pytest.raises(ValueError, match="does not support write_pair"):
        binding.require("write_pair")


def test_format_lookup_contributes_dynamic_codec_sources_to_artifacts():
    from akas.compilation.emit import source_dependencies

    dependencies = source_dependencies("akas.ops.vocabulary.kernel")
    for scope, name in CODECS:
        assert f"akas.quantization.{scope}.{name}.definition" in dependencies
        for provider in ("cuda", "webgpu"):
            assert f"akas.quantization.{scope}.{name}.{provider}" in dependencies


def test_codecs_do_not_depend_on_checkpoint_parsing_or_operation_kernels():
    root = Path(__file__).parents[1] / "src/akas/quantization"
    for path in root.rglob("*.py"):
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node, ast.ImportFrom):
                assert not (node.module or "").startswith(
                    ("akas.checkpoints", "akas.ops")
                ), path
    for scope, name in CODECS:
        package = import_module(f"akas.quantization.{scope}.{name}")
        assert package.__all__ == ["FORMAT"]


@pytest.mark.parametrize("provider", ["cuda", "webgpu"])
@pytest.mark.parametrize("kind,parameters,contract", CASES)
def test_factories_return_explicit_results_on_both_providers(
    provider, kind, parameters, contract
):
    from akas.kernels.definition import KernelSpec, Capabilities, define

    result = define(
        KernelSpec(kind, parameters, contract), capabilities=Capabilities(provider)
    )
    assert result.__akas_signature__.outputs
    assert not result.__akas_signature__.mutates or kind == "kv_encode"


@pytest.mark.parametrize("provider", ["cuda", "webgpu"])
@pytest.mark.parametrize("kind,parameters,contract", CASES)
def test_native_codec_and_fused_consumer_qualification(
    tmp_path, provider, kind, parameters, contract
):
    enabled = (
        os.environ.get("TENSOR_QWEN_CUDA") == "1"
        if provider == "cuda"
        else os.environ.get("AKAS_COMPILE_WEBGPU") == "1"
    )
    if not enabled:
        pytest.skip("opt-in CUDA execution or WebGPU compilation")
    import tensor
    from tensor.artifacts.format import read_artifact
    from akas.compilation.selection import source
    from akas.compilation.emit import build_artifact
    from akas.kernels.registry import validation

    entry = tmp_path / "kernel.py"
    artifact = tmp_path / "kernel.tbin"
    target = "sm_89" if provider == "cuda" else "webgpu-portable-v1"
    entry.write_text(
        source(
            kind, parameters, contract=contract, provider=provider, target=target
        ).render()
    )
    build_artifact(entry, artifact, provider=provider, target=target)
    meta, files = read_artifact(artifact)
    if provider == "webgpu":
        assert any(name.endswith(".wgsl") for name in files)
        return
    case = validation(kind, parameters, meta["arguments"])
    with tensor.Device() as device, ExitStack() as stack:
        buffers = []
        for argument in meta["arguments"]:
            buffer = device.from_numpy(
                case.arguments[argument["name"]], dtype=argument["dtype"]
            )
            stack.callback(buffer.release)
            buffers.append(buffer)
        kernel = stack.enter_context(device.load(artifact))
        kernel.launch(*buffers)
        for argument, buffer in zip(meta["arguments"], buffers):
            name = argument["name"]
            actual, expected = buffer.to_numpy(), case.expected[name]
            if name in case.comparators:
                case.comparators[name](actual, expected)
            elif np.issubdtype(actual.dtype, np.integer):
                np.testing.assert_array_equal(actual, expected)
            else:
                np.testing.assert_allclose(
                    actual, expected, rtol=case.rtol, atol=case.atol
                )
