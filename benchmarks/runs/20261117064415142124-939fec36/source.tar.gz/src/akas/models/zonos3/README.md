# ZONOS3-Mini

`Zonos3MiniSynthesis` uses a Q8_0 backbone and F32 `keep2_plain` ZAC
projector. `config.py` parses and validates architecture geometry, and
`weights.py` loads and uploads the GGUF tensors. `model.py` declares the
graphs and runs synthesis through the shared `Forward` executor. The backbone
shares attention and Gated DeltaNet state across prefill and single-row phases.
The speech compilation profile builds the graphs and publishes `speech.json`.

The WebGPU path uses hardware Vulkan for normalized English text with the
projector's predefined voices. It returns mono 44.1 kHz audio. Compile frame
capacities for the expected output length. The runtime selects the smallest
compiled codec capacity that can hold the generated frames.

```sh
WGPU_BACKEND_TYPE=Vulkan uv run --no-sync akas compile \
  --definition akas.models.zonos3:Zonos3MiniSynthesis --profile speech \
  --checkpoint build/checkpoints/zonos3-mini/ZONOS3-Mini-Q8_0.gguf \
  --checkpoint-options '{"projector":"build/checkpoints/zonos3-mini/mmproj-ZONOS3-Mini-F32.gguf"}' \
  --config '{"context":1024,"prefill_rows":64,"codec_frames":[32,64]}' \
  --out build/zonos3-mini/speech
```

Set `$env:WGPU_BACKEND_TYPE = 'Vulkan'` before the command in PowerShell.
Use the [speech benchmark commands](../../../../tools/baselines/README.md#speech-synthesis-demo)
to compare with llama.cpp Vulkan under the same request and audio protocol.
