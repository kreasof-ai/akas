"""Shared-KV GQA decode with FP32 scores, softmax and value accumulation."""

from akas.kernels.kernel import Tensor, kernel, output


def cooperative_scores(spec, schedule):
    import tilelang.language as T
    from tensor.compiler.webgpu.schedules.registers import registers, vector

    p = {**spec.parameters, **schedule}
    if p.get("score_tile") == 256:
        return cooperative_scores_wide(spec, schedule)
    r, h, kh, d, cap = (p[n] for n in ("r", "h", "kh", "d", "capacity"))
    group = h // kh
    tile = p.get("score_tile", 64)
    key_dtype = "float32" if p.get("score_float_shared", False) else "float16"
    if tile not in (32, 64, 128) or (tile >= 64 and key_dtype == "float32"):
        raise ValueError("unsupported cooperative score tile/shared storage")
    if d not in (64, 128) or cap % tile or h % kh or group not in (1, 2, 4, 8):
        raise ValueError("unsupported cooperative score geometry")

    def query_vector(q, queries, row, kv_head, head, band, chain):
        if tile == 128:
            return vector(
                [
                    q[row, (kv_head * group + head) * d + band * 16 + chain * 4 + j]
                    for j in range(4)
                ]
            )
        return vector([queries[head, band * 16 + chain * 4 + j] for j in range(4)])

    def key_vector(keys, lane, band, chain):
        if tile == 128:
            return vector(
                [
                    T.cast(
                        keys[
                            band * 16 + chain * 4 + j,
                            lane ^ ((band * 16 + chain * 4 + j) % tile),
                        ],
                        "float32",
                    )
                    for j in range(4)
                ]
            )
        return vector(
            [T.cast(keys[band * 16 + chain * 4 + j, lane], "float32") for j in range(4)]
        )

    @T.macro
    def dot_term(acc: T.Ref, q, queries, keys, row, kv_head, head, lane, band, chain):
        acc += T.call_extern(
            "float32",
            "dot",
            query_vector(q, queries, row, kv_head, head, band, chain),
            key_vector(keys, lane, band, chain),
        )

    def dot_terms(accum, q, queries, keys, row, kv_head, head, lane, band):
        for chain in range(4):
            dot_term(
                accum[chain,][0],
                q,
                queries,
                keys,
                row,
                kv_head,
                head,
                lane,
                band,
                chain,
            )

    bands = T.unroll if p.get("score_unroll", False) else T.serial

    @kernel
    def compute(
        q: Tensor((r, h * d), "float32"),
        kc: Tensor((r, kh, cap, d), "float16"),
        positions: Tensor((r,), "int32"),
        enabled: Tensor((r,), "int32"),
    ) -> Tensor((r * h * cap,), "float32"):
        out = output((r * h * cap,), "float32")
        with T.Kernel(kh, cap // tile, r, threads=group * tile) as (
            kv_head,
            block,
            row,
        ):
            tx = T.get_thread_binding()
            head, lane = tx // tile, tx % tile
            if tile == 128:
                queries = T.alloc_local((1, 1), "float32")
                keys = T.alloc_shared((d, tile), key_dtype)
            else:
                queries = T.alloc_shared((group, d), "float32")
                keys = T.alloc_shared((d, tile + 1), key_dtype)
                for query, channel in T.Parallel(group, d):
                    queries[query, channel] = q[
                        row, (kv_head * group + query) * d + channel
                    ]
            for key, channel in T.Parallel(tile, d):
                if tile == 128:
                    keys[channel, key ^ (channel % tile)] = T.if_then_else(
                        (enabled[row] != 0) & (block * tile + key <= positions[row]),
                        kc[row, kv_head, block * tile + key, channel],
                        0,
                    )
                else:
                    keys[channel, key] = T.cast(
                        T.if_then_else(
                            (enabled[row] != 0)
                            & (block * tile + key <= positions[row]),
                            kc[row, kv_head, block * tile + key, channel],
                            0,
                        ),
                        key_dtype,
                    )
            T.sync_threads()
            accum = registers((4,))
            for band in bands(d // 16):
                dot_terms(accum, q, queries, keys, row, kv_head, head, lane, band)
            score = (accum[0,][0] + accum[1,][0]) + (accum[2,][0] + accum[3,][0])
            out[(row * h + kv_head * group + head) * cap + block * tile + lane] = (
                T.if_then_else(
                    (enabled[row] != 0) & (block * tile + lane <= positions[row]),
                    score * d**-0.5,
                    -1e30,
                )
            )
        return out

    return compute


def cooperative_scores_wide(spec, schedule):
    """256 keys per group; stage 64 channels at a time within 32 KiB LDS."""
    import tilelang.language as T
    from tensor.compiler.webgpu.schedules.registers import registers, vector

    p = {**spec.parameters, **schedule}
    r, h, kh, d, cap = (p[n] for n in ("r", "h", "kh", "d", "capacity"))
    group = h // kh
    if d not in (64, 128) or cap % 256 or h % kh or group not in (1, 2, 4):
        raise ValueError("unsupported wide cooperative score geometry")

    def query_vector(q, row, head, dimension, band, chain):
        return vector(
            [
                q[row, head * d + dimension * 64 + band * 16 + chain * 4 + j]
                for j in range(4)
            ]
        )

    def key_vector(keys, lane, band, chain):
        return vector(
            [
                T.cast(
                    keys[band * 16 + chain * 4 + j, lane ^ (band * 16 + chain * 4 + j)],
                    "float32",
                )
                for j in range(4)
            ]
        )

    @T.macro
    def dot_term(acc: T.Ref, q, keys, row, head, lane, dimension, band, chain):
        acc += T.call_extern(
            "float32",
            "dot",
            query_vector(q, row, head, dimension, band, chain),
            key_vector(keys, lane, band, chain),
        )

    def dot_terms(accum, q, keys, row, head, lane, dimension, band):
        for chain in range(4):
            dot_term(accum[chain,][0], q, keys, row, head, lane, dimension, band, chain)

    bands = T.unroll if p.get("score_unroll", False) else T.serial

    @kernel
    def compute(
        q: Tensor((r, h * d), "float32"),
        kc: Tensor((r, kh, cap, d), "float16"),
        positions: Tensor((r,), "int32"),
        enabled: Tensor((r,), "int32"),
    ) -> Tensor((r * h * cap,), "float32"):
        out = output((r * h * cap,), "float32")
        with T.Kernel(kh, cap // 256, r, threads=group * 256) as (kv_head, block, row):
            tx = T.get_thread_binding()
            head, lane = tx // 256, tx % 256
            keys = T.alloc_shared((64, 256), "float16")
            accum = registers((4,))
            if (enabled[row] != 0) & (block * 256 <= positions[row]):
                for dimension in T.serial(d // 64):
                    for key, channel in T.Parallel(256, 64):
                        keys[channel, key ^ channel] = T.if_then_else(
                            block * 256 + key <= positions[row],
                            kc[
                                row,
                                kv_head,
                                block * 256 + key,
                                dimension * 64 + channel,
                            ],
                            0,
                        )
                    T.sync_threads()
                    for band in bands(4):
                        dot_terms(
                            accum,
                            q,
                            keys,
                            row,
                            kv_head * group + head,
                            lane,
                            dimension,
                            band,
                        )
                    T.sync_threads()
            score = (accum[0,][0] + accum[1,][0]) + (accum[2,][0] + accum[3,][0])
            out[(row * h + kv_head * group + head) * cap + block * 256 + lane] = (
                T.if_then_else(
                    (enabled[row] != 0) & (block * 256 + lane <= positions[row]),
                    score * d**-0.5,
                    -1e30,
                )
            )
        return out

    return compute


def group_reduce(maximum):
    import tilelang.language as T

    @T.macro
    def reduce(value: T.Ref, scratch, tx, lane):
        if T.call_extern("uint32", "tensor_subgroup_size") >= 64:
            for step in T.unroll(6):
                other = T.call_extern(
                    "float32", "subgroupShuffleXor", value, T.uint32(32 >> step)
                )
                if maximum:
                    value = T.max(value, other)
                else:
                    value += other
        else:
            scratch[tx] = value
            T.sync_threads()
            for step in T.unroll(6):
                if lane < (32 >> step):
                    if maximum:
                        scratch[tx] = T.max(scratch[tx], scratch[tx + (32 >> step)])
                    else:
                        scratch[tx] += scratch[tx + (32 >> step)]
                T.sync_threads()
            value = scratch[tx - lane]

    return reduce


def cooperative_values(spec, schedule):
    import tilelang.language as T
    from tensor.compiler.webgpu.schedules.registers import registers, vector

    p = {**spec.parameters, **schedule}
    r, h, kh, d, cap, splits = (
        p[n] for n in ("r", "h", "kh", "d", "capacity", "splits")
    )
    group = h // kh
    extent = ((cap + splits * 64 - 1) // (splits * 64)) * 64
    value_tile = p.get("value_tile", 64)
    value_dtype = "float32" if p.get("value_float_shared", False) else "float16"
    if value_tile not in (16, 32, 64):
        raise ValueError("unsupported cooperative value tile")
    if d not in (64, 128) or cap % 64 or h % kh or group not in (1, 2, 4, 8):
        raise ValueError("unsupported cooperative value geometry")
    if (
        group * extent * 4
        + value_tile * d * (4 if value_dtype == "float32" else 2)
        + group * 64 * 4
        > 32768
    ):
        raise ValueError(
            "cooperative value shared storage exceeds 32 KiB; increase splits"
        )
    maximum_reduce, sum_reduce = group_reduce(True), group_reduce(False)

    def probability_vector(probs, head, tile, band, chain):
        return vector(
            [
                probs[head, tile * value_tile + band * 16 + chain * 4 + j]
                for j in range(4)
            ]
        )

    def value_vector(values, lane, band, chain, side):
        return vector(
            [
                T.cast(values[band * 16 + chain * 4 + j, lane + side * 64], "float32")
                for j in range(4)
            ]
        )

    @T.macro
    def dot_term(acc: T.Ref, probs, values, head, lane, tile, band, chain, side):
        acc += T.call_extern(
            "float32",
            "dot",
            probability_vector(probs, head, tile, band, chain),
            value_vector(values, lane, band, chain, side),
        )

    def dot_terms(accum, probs, values, head, lane, tile, band):
        for side in range(d // 64):
            for chain in range(4):
                dot_term(
                    accum[side, chain][0],
                    probs,
                    values,
                    head,
                    lane,
                    tile,
                    band,
                    chain,
                    side,
                )

    @T.macro
    def store_value(out, value, row, kv_head, head, part, lane, side):
        offset = ((row * h + kv_head * group + head) * splits + part) * (d + 2)
        out[offset + lane + side * 64] = value

    def store_values(out, accum, row, kv_head, head, part, lane):
        for side in range(d // 64):
            value = (accum[side, 0][0] + accum[side, 1][0]) + (
                accum[side, 2][0] + accum[side, 3][0]
            )
            store_value(out, value, row, kv_head, head, part, lane, side)

    @kernel
    def compute(
        scores: Tensor((r * h * cap,), "float32"),
        vc: Tensor((r, kh, cap, d), "float16"),
        positions: Tensor((r,), "int32"),
        enabled: Tensor((r,), "int32"),
    ) -> Tensor((r * h * splits * (d + 2),), "float32"):
        out = output((r * h * splits * (d + 2),), "float32")
        with T.Kernel(kh, r, splits, threads=group * 64) as (kv_head, row, part):
            tx = T.get_thread_binding()
            head, lane = tx // 64, tx % 64
            length = T.if_then_else(
                enabled[row] != 0, T.min(positions[row] + 1, cap), 0
            )
            span = T.ceildiv(T.ceildiv(length, 64), splits) * 64
            begin, end = part * span, T.min((part + 1) * span, length)
            probs = T.alloc_shared((group, extent), "float32")
            values = T.alloc_shared((value_tile, d), value_dtype)
            scratch = T.alloc_shared((group * 64,), "float32")
            maximum, norm = T.alloc_var("float32"), T.alloc_var("float32")
            maximum, norm = -1e30, 0
            for tile in T.serial(extent // 64):
                index = tile * 64 + lane
                score = T.if_then_else(
                    begin + index < end,
                    scores[
                        (row * h + kv_head * group + head) * cap
                        + T.min(begin + index, cap - 1)
                    ],
                    -1e30,
                )
                maximum = T.max(maximum, score)
            maximum_reduce(maximum, scratch, tx, lane)
            for tile in T.serial(extent // 64):
                index = tile * 64 + lane
                score = T.if_then_else(
                    begin + index < end,
                    scores[
                        (row * h + kv_head * group + head) * cap
                        + T.min(begin + index, cap - 1)
                    ],
                    -1e30,
                )
                probability = T.if_then_else(
                    begin + index < end, T.exp(score - maximum), 0
                )
                probs[head, index] = probability
                norm += probability
            T.sync_threads()
            sum_reduce(norm, scratch, tx, lane)
            accum = registers((d // 64, 4))
            for tile in T.serial(T.ceildiv(T.max(end - begin, 0), value_tile)):
                for key, channel in T.Parallel(value_tile, d):
                    index = begin + tile * value_tile + key
                    values[key, channel] = T.cast(
                        T.if_then_else(
                            index < end,
                            vc[row, kv_head, T.min(index, cap - 1), channel],
                            0,
                        ),
                        value_dtype,
                    )
                T.sync_threads()
                for band in T.unroll(value_tile // 16):
                    dot_terms(accum, probs, values, head, lane, tile, band)
                T.sync_threads()
            store_values(out, accum, row, kv_head, head, part, lane)
            if lane == 0:
                offset = ((row * h + kv_head * group + head) * splits + part) * (d + 2)
                out[offset + d] = maximum
                out[offset + d + 1] = norm
        return out

    return compute


def _controls(values, p):
    values["positions"][:] = min(4095, p["capacity"] - 1)
    values["enabled"][:] = 1
    if p["r"] > 1:
        values["enabled"][-1] = 0


def cooperative_merge(spec, schedule):
    import tilelang.language as T
    from tensor.compiler.webgpu.schedules.registers import registers

    p = {**spec.parameters, **schedule}
    r, h, d, splits, groups = (p[n] for n in ("r", "h", "d", "splits", "merge_splits"))
    count = splits // groups
    if splits % groups or count not in (16, 32, 64) or d not in (64, 128):
        raise ValueError("unsupported hierarchical attention merge geometry")
    from akas.kernels.webgpu import subgroup_reduce

    reduce_max, reduce_sum = subgroup_reduce(d, "max"), subgroup_reduce(d)

    @T.macro
    def product(acc: T.Ref, parts, weights, index, group, tx, part):
        acc += (
            parts[((index * splits + group * count + part) * (d + 2)) + tx]
            * weights[part]
        )

    def products(accum, parts, weights, index, group, tx, band):
        for chain in range(4):
            product(
                accum[chain,][0], parts, weights, index, group, tx, band * 4 + chain
            )

    @kernel
    def compute(parts: Tensor((r * h * splits * (d + 2),), "float32")) -> Tensor(
        (r * h * groups * (d + 2),), "float32"
    ):
        out = output((r * h * groups * (d + 2),), "float32")
        with T.Kernel(r * h, groups, threads=d) as (index, group):
            tx = T.get_thread_binding()
            weights = T.alloc_shared((count,), "float32")
            scratch = T.alloc_shared((d,), "float32")
            part = tx % count
            base = (index * splits + group * count + part) * (d + 2)
            maximum, norm = T.alloc_var("float32"), T.alloc_var("float32")
            size = T.cast(T.call_extern("uint32", "tensor_subgroup_size"), "int32")
            if T.min(size, d) >= count:
                maximum = T.call_extern("float32", "subgroupMax", parts[base + d])
                factor = T.exp(parts[base + d] - maximum)
                norm = T.call_extern(
                    "float32", "subgroupAdd", parts[base + d + 1] * factor
                )
                norm *= T.cast(count, "float32") / T.cast(T.min(size, d), "float32")
                if tx < count:
                    weights[tx] = factor
                T.sync_threads()
            else:
                maximum = parts[base + d]
                reduce_max(scratch, tx, maximum)
                maximum = scratch[0]
                factor = T.exp(parts[base + d] - maximum)
                if tx < count:
                    weights[tx] = factor
                norm = parts[base + d + 1] * factor * T.cast(count, "float32") / d
                reduce_sum(scratch, tx, norm)
                norm = scratch[0]
            accum = registers((4,))
            for band in T.unroll(count // 4):
                products(accum, parts, weights, index, group, tx, band)
            result = (accum[0,][0] + accum[1,][0]) + (accum[2,][0] + accum[3,][0])
            offset = (index * groups + group) * (d + 2)
            out[offset + tx] = result
            if tx == 0:
                out[offset + d] = maximum
                out[offset + d + 1] = norm
        return out

    return compute


def merge_validation(kind, p, signature):
    import numpy as np
    from akas.kernels.contracts import ValidationCase, sample_arguments

    v = sample_arguments(signature)
    r, h, d, splits, groups = (p[n] for n in ("r", "h", "d", "splits", "merge_splits"))
    count = splits // groups
    source = v["parts"].reshape(r, h, splits, d + 2)
    source[:, :, :, -1] = np.abs(source[:, :, :, -1]) + 0.01
    source[:, :, -count:, :d] = 0
    source[:, :, -count:, -2] = -1e30
    source[:, :, -count:, -1] = 0
    chunks = source.reshape(r, h, groups, count, d + 2).astype("float64")
    maximum = chunks[..., -2].max(axis=-1)
    weight = np.exp(chunks[..., -2] - maximum[..., None])
    expected = np.empty((r, h, groups, d + 2), dtype="float32")
    expected[..., :d] = (chunks[..., :d] * weight[..., None]).sum(axis=-2)
    expected[..., -2] = maximum
    expected[..., -1] = (chunks[..., -1] * weight).sum(axis=-1)
    return ValidationCase(v, {**v, "out": expected.reshape(-1)}, rtol=0.001, atol=2e-5)


def scores_validation(kind, p, signature):
    import numpy as np
    from akas.kernels.contracts import ValidationCase, sample_arguments

    v = sample_arguments(signature)
    _controls(v, p)
    r, h, kh, d, cap = (p[n] for n in ("r", "h", "kh", "d", "capacity"))
    group = h // kh
    result = np.full((r, h, cap), -1e30, dtype="float32")
    query = v["q"].reshape(r, h, d).astype("float64")
    for row in range(r):
        length = min(int(v["positions"][row]) + 1, cap) if v["enabled"][row] else 0
        if length:
            for head in range(kh):
                keys = v["kc"][row, head, :length].astype("float64")
                result[row, head * group : (head + 1) * group, :length] = (
                    query[row, head * group : (head + 1) * group] @ keys.T * d**-0.5
                ).astype("float32")
        v["kc"][row, :, length:, :] = np.nan
    return ValidationCase(v, {**v, "out": result.reshape(-1)}, rtol=0.001, atol=2e-5)


def values_validation(kind, p, signature):
    import numpy as np
    from akas.kernels.contracts import ValidationCase, sample_arguments

    v = sample_arguments(signature)
    _controls(v, p)
    r, h, kh, d, cap, splits = (
        p[n] for n in ("r", "h", "kh", "d", "capacity", "splits")
    )
    result = np.zeros((r, h, splits, d + 2), dtype="float32")
    result[:, :, :, -2] = -1e30
    scores = v["scores"].reshape(r, h, cap)
    for row in range(r):
        length = min(int(v["positions"][row]) + 1, cap) if v["enabled"][row] else 0
        span = ((length + splits * 64 - 1) // (splits * 64)) * 64
        for part in range(splits):
            begin, end = part * span, min((part + 1) * span, length)
            if end <= begin:
                continue
            for head in range(h):
                raw = scores[row, head, begin:end].astype("float64")
                peak = raw.max()
                probability = np.exp(raw - peak)
                values = v["vc"][row, head // (h // kh), begin:end].astype("float64")
                result[row, head, part, :d] = probability @ values
                result[row, head, part, d] = peak
                result[row, head, part, d + 1] = probability.sum()
        scores[row, :, length:] = np.nan
        v["vc"][row, :, length:, :] = np.nan
    return ValidationCase(v, {**v, "out": result.reshape(-1)}, rtol=0.001, atol=2e-5)
