"""Shared TileLang computations for residual."""

from collections.abc import Mapping
from akas.kernels.definition import KernelSpec
from akas.kernels.kernel import Tensor, kernel, output


def add(spec: KernelSpec, schedule: Mapping[str, object]):
    p = {**spec.parameters, **schedule}
    import tilelang.language as T

    c = p.get("c")
    r = p.get("r", 1)
    n = r * c
    input_dtype = p.get("input_dtype", "float32")
    other_dtype = p.get("other_dtype", input_dtype)
    output_dtype = p.get("output_dtype", input_dtype)
    if any(
        dtype not in ("float32", "float16", "bfloat16")
        for dtype in (input_dtype, other_dtype, output_dtype)
    ):
        raise ValueError("residual addition requires floating storage")

    @kernel
    def compute(x: Tensor((n,), input_dtype), y: Tensor((n,), other_dtype)) -> Tensor(
        (n,), output_dtype
    ):
        out = output((n,), output_dtype)
        with T.Kernel(T.ceildiv(n, 256), threads=256) as block:
            for lane in T.Parallel(256):
                i = block * 256 + lane
                if i < n:
                    out[i] = T.cast(x[i], "float32") + T.cast(y[i], "float32")
        return out

    return compute


def attention_residual(spec, schedule):
    """Append one source and attend over the valid prefix of a residual bank."""
    import tilelang.language as T

    p = {**spec.parameters, **schedule}
    rows, width, capacity, index, epsilon = (
        p[key] for key in ("r", "c", "capacity", "index", "eps")
    )

    @kernel
    def compute(
        bank: Tensor((capacity, rows, width), "float32"),
        source: Tensor((rows, width), "float32"),
        query: Tensor((width,), "float32"),
    ) -> tuple[
        Tensor((capacity, rows, width), "float32"), Tensor((rows, width), "float32")
    ]:
        out = output((rows, width), "float32")
        with T.Kernel(rows, threads=128) as row:
            scores = T.alloc_shared((index + 1,), "float32")
            squared = T.alloc_fragment((width,), "float32")
            product = T.alloc_fragment((width,), "float32")
            norm = T.alloc_fragment((1,), "float32")
            score = T.alloc_fragment((1,), "float32")
            peak = T.alloc_shared((1,), "float32")
            denominator = T.alloc_shared((1,), "float32")
            for c in T.Parallel(width):
                bank[index, row, c] = source[row, c]
            T.sync_threads()
            for i in T.serial(index + 1):
                for c in T.Parallel(width):
                    value = bank[i, row, c]
                    squared[c] = value * value
                    product[c] = value * query[c]
                T.reduce_sum(squared, norm, dim=0)
                T.reduce_sum(product, score, dim=0)
                for j in T.Parallel(1):
                    scores[i] = score[0] * T.rsqrt(norm[0] / width + epsilon)
                T.sync_threads()
            for j in T.Parallel(1):
                peak[0] = scores[0]
                for i in T.serial(1, index + 1):
                    peak[0] = T.max(peak[0], scores[i])
                denominator[0] = 0
                for i in T.serial(index + 1):
                    scores[i] = T.exp(scores[i] - peak[0])
                    denominator[0] += scores[i]
            T.sync_threads()
            for c in T.Parallel(width):
                total = T.alloc_var("float32")
                total = 0
                for i in T.serial(index + 1):
                    total += bank[i, row, c] * (scores[i] / denominator[0])
                out[row, c] = total
        return bank, out

    return compute
