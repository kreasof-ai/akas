"""Host-side codebook table indexing and output interpretation."""

import numpy as np


def feedback_ids(config, codes):
    values = np.asarray(codes)
    if (
        values.ndim < 1
        or values.shape[-1] != config.codebooks
        or values.dtype.kind not in "iu"
        or np.any(values < 0)
        or np.any(values >= config.code_vocab)
    ):
        raise ValueError("invalid ZONOS3 codebook IDs")
    offsets = np.arange(config.codebooks, dtype="int32") * config.code_vocab
    return (values.astype("int32") + offsets).reshape(-1)


def feedback_embedding(config, embedded):
    rows = np.asarray(embedded, dtype="float32").reshape(
        -1, config.codebooks, config.width
    )
    return rows.sum(axis=1, dtype="float32")


def codebook_logits(config, projection):
    logits = np.asarray(projection, dtype="float32").reshape(
        -1, config.codebooks, config.code_vocab
    )
    limit = config.logit_softcap
    return limit * np.tanh(logits / limit)
