"""Stateful backbone composition for a single speech request."""

from math import prod
from types import SimpleNamespace

from akas.graph import Graph
from akas.ops.gdn.definition import gated_delta
from akas.ops.linear.definition import project
from akas.ops.moe.definition import routed_moe
from akas.quantization.weights import Weight


def compose_backbone(checkpoint, *, rows, context, provider):
    c = checkpoint.config
    if (
        provider != "webgpu"
        or type(context) is not int
        or not 1 <= rows <= context <= c.max_context
    ):
        raise ValueError("ZONOS3 backbone requires WebGPU and a valid request context")
    if c.conv_width != 4 or c.delta_dim % 32:
        raise ValueError("unsupported ZONOS3 recurrent geometry")
    g = Graph(contract="reference")
    x = g.buffer("embedding", (rows, c.width), "float32", role="input")
    positions = g.buffer("positions", (rows,), "int32", role="input")
    lengths = g.buffer("lengths", (1,), "int32", role="input")
    mapping = g.buffer("mapping", (1,), "int32", role="input")
    active = g.buffer("active", (rows,), "int32", role="input")
    rotary = g.buffer("rope", (context, c.head_dim), "float32", role="weight")
    unit = g.buffer("unit.weight", (c.width,), "float32", role="weight")
    sources = 2 * len(c.recurrent) + 1
    bank = g.buffer("residual_bank", (sources, rows, c.width), "float32")

    def weight(name):
        if name not in g.buffers:
            checkpoint.graph_weight(g, name, provider=provider)
        return g.buffers[name]

    def encoded(names, shape):
        tensors = checkpoint.backbone.tensors
        return Weight(
            shape,
            tuple(weight(name) for name in names),
            tuple(
                dict(
                    format="ggml",
                    rows=prod(tensors[name].shape[:-1]),
                    options={"encoding": tensors[name].type},
                )
                for name in names
            ),
        )

    def norm(x, weights, name, *, role="scratch"):
        out = g.buffer(name, x.shape, "float32", role=role)
        flat = (rows * c.width,)
        g("rms", dict(r=rows, c=c.width, eps=c.epsilon), x.view(flat), weights, out.view(flat))
        return out

    def residual(source, index, name, query):
        out = g.buffer(name, source.shape, "float32")
        g(
            "attention_residual",
            dict(r=rows, c=c.width, capacity=sources, index=index, eps=c.epsilon),
            bank,
            source,
            query,
            out,
        )
        return out

    def linear(x, name, out):
        shape = checkpoint.backbone.tensors[name].shape
        return project(g, x, encoded((name,), shape), width=c.width, name=out)

    def delta(x, prefix):
        heads, d, width = c.delta_heads, c.delta_dim, c.delta_width
        channels = 3 * width
        shape = (channels + width + 2 * heads, c.width)
        joined = (
            "attn_qkv.weight",
            "attn_gate.weight",
            "ssm_alpha.weight",
            "ssm_beta.weight",
        )
        conv = g.view(
            prefix + "conv", weight(prefix + "ssm_conv1d.weight"), (channels, 1, 4)
        )
        log_decay = g.buffer(prefix + "ssm_a_log", (heads,), "float32", role="weight")
        w = {
            prefix + "input.weight": encoded(
                tuple(prefix + name for name in joined), shape
            ),
            prefix + "conv1d.weight": conv,
            prefix + "dt_bias": weight(prefix + "ssm_dt.bias"),
            prefix + "A_log": log_decay,
            prefix + "norm.weight": weight(prefix + "ssm_norm.weight"),
            prefix + "out_proj.weight": encoded(
                (prefix + "ssm_out.weight",), (c.width, width)
            ),
        }
        cfg = SimpleNamespace(
            qkv_width=channels,
            value_width=width,
            value_heads=heads,
            key_heads=heads,
            value_dim=d,
            key_dim=d,
            epsilon=c.epsilon,
        )
        state = g.buffer(prefix + "delta", (1, heads, d, d), "float32", role="state")
        history = g.buffer(
            prefix + "conv_state", (1, channels, 3), "float32", role="state"
        )
        controls = dict(
            mapping=mapping,
            lengths=lengths,
            parameters=dict(slots=1, chunk=rows, pool=1, dtype="float32"),
        )
        return gated_delta(
            g,
            x,
            w,
            (state, history),
            controls,
            config=cfg,
            prefix=prefix,
            dtype="float32",
        )

    def attention(x, prefix):
        h, kh, d = c.heads, c.kv_heads, c.head_dim
        scale = weight(prefix + "attn_q_norm.weight")
        q, k = (
            g.buffer(prefix + tag + "_rot", (rows, heads * d), "float32")
            for tag, heads in (("q", h), ("k", kh))
        )
        for tag, heads, out in (("q", h, q), ("k", kh, k)):
            projected = linear(x, prefix + f"attn_{tag}.weight", prefix + tag)
            g(
                "head_rms_rotary",
                dict(
                    r=rows,
                    h=heads,
                    d=d,
                    capacity=context,
                    scale_heads=h,
                    weighted=tag == "q",
                    eps=1e-6,
                ),
                projected,
                scale,
                rotary,
                positions,
                out,
            )
        v = linear(x, prefix + "attn_v.weight", prefix + "v")
        shape = (1, kh, context, d)
        kc, vc = (
            g.buffer(prefix + name, shape, "float16", role="state")
            for name in ("kc", "vc")
        )
        params = dict(r=rows, h=h, kh=kh, d=d, capacity=context, chunk=rows, window=0)
        g("window_cache", params, k, v, kc, vc, positions, active)
        attended = g.buffer(prefix + "attended", (rows * h * d,), "float32")
        g("causal_grouped", params, q, kc, vc, positions, active, attended)
        gated = g.buffer(prefix + "gated", (rows * h * d,), "float32")
        gate = linear(x, prefix + "attn_gate.weight", prefix + "gate")
        g("head_gate", dict(r=rows, h=h, d=d), attended, gate.view((rows * h,)), gated)
        return linear(
            gated.view((rows, h * d)),
            prefix + "attn_output.weight",
            prefix + "attention",
        )

    def feed_forward(x, prefix, index):
        if index < c.dense_layers:
            gate, up = (
                linear(x, prefix + f"ffn_{tag}.weight", prefix + f"ffn_{tag}")
                for tag in ("gate", "up")
            )
            inner = g.buffer(prefix + "swiglu", (rows, c.dense_width), "float32")
            flat = (rows * c.dense_width,)
            g(
                "swiglu",
                dict(r=rows, c=c.dense_width),
                gate.view(flat),
                up.view(flat),
                inner.view(flat),
            )
            return linear(inner, prefix + "ffn_down.weight", prefix + "dense")
        route_input = norm(x, unit, prefix + "route_norm")
        logits = linear(route_input, prefix + "ffn_gate_inp.weight", prefix + "logits")
        latent = linear(x, prefix + "ffn_latent_down.weight", prefix + "latent")
        names = {
            tag: prefix + f"ffn_{tag}_exps.weight" for tag in ("gate", "up", "down")
        }
        experts = {
            tag: encoded((name,), checkpoint.backbone.tensors[name].shape)
            for tag, name in names.items()
        }
        mixed = routed_moe(
            g,
            latent,
            logits,
            weight(prefix + "exp_probs_b.bias"),
            experts,
            top=c.experts_per_row,
            active=active,
            prefix=prefix + "experts.",
            provider=provider,
            router="biased_softmax_router",
        )
        return linear(mixed, prefix + "ffn_latent_up.weight", prefix + "ffn")

    current = norm(x, unit, "input_norm")
    for index, recurrent in enumerate(c.recurrent):
        prefix = f"blk.{index}."
        routed = residual(
            current,
            2 * index,
            prefix + "attn_route",
            weight(prefix + "attn_res_score.weight"),
        )
        normal = norm(
            routed, weight(prefix + "attn_norm.weight"), prefix + "attn_normal"
        )
        mixed = delta(normal, prefix) if recurrent else attention(normal, prefix)
        routed = residual(
            mixed,
            2 * index + 1,
            prefix + "ffn_route",
            weight(prefix + "ffn_res_score.weight"),
        )
        normal = norm(routed, weight(prefix + "ffn_norm.weight"), prefix + "ffn_normal")
        current = feed_forward(normal, prefix, index)
    routed = residual(
        current, sources - 1, "output_route", weight("output_res_score.weight")
    )
    norm(routed, weight("output_norm.weight"), "hidden", role="output")
    return g
