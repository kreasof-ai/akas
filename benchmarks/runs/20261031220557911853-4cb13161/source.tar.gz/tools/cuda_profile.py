"""Attribute one compiled phase's dependency chain with CUDA events.

Intervals include uncaptured host submission gaps. This diagnoses bottlenecks;
it does not replace captured or end-to-end serving measurements.
"""

import argparse
from collections import defaultdict
from pathlib import Path

from akas.benchmarking.history import digest, write
from akas.benchmarking.research import definition
from akas.benchmarking.state import RecurrentSnapshot
from akas.benchmarking.workload import synthetic_prompts
from akas.optimization.context import discover


def profile(args):
    import tensor
    from tensor.compiler.tuning import measure_cuda_sequence

    declaration = definition(args.definition or discover(args.checkpoint))
    with tensor.Device() as device, declaration(args.checkpoint, args.program, device,
            graphs=False, checkpoint_options={"tokenizer": False}) as model:
        slots = [model.admit() for _ in range(args.batch)]
        prompts = synthetic_prompts(model.config.vocab, args.batch, args.chunk)
        if args.position:
            prefix = synthetic_prompts(model.config.vocab, args.batch, args.position)
            model.prefill(slots, prefix, chunk=model.prefill_geometry(2048))
        frame = model.batch(args.batch, args.chunk)
        frame.prepare(slots, prompts, model.positions)
        snapshot = RecurrentSnapshot.capture(model)
        entries = tuple(frame.forward.plan)

        def reset():
            snapshot.restore(model)
            frame.prepare(slots, prompts, model.positions)

        timing = measure_cuda_sequence(device,
            [lambda entry=entry: device._launch(entry[0], entry[1]) for entry in entries],
            reset=reset, warmup=1, samples=args.samples)
        groups = defaultdict(lambda: dict(seconds=0.0, count=0))
        for call, seconds in zip(frame.forward.definition.calls, timing["median_gpu_seconds"]):
            row = groups[call.key]
            row.update(kind=call.kind, parameters=call.parameters)
            row["seconds"] += seconds
            row["count"] += 1
        result = dict(program_sha256=digest(args.program / "program.json"),
                      device=device.info, chunk=args.chunk, position=args.position,
                      batch=args.batch, timing=timing,
                      operations=sorted(groups.values(), key=lambda r: r["seconds"], reverse=True))
        write(args.out, result)
        for row in result["operations"]:
            print(row["kind"], row["count"], round(row["seconds"] * 1000, 3), row["parameters"], flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--program", type=Path, required=True)
    parser.add_argument("--definition")
    parser.add_argument("--batch", type=int, default=1)
    parser.add_argument("--chunk", type=int, default=1)
    parser.add_argument("--position", type=int, default=0)
    parser.add_argument("--samples", type=int, default=3)
    parser.add_argument("--out", type=Path, required=True)
    profile(parser.parse_args())
