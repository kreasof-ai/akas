"""Publish the sequence and waveform phases of a compiled speech model."""

from pathlib import Path
from uuid import uuid4

from akas.artifacts.write import publish
from akas.benchmarking.history import digest
from akas.compilation.compile import produce


def compile_speech(
    checkpoint,
    out,
    *,
    definition,
    provider="webgpu",
    context=1024,
    prefill_rows=32,
    codec_frames=(16, 32, 64, 128),
    device=None,
    search_settings=None,
):
    if device is None and provider == "webgpu":
        from akas.tensor.device import vulkan_device

        with vulkan_device() as device:
            return compile_speech(
                checkpoint,
                out,
                definition=definition,
                provider=provider,
                context=context,
                prefill_rows=prefill_rows,
                codec_frames=codec_frames,
                device=device,
                search_settings=search_settings,
            )
    if (
        type(prefill_rows) is not int
        or type(context) is not int
        or not 1 <= prefill_rows <= context
        or not codec_frames
        or any(type(n) is not int or n < 1 for n in codec_frames)
    ):
        raise ValueError("invalid speech phase geometries")
    folder = Path(out)
    version = uuid4().hex
    phases = {}
    for phase, sizes in (
        ("codec", sorted(set(codec_frames))),
        ("backbone", sorted({1, prefill_rows})),
        ("audio_head", (1,)),
    ):
        phases[phase] = {}
        for rows in sizes:
            graph = definition(
                checkpoint, phase=phase, rows=rows, provider=provider, context=context
            )
            filename = f"phases/{version}/{phase}-{rows}.json"
            print(f"Compiling speech {phase} with {rows} rows", flush=True)
            produce(
                graph,
                folder,
                filename=filename,
                provider=provider,
                device=device,
                search_settings=search_settings,
            )
            phases[phase][str(rows)] = {
                "path": filename,
                "sha256": digest(folder / filename),
            }
    manifest = dict(
        schema="akas.speech-program.v1",
        provider=provider,
        context=context,
        phases=phases,
    )
    publish(folder / "speech.json", manifest)
    return manifest
