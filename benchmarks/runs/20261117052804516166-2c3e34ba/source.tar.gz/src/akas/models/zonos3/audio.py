"""Host-side codebook sampling, delay handling and waveform synthesis."""

from dataclasses import dataclass
import numpy as np


SILENCE = (1918, 746, 3544, 234, 1267, 2914, 3944, 2849, 326, 1337)
SILENCE_FRAMES = 3


@dataclass(frozen=True)
class CodeFrames:
    frames: np.ndarray
    generated_rows: int
    terminated: bool


def feedback_ids(config, codes):
    values = np.asarray(codes)
    if (
        values.ndim < 1
        or values.shape[-1] != config.codebooks
        or values.dtype.kind not in "iu"
        or np.any(values < 0)
        or np.any(values >= config.code_vocab)
    ):
        raise ValueError("invalid ZONOS3 codebook IDs")
    offsets = np.arange(config.codebooks, dtype="int32") * config.code_vocab
    return (values.astype("int32") + offsets).reshape(-1)


def feedback_embedding(config, embedded):
    rows = np.asarray(embedded, dtype="float32").reshape(
        -1, config.codebooks, config.width
    )
    return rows.sum(axis=1, dtype="float32")


def codebook_logits(config, projection):
    logits = np.asarray(projection, dtype="float32").reshape(
        -1, config.codebooks, config.code_vocab
    )
    limit = config.logit_softcap
    return limit * np.tanh(logits / limit)


def silence_prefix(config):
    rows = np.full((SILENCE_FRAMES, config.codebooks), config.codes + 1, dtype="int32")
    for index, row in enumerate(rows):
        row[: index + 1] = SILENCE[: index + 1]
    return rows


def _sample(logits, history, temperature, rng, eoa):
    value = logits.copy()
    value[eoa + 1] = -np.inf
    if history:
        used = np.unique(history)
        used = used[used < eoa]
        penalty = 2.4
        value[used] = np.where(
            value[used] > 0, value[used] / penalty, value[used] * penalty
        )
    if temperature == 0:
        return int(np.argmax(value))
    value /= temperature
    top_k, top_p = 80, 0.69
    threshold = np.partition(value, -top_k)[-top_k]
    indices = np.flatnonzero(value >= threshold)
    selected = value[indices].astype("float64")
    weights = np.exp(selected - selected.max())
    order = np.argsort(-weights, kind="stable")
    sorted_weights = weights[order]
    before = np.cumsum(sorted_weights) - sorted_weights
    weights[order[before > top_p * weights.sum()]] = 0
    cdf = np.cumsum(weights)
    return int(
        indices[np.searchsorted(cdf, rng.random_sample() * cdf[-1], side="right")]
    )


def generate_codes(config, initial_logits, advance, *, seed, temperature, limit):
    """Sample delayed rows until EOA and reserve its trailing delay for deinterleaving."""
    if (
        not np.isfinite(temperature)
        or temperature < 0
        or type(limit) is not int
        or limit < 1
    ):
        raise ValueError("invalid ZONOS3 sampling settings")
    rng = np.random.RandomState(seed)
    rows = list(silence_prefix(config))
    logits = initial_logits
    eoa, pad = config.codes, config.codes + 1
    eos_frame, stop_row = None, None
    columns = np.arange(config.codebooks)
    for step in range(limit):
        logits = np.asarray(logits, dtype="float32").reshape(
            config.codebooks, config.code_vocab
        )
        if not np.isfinite(logits).all():
            raise ValueError("ZONOS3 produced non-finite audio logits")
        recent = rows[max(SILENCE_FRAMES, len(rows) - 96) :]
        sample = np.array(
            [
                _sample(
                    logits[cb],
                    [row[cb] for row in recent] if cb < 6 else (),
                    temperature,
                    rng,
                    eoa,
                )
                for cb in range(config.codebooks)
            ],
            dtype="int32",
        )
        index = len(rows)
        sample[index + 1 :] = pad
        rows.append(sample)
        ended = np.flatnonzero(sample == eoa)
        if eos_frame is None and len(ended):
            eos_frame = max(0, index - int(ended[-1]))
            stop_row = index + config.codebooks
        if index == stop_row or step + 1 == limit:
            break
        logits = advance(sample)
    end = max(0, len(rows) - config.codebooks + 1)
    if eos_frame is not None:
        end = min(end, eos_frame)
    delayed = np.asarray(rows, dtype="int32")
    codes = delayed[np.arange(end)[:, None] + columns, columns]
    return CodeFrames(
        np.minimum(codes, config.codes - 1),
        len(rows) - SILENCE_FRAMES,
        eos_frame is not None,
    )


def waveform(checkpoint, spectrum):
    """Reconstruct mono 44.1 kHz PCM from the two ZAC inverse STFT branches."""
    sizes, hop = (736, 2208), 184
    data = np.asarray(spectrum, dtype="float32")
    if data.ndim != 2 or data.shape[1] != sum(n + 2 for n in sizes) or not len(data):
        raise ValueError("invalid ZONOS3 ZAC spectrum")
    mixer = checkpoint.projector.array("a.gen.wav.mixer.weight")
    resample = checkpoint.projector.array("a.gen.wav.resample.weight")
    length, offset = len(data) * hop, 0
    mixed = np.zeros(length, dtype="float32")
    for n, taps in zip(sizes, mixer, strict=True):
        bins = n // 2 + 1
        magnitude = np.exp(np.minimum(data[:, offset : offset + bins], np.log(100)))
        phase = data[:, offset + bins : offset + 2 * bins]
        window = 0.5 - 0.5 * np.cos(2 * np.pi * np.arange(n) / n)
        frames = np.fft.irfft(magnitude * np.exp(1j * phase), n=n, axis=1)
        signal = np.zeros(length + n, dtype="float32")
        envelope = np.zeros_like(signal)
        for i, frame in enumerate(frames):
            region = slice(i * hop, i * hop + n)
            signal[region] += frame * window
            envelope[region] += window**2
        centered = slice(n // 2, n // 2 + length)
        branch = signal[centered] / np.maximum(envelope[centered], 1e-11)
        mixed += np.correlate(branch, taps, mode="same")
        offset += 2 * bins
    block = 736
    width = (resample.shape[1] - block) // 2
    padded = np.pad(mixed, (width, width + (-length % block)))
    windows = np.lib.stride_tricks.sliding_window_view(padded, resample.shape[1])[
        ::block
    ]
    samples = (windows @ resample.T).reshape(-1)[: (length * 735 + 735) // block]
    samples = (
        samples[SILENCE_FRAMES * checkpoint.config.samples_per_frame :] * 0.70794578
    )
    knee = 10 ** (-1 / 20)
    limit = knee + (1 - knee) * np.tanh((np.abs(samples) - knee) / (1 - knee))
    return np.where(
        np.abs(samples) <= knee, samples, np.copysign(limit, samples)
    ).astype("float32")
