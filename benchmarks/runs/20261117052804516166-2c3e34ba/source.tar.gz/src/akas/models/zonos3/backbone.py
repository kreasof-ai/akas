"""Run compiled embedding-to-hidden ZONOS3 phases with shared request state."""

import json
from contextlib import ExitStack
from pathlib import Path

import numpy as np

from akas.execution.forward import Forward
from akas.graph import Graph
from akas.memory.transfer import write_many


class Zonos3Mini:
    """A single ZONOS3 speech backbone request over common Forward bundles."""

    def __init__(self, checkpoint, directory, device, *, phases):
        self.config = checkpoint.config
        self.device = device
        self._resources = ExitStack()
        self._forwards, self._states = {}, {}
        self.position = 0
        directory = Path(directory)
        definitions = {}
        shared = {}
        try:
            for rows, filename in phases.items():
                manifest = json.loads(
                    (directory / filename).read_text(encoding="utf-8")
                )
                if manifest["provider"] != device.info["provider"]:
                    raise ValueError("ZONOS3 phase targets a different backend")
                graph = Graph.from_metadata(manifest["forward"])
                if graph.buffers["embedding"].shape != (rows, self.config.width):
                    raise ValueError(
                        "ZONOS3 phase row count does not match its manifest"
                    )
                definitions[rows] = graph
                for name, spec in graph.buffers.items():
                    if spec.role in ("state", "weight") and spec.alias_of is None:
                        previous = shared.setdefault(name, spec)
                        if previous != spec:
                            raise ValueError(
                                f"incompatible ZONOS3 phase buffer: {name}"
                            )
            if 1 not in definitions:
                raise ValueError("ZONOS3 requires a one-row decode phase")
            self.prefill_rows = max(definitions)
            self.context = shared["rope"].shape[0]
            weights = checkpoint.upload(
                device,
                (name for name, spec in shared.items() if spec.role == "weight"),
                context=self.context,
            )
            for buffer in weights.values():
                self._resources.callback(buffer.release)
            for name, spec in shared.items():
                if spec.role == "state":
                    buffer = device.zeros(spec.shape, spec.dtype)
                    self._states[name] = buffer
                    self._resources.callback(buffer.release)
            for rows, graph in definitions.items():
                supplied = {
                    name: buffer
                    for name, buffer in (weights | self._states).items()
                    if name in graph.buffers
                }
                for name, spec in graph.buffers.items():
                    if spec.role in ("input", "output") and spec.alias_of is None:
                        supplied[name] = buffer = device.empty(spec.shape, spec.dtype)
                        self._resources.callback(buffer.release)
                forward = Forward(
                    directory, device, supplied, filename=phases[rows], graphs=True
                )
                self._forwards[rows] = self._resources.enter_context(forward)
        except BaseException:
            self.close()
            raise

    def reset(self):
        write_many(
            self.device,
            (
                (buffer, np.zeros(buffer.shape, str(buffer.dtype)))
                for buffer in self._states.values()
            ),
        )
        self.position = 0

    def advance(self, embeddings):
        """Run a compiled chunk and return its F32 hidden states."""
        rows = np.asarray(embeddings, dtype="float32")
        if rows.ndim != 2 or rows.shape[1] != self.config.width or not len(rows):
            raise ValueError("invalid ZONOS3 embedding rows")
        if self.position + len(rows) > self.context:
            raise ValueError("ZONOS3 request exceeds its compiled context")
        count = len(rows)
        eligible = [capacity for capacity in self._forwards if capacity >= count]
        if not eligible:
            raise ValueError("ZONOS3 request chunk does not have a compiled phase")
        capacity = min(eligible)
        forward = self._forwards[capacity]
        positions = np.zeros(capacity, dtype="int32")
        positions[:count] = np.arange(
            self.position, self.position + count, dtype="int32"
        )
        active = np.zeros(capacity, dtype="int32")
        active[:count] = 1
        values = dict(
            embedding=np.pad(rows, ((0, capacity - count), (0, 0)))
            if count < capacity
            else rows,
            positions=positions,
            active=active,
            lengths=np.array([count], dtype="int32"),
            mapping=np.zeros(1, dtype="int32"),
        )
        write_many(
            self.device,
            ((forward.buffers[name], value) for name, value in values.items()),
        )
        forward.run()
        hidden = forward.buffers["hidden"].to_numpy()
        self.position += len(rows)
        return hidden[:count]

    def close(self):
        self._resources.close()
        self._forwards.clear()
        self._states.clear()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
