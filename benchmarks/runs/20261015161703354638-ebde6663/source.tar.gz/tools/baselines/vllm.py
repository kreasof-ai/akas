import argparse, dataclasses, json, time, traceback
from pathlib import Path
import torch
from vllm import LLM, SamplingParams
from vllm._version import __commit_id__


def main():
    p = argparse.ArgumentParser()
    p.add_argument("model", choices=["lfm", "qwen"])
    p.add_argument("--mtp", action="store_true")
    a = p.parse_args()
    root = Path(__file__).resolve().parents[2] / "build/baselines"
    name = f"vllm-{a.model}-" + ("mtp" if a.mtp else "ar")
    checkpoint = (
        root.parent
        / "model-smoke/checkpoints"
        / ("lfm-hf" if a.model == "lfm" else "qwen-hf")
    ).resolve()
    settings = dict(
        model=str(checkpoint),
        dtype="bfloat16",
        max_model_len=2304,
        max_num_seqs=4,
        max_num_batched_tokens=2048,
        gpu_memory_utilization=0.45,
        enforce_eager=True,
        enable_prefix_caching=False,
        disable_log_stats=False,
        seed=17,
    )
    if a.model == "qwen":
        settings["language_model_only"] = True
    if a.mtp:
        settings["speculative_config"] = dict(method="mtp", num_speculative_tokens=1)
    report = dict(
        runtime="vllm",
        revision=__commit_id__,
        version=__import__("vllm").__version__,
        model=a.model,
        mode="mtp" if a.mtp else "ar",
        settings=settings,
        device=torch.cuda.get_device_name(),
        scope="preflight; eager execution; not tuned performance",
        cases=[],
    )
    try:
        llm = LLM(**settings)
        tokenizer = llm.get_tokenizer()
        seed = tokenizer.encode(
            "The capital of France is Paris. Explain the history of this city briefly. ",
            add_special_tokens=False,
        )
        for batch, prefix in [(1, 32), (4, 32), (1, 2048)]:
            ids = (seed * ((prefix + len(seed) - 1) // len(seed)))[:prefix]
            params = SamplingParams(temperature=0, max_tokens=128, ignore_eos=True)
            prompts = [dict(prompt_token_ids=ids) for _ in range(batch)]
            llm.generate(prompts, params, use_tqdm=False)
            torch.cuda.synchronize()
            start = time.perf_counter()
            out = llm.generate(prompts, params, use_tqdm=False)
            torch.cuda.synchronize()
            elapsed = time.perf_counter() - start
            tokens = [list(row.outputs[0].token_ids) for row in out]
            assert len(tokens) == batch and all(len(row) == 128 for row in tokens)
            metrics = [
                dataclasses.asdict(row.metrics)
                if dataclasses.is_dataclass(row.metrics)
                else str(row.metrics)
                for row in out
            ]
            report["cases"].append(
                dict(
                    batch=batch,
                    prefix=prefix,
                    output=128,
                    wall_seconds=elapsed,
                    output_ids=tokens,
                    request_metrics=metrics,
                    status="passed",
                )
            )
            (root / f"{name}.json").write_text(
                json.dumps(report, indent=2, default=str) + "\n"
            )
            print("CASE", name, batch, prefix, elapsed, flush=True)
        report["status"] = "passed"
    except Exception as e:
        report.update(
            status="failed",
            error=f"{type(e).__name__}: {e}",
            traceback=traceback.format_exc(),
        )
        print(report["traceback"], flush=True)
    finally:
        (root / f"{name}.json").write_text(
            json.dumps(report, indent=2, default=str) + "\n"
        )
    if report["status"] != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
