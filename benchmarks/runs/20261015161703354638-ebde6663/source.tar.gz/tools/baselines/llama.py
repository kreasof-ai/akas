"""Short text generation checks through an isolated localhost llama-server."""

import argparse, json, os, signal, subprocess, time, traceback, urllib.request
from datetime import datetime, timezone
from pathlib import Path


def main():
    p = argparse.ArgumentParser()
    p.add_argument("model", choices=["lfm", "qwen"])
    p.add_argument("provider", choices=["cuda", "vulkan"])
    p.add_argument("format", choices=["f16", "q4_0", "q4_k_m"])
    a = p.parse_args()
    root = Path(__file__).resolve().parents[2] / "build/baselines"
    repo = root / "llama.cpp"
    binary = repo / f"build-{a.provider}/bin/llama-server"
    model = root / "checkpoints" / f"{a.model}-{a.format}.gguf"
    if a.format == "q4_k_m":
        model = next(
            (root.parent / "model-smoke/checkpoints" / f"{a.model}-gguf").glob("*.gguf")
        )
    name = f"llama-{a.model}-{a.provider}-{a.format}"
    command = [
        str(binary),
        "-m",
        str(model),
        "-ngl",
        "99",
        "--device",
        "CUDA0" if a.provider == "cuda" else "Vulkan0",
        "-c",
        "2304",
        "-np",
        "1",
        "-b",
        "2048",
        "-ub",
        "512",
        "-t",
        "2",
        "-fa",
        "on",
        "--host",
        "127.0.0.1",
        "--port",
        "8817",
        "--no-webui",
    ]
    report = dict(
        runtime="llama.cpp",
        model=a.model,
        mode="ar",
        provider=a.provider,
        format=a.format,
        started_at=datetime.now(timezone.utc).isoformat(),
        command=command,
        revision=subprocess.check_output(
            ["git", "-C", str(repo), "rev-parse", "HEAD"], text=True
        ).strip(),
        scope="localhost server preflight; not tuned performance",
        cases=[],
    )
    process = None

    def request(path, data=None):
        req = urllib.request.Request(
            "http://127.0.0.1:8817" + path,
            data=None if data is None else json.dumps(data).encode(),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=90) as r:
            return json.load(r)

    try:
        with (root / f"{name}-server.log").open("w") as log:
            process = subprocess.Popen(
                command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True
            )
            until = time.monotonic() + 120
            while True:
                if process.poll() is not None:
                    raise RuntimeError(
                        "llama-server exited: " + str(process.returncode)
                    )
                try:
                    if request("/health").get("status") == "ok":
                        break
                except Exception:
                    if time.monotonic() > until:
                        raise TimeoutError("server startup exceeded 120s")
                    time.sleep(0.25)
            seed = request(
                "/tokenize",
                dict(
                    content="The capital of France is Paris. Explain the history of this city briefly. ",
                    add_special=False,
                ),
            )["tokens"]
            for prefix in (32, 2048):
                ids = (seed * ((prefix + len(seed) - 1) // len(seed)))[:prefix]
                payload = dict(
                    prompt=ids,
                    n_predict=128,
                    temperature=0,
                    seed=17,
                    ignore_eos=True,
                    cache_prompt=False,
                    return_tokens=True,
                )
                request("/completion", payload)
                start = time.perf_counter()
                out = request("/completion", payload)
                elapsed = time.perf_counter() - start
                assert out["tokens_predicted"] == 128, out
                report["cases"].append(
                    dict(
                        batch=1,
                        prefix=prefix,
                        output=128,
                        wall_seconds=elapsed,
                        response=out,
                        status="passed",
                    )
                )
                print("CASE", name, prefix, elapsed, flush=True)
        report["status"] = "passed"
    except Exception as e:
        report.update(
            status="failed",
            error=f"{type(e).__name__}: {e}",
            traceback=traceback.format_exc(),
        )
        print(report["traceback"], flush=True)
    finally:
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        report["completed_at"] = datetime.now(timezone.utc).isoformat()
        (root / f"{name}.json").write_text(json.dumps(report, indent=2) + "\n")
    if report["status"] != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
