"""Run one isolated baseline probe and retain its provenance in benchmark history."""

import argparse
import csv
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

from akas.benchmarking.history import Recorder, digest
from akas.cli import checkpoint_digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runtime", choices=("vllm", "sglang", "llama"))
    parser.add_argument("model", choices=("lfm", "qwen"))
    parser.add_argument("--mtp", action="store_true")
    parser.add_argument("--provider", choices=("cuda", "vulkan"), default="cuda")
    parser.add_argument("--format", choices=("f16", "q4_0", "q4_k_m"), default="q4_k_m")
    parser.add_argument("--history", type=Path, default=Path("benchmarks"))
    parser.add_argument("--seconds", type=int, default=600)
    args = parser.parse_args()
    if args.seconds <= 0 or (args.runtime != "llama" and args.provider != "cuda"):
        parser.error("a positive deadline and compatible provider are required")
    if args.runtime == "llama" and args.mtp:
        parser.error("this llama.cpp probe measures AR")
    root = Path(__file__).resolve().parents[2]
    work = root / "build/baselines"
    kind = "mtp" if args.mtp else "ar"
    name = (
        f"{args.runtime}-{args.model}-{kind}"
        if args.runtime != "llama"
        else f"llama-{args.model}-{args.provider}-{args.format}"
    )
    python = (
        work / args.runtime / "bin/python"
        if args.runtime != "llama"
        else Path(sys.executable)
    )
    command = [str(python), "-u", "-m", f"tools.baselines.{args.runtime}", args.model]
    if args.runtime == "llama":
        command.extend((args.provider, args.format))
    elif args.mtp:
        command.append("--mtp")
    checkpoint = root / f"build/model-smoke/checkpoints/{args.model}-hf"
    if args.runtime == "llama":
        checkpoint = (
            next(
                (root / f"build/model-smoke/checkpoints/{args.model}-gguf").glob(
                    "*.gguf"
                )
            )
            if args.format == "q4_k_m"
            else work / "checkpoints" / f"{args.model}-{args.format}.gguf"
        )
    detected = next(
        csv.reader(
            subprocess.check_output(
                [
                    "nvidia-smi",
                    "--query-gpu=name,compute_cap,uuid,driver_version,memory.total",
                    "--format=csv,noheader,nounits",
                ],
                text=True,
            ).splitlines()
        )
    )
    gpu_name, capability, gpu_uuid, driver, memory_mib = (
        value.strip() for value in detected
    )
    metadata = dict(
        runtime=args.runtime,
        model="LiquidAI/LFM2.5-230M" if args.model == "lfm" else "Qwen/Qwen3.5-0.8B",
        mode=kind,
        provider=args.provider,
        target="sm_" + capability.replace(".", "")
        if args.provider == "cuda"
        else "vulkan",
        device=dict(
            name=gpu_name, uuid=gpu_uuid, driver=driver, memory_mib=int(memory_mib)
        ),
        purpose="preflight",
        command=command,
        protocol="baseline-preflight-v1",
        checkpoint=str(checkpoint),
        checkpoint_sha256=checkpoint_digest(checkpoint),
        environment={
            k: os.environ.get(k)
            for k in (
                "CUDA_HOME",
                "OMP_NUM_THREADS",
                "OPENBLAS_NUM_THREADS",
                "MAX_JOBS",
                "VK_ICD_FILENAMES",
                "LD_LIBRARY_PATH",
                "CUDA_VISIBLE_DEVICES",
            )
        },
        warmup=1,
        repeats=1,
        graphs=False if args.runtime != "llama" else None,
        weight_format="bf16-safetensors" if args.runtime != "llama" else args.format,
        kv_dtype="bfloat16" if args.runtime != "llama" else "float16",
        sampling=dict(temperature=0, ignore_eos=True, output_tokens=128),
    )
    if args.runtime != "llama":
        frozen = subprocess.check_output(
            [
                str(python),
                "-c",
                "import importlib.metadata as m,json;print(json.dumps({d.metadata['Name']:d.version for d in m.distributions()}))",
            ],
            text=True,
        )
        metadata["dependencies"] = json.loads(frozen)
    run = Recorder(
        args.history,
        metadata,
        kind="baseline",
        change="Qualify baseline execution; eager probes are not competitive performance measurements",
    )
    raw, log = work / f"{name}.json", work / f"{name}.log"
    raw.unlink(missing_ok=True)
    result = dict(schema="akas.benchmark.v1", metadata=metadata, results=[])
    process = None
    try:
        with log.open("w") as output:
            process = subprocess.Popen(
                command,
                cwd=root,
                stdout=output,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            code = process.wait(timeout=args.seconds)
        data = json.loads(raw.read_text()) if raw.exists() else {}
        metadata.update(
            runtime_version=data.get("version"),
            runtime_revision=data.get("revision"),
            configuration=data.get("settings", data.get("command")),
            error=data.get("error"),
        )
        for row in data.get("cases", []):
            result["results"].append(
                dict(
                    case=dict(
                        batch=row["batch"],
                        prompt=row["prefix"],
                        generated=row["output"],
                        depth=0,
                        mixed=False,
                    ),
                    status="ok" if row["status"] == "passed" else "error",
                    samples=[dict(wall_seconds=row["wall_seconds"])],
                    correctness=dict(output_count=True, full_model_reference=False),
                )
            )
        if args.mtp and data.get("status") == "passed":
            previous = json.loads(
                (work / f"{args.runtime}-{args.model}-ar.json").read_text()
            )

            def ids(row):
                return (
                    row["output_ids"]
                    if "output_ids" in row
                    else [r["output_ids"] for r in row["responses"]]
                )

            if len(previous["cases"]) != len(data["cases"]) or not all(
                (a["batch"], a["prefix"], ids(a)) == (b["batch"], b["prefix"], ids(b))
                for a, b in zip(previous["cases"], data["cases"])
            ):
                raise ValueError("MTP output differs from the matching AR probe")
            metadata["greedy_ar_mtp_equal"] = True
        status = "passed" if code == 0 and data.get("status") == "passed" else "failed"
        metadata["returncode"] = code
    except subprocess.TimeoutExpired:
        status = "budget_exhausted"
        metadata["error"] = f"probe exceeded {args.seconds}s"
    except BaseException as error:
        status = "interrupted" if isinstance(error, KeyboardInterrupt) else "failed"
        metadata["error"] = f"{type(error).__name__}: {error}"
    finally:
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        for path in (raw, log):
            if path.exists():
                run.artifact(path, path.name)
        run.artifact(Path(__file__).with_name(args.runtime + ".py"), "probe.py")
        if args.runtime == "llama":
            binary = work / f"llama.cpp/build-{args.provider}/bin/llama-server"
            if binary.is_file():
                metadata["binary_sha256"] = digest(binary)
            cache = binary.parents[1] / "CMakeCache.txt"
            if cache.is_file():
                run.artifact(cache, "CMakeCache.txt")
        record = run.update(result, final=True, status=status)
        print(record["id"], record["status"], name, flush=True)
    if record["status"] != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
