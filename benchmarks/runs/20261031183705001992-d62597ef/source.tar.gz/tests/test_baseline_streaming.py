"""Token arrival measurements preserve concurrency, coalescing and failures."""

import asyncio
import pytest

from tools.baselines.common import stream_burst


def test_streamed_burst_retains_each_request_and_delivery_chunks():
    async def generate(index, prompt):
        await asyncio.sleep(.001 * (index + 1))
        yield [prompt[0]], {"cached_tokens": 0}
        await asyncio.sleep(.001)
        yield [prompt[0], 7, 8], {"cached_tokens": 0}

    output, details = asyncio.run(stream_burst([[1, 2], [3, 4]], generate, 3))
    assert output == [[1, 7, 8], [3, 7, 8]]
    assert details["phase_protocol"] == "client-stream-burst-v1"
    times = [r["arrivals_seconds"] for r in details["request_streams"]]
    assert all(row[0] < row[1] == row[2] for row in times)
    assert details["ttft_seconds"] == max(row[0] for row in times)
    assert details["prefill_tokens_per_second"] == 4 / details["ttft_seconds"]
    assert details["decode_tokens_per_second"] == 4 / max(row[-1] - row[0] for row in times)


@pytest.mark.parametrize("problem", ["rewrite", "cache", "short"])
def test_failed_stream_cancels_other_requests(problem):
    closed = []

    async def generate(index, prompt):
        try:
            yield [1], {}
            if index == 0:
                await asyncio.sleep(.001)
                if problem == "short":
                    return
                yield [9, 2] if problem == "rewrite" else [1, 2], {"cached_tokens": int(problem == "cache")}
            else:
                await asyncio.sleep(10)
        finally:
            closed.append(index)

    with pytest.raises(ValueError):
        asyncio.run(stream_burst([[1], [2]], generate, 2))
    assert sorted(closed) == [0, 1]
