"""Original FP8 safetensors use shared model/runtime and numerical operations."""

import json
import os
from pathlib import Path
import struct

import numpy as np
import pytest

from akas.models.lfm2 import LFM2MoE
from akas.models.lfm2.config import LFM2MoEConfig
from akas.models.lfm2.weights import LFM2MoECheckpoint


def fixture(directory):
    from akas.models.lfm2.weights import huggingface_names, tensor_shapes
    from akas.quantization._shared.e4m3 import encode_storage
    from tensor.runtime.dtypes import encode_bfloat16

    directory.mkdir(parents=True)
    config = dict(model_type="lfm2_moe", hidden_size=256, intermediate_size=256,
                  num_attention_heads=4, num_key_value_heads=1, num_hidden_layers=2,
                  layer_types=["conv", "full_attention"], vocab_size=64, conv_L_cache=3,
                  max_position_embeddings=64, norm_eps=1e-5, num_experts=4,
                  num_experts_per_tok=2, moe_intermediate_size=256, num_dense_layers=1,
                  use_expert_bias=True, norm_topk_prob=True, routed_scaling_factor=1.0,
                  quantization_config={"quant_method": "compressed-tensors", "format": "float-quantized",
                      "config_groups": {"FP8_BLOCK": {
                          "weights": dict(num_bits=8, type="float", strategy="block", block_structure=[128, 128],
                                          dynamic=False, symmetric=True),
                          "input_activations": dict(num_bits=8, type="float", strategy="group", group_size=128,
                                                    dynamic=True, symmetric=True)}}})
    c = LFM2MoEConfig.from_huggingface(config)
    shapes = tensor_shapes(c)
    names = huggingface_names(c)
    sources = {name: (names[name],) for name in shapes if name in names}
    sources["blk.1.ffn_gate_inp.weight"] = ("model.layers.1.feed_forward.gate.weight",)
    sources["blk.1.exp_probs_b.bias"] = ("model.layers.1.feed_forward.expert_bias",)
    for part, original in (("gate", "w1"), ("up", "w3"), ("down", "w2")):
        sources[f"blk.1.ffn_{part}_exps.weight"] = tuple(
            f"model.layers.1.feed_forward.experts.{e}.{original}.weight" for e in range(4))
    rng, payload, header = np.random.default_rng(93), bytearray(), {}

    def append(name, values, dtype):
        raw = encode_bfloat16(values).tobytes() if dtype == "BF16" else values.tobytes()
        start = len(payload)
        payload.extend(raw)
        header[name] = dict(shape=list(values.shape), dtype=dtype, data_offsets=[start, len(payload)])

    for name, shape in shapes.items():
        group = sources[name]
        local = shape[1:] if len(group) > 1 else shape
        if name.endswith("conv.weight"):
            local = (c.width, 1, c.conv)
        quantized = name.endswith("_exps.weight") or (len(local) == 2 and name not in
                    ("token_embd.weight", "blk.1.ffn_gate_inp.weight") and "shortconv." not in name)
        for source in group:
            values = (rng.uniform(.8, 1.2, local) if len(local) == 1 and not name.endswith("bias")
                      else rng.normal(0, .03, local)).astype("float32")
            if quantized:
                append(source, encode_storage(values / .01), "F8_E4M3")
                append(source[:-6] + "weight_scale", np.full(((local[0] + 127) // 128, local[1] // 128), .01,
                                                             dtype="float32"), "BF16")
            else:
                append(source, values, "F32" if name.endswith("bias") else "BF16")
    encoded = json.dumps(header).encode()
    (directory / "config.json").write_text(json.dumps(config))
    (directory / "model.safetensors").write_bytes(struct.pack("<Q", len(encoded)) + encoded + payload)
    return directory


def test_native_moe_maps_original_scale_buffers_and_shared_graph(tmp_path):
    from akas.optimization.context import discover

    path = fixture(tmp_path / "weights")
    loaded = LFM2MoECheckpoint(path, tokenizer=False)
    assert discover(path).endswith(":LFM2MoE")
    assert loaded.config.experts == 4 and loaded.config.top_k == 2
    graph = LFM2MoE.compose(loaded, rows=3, chunk=4, max_requests=4, max_context=64).graph
    assert graph.buffers["blk.1.ffn_gate_exps.weight"].shape == (4, 256, 256)
    assert graph.buffers["blk.1.ffn_gate_exps.weight.scale"].shape == (4, 2, 2)
    assert graph.buffers["blk.1.ffn_gate_exps.weight.scale"].dtype == "bfloat16"
    assert {"quantize", "expert_partial", "routed_combine", "fp8_linear"} <= {call.kind for call in graph.calls}
    assert not any(call.kind == "expert_tile_map" for call in graph.calls)
    assert any(call.kind == "expert_tiles" for call in graph.calls)
    assert all(spec.dtype == "float16" for name, spec in graph.buffers.items() if name.endswith((".kc", ".vc")))
    with pytest.raises(ValueError, match="CUDA"):
        LFM2MoE.compose(loaded, rows=1, chunk=1, max_requests=1, max_context=64, provider="webgpu")


@pytest.mark.parametrize("mutation", [
    lambda d: d.update(num_experts_per_tok=5),
    lambda d: d.update(use_expert_bias=False),
    lambda d: d["quantization_config"]["config_groups"]["FP8_BLOCK"]["weights"].update(block_structure=[64, 128]),
])
def test_native_moe_rejects_unsupported_semantics_before_allocating(tmp_path, mutation):
    path = fixture(tmp_path / "weights")
    data = json.loads((path / "config.json").read_text())
    mutation(data)
    (path / "config.json").write_text(json.dumps(data))
    with pytest.raises(ValueError):
        LFM2MoECheckpoint(path, tokenizer=False)


@pytest.mark.skipif(os.getenv("AKAS_LFM_FP8_CUDA") != "1", reason="native FP8 CUDA qualification")
@pytest.mark.parametrize("kind,p", [
    ("fp8_linear", dict(r=3, k=256, o=128, input_dtype="float32")),
    ("expert_partial", dict(r=3, rows=3, k=256, o=128, experts=4, top=2, partitions=1, block_m=16)),
    ("expert_partial", dict(r=33, rows=33, k=256, o=128, experts=4, top=2, partitions=1, block_m=16, compact=True)),
    ("expert_tiles", dict(r=33, experts=4, top=2, block_m=16)),
    ("quantize", dict(r=3, k=256, input_dtype="float32")),
])
def test_native_fp8_operations_match_independent_references(tmp_path, kind, p):
    import tensor
    from akas.compilation.selection import source
    from akas.kernels.definition import define
    from akas.kernels.registry import validation
    from tensor.compiler.frontend.signature import frontend_arguments

    primitive = define(dict(kind=kind, parameters=p, contract="reference"))
    case = validation(kind, p, frontend_arguments(primitive, {}))
    entry, artifact = tmp_path / "kernel.py", tmp_path / "kernel.tbin"
    entry.write_text(source(kind, p, contract="reference", target="sm_89").render())
    tensor.build(entry, artifact, target="sm_89")
    with tensor.Device() as device:
        executable = device.load(artifact)
        buffers = {}
        for item in executable.manifest["arguments"]:
            values = case.arguments[item["name"]]
            buffers[item["name"]] = (device.from_numpy(values, dtype="bfloat16") if item["dtype"] == "bfloat16"
                                      else device.from_numpy(values))
        executable.launch(*(buffers[item["name"]] for item in executable.manifest["arguments"]))
        for name, expected in case.expected.items():
            np.testing.assert_allclose(buffers[name].to_numpy(), expected, rtol=case.rtol, atol=case.atol)


def reference(checkpoint):
    from support.native_fp8_reference import NativeFP8Reference

    return NativeFP8Reference(checkpoint)


@pytest.mark.skipif(os.getenv("AKAS_LFM_FP8_CUDA") != "1", reason="native FP8 model qualification")
def test_native_model_reordered_ragged_requests_reuse_common_executor(tmp_path):
    import tensor
    from akas.compilation import compile_checkpoint

    path = fixture(tmp_path / "weights")
    checkpoint = LFM2MoECheckpoint(path, tokenizer=False)
    bundle = tmp_path / "program"
    compile_checkpoint(LFM2MoE, path, bundle, checkpoint_options={"tokenizer": False},
                       geometries=[(2, 1), (2, 4)], max_requests=4, max_context=64,
                       target="sm_89", search=False)
    with tensor.Device() as device, LFM2MoE(path, bundle, device, checkpoint_options={"tokenizer": False}) as model:
        slots = [model.admit_at(3), model.admit_at(1)]
        sequences = [[1, 3, 5], [2, 4]]
        expected = [reference(checkpoint), reference(checkpoint)]
        predictions = model.prefill(slots, sequences, chunk=4)
        actual = model.last_frame.feature("logits").to_numpy().reshape(2, 64)
        for row in range(2):
            target = expected[row].forward(sequences[row])
            np.testing.assert_allclose(actual[row], target, rtol=.05, atol=.005)
            assert predictions[row] == target.argmax()
        model.decode(slots[::-1], predictions[::-1])
        actual = model.last_frame.feature("logits").to_numpy().reshape(2, 64)
        for row, index in enumerate((1, 0)):
            target = expected[index].forward([predictions[index]])
            np.testing.assert_allclose(actual[row], target, rtol=.05, atol=.005)
        model.release(3)
        assert model.admit_at(3) == 3
        model.prefill([3], [[7, 9, 11]], chunk=4)
        target = reference(checkpoint).forward([7, 9, 11])
        np.testing.assert_allclose(model.last_frame.feature("logits").to_numpy().reshape(2, 64)[0],
                                   target, rtol=.05, atol=.005)
