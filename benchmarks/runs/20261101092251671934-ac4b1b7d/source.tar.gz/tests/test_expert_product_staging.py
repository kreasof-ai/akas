"""Typed product staging retains the shared expert arithmetic."""
import os
import pytest

@pytest.mark.skipif(os.getenv('AKAS_LFM_FP8_CUDA')!='1',reason='CUDA expert product staging qualification')
@pytest.mark.parametrize('kind,layout,packed,stages,threads,dtype',[
 ('fp8_expert_swiglu','wide',True,1,256,'bfloat16'),
 ('fp8_expert_swiglu','wide',True,2,256,'bfloat16'),
 ('fp8_expert_swiglu','wide',True,1,512,'bfloat16'),
 ('fp8_expert_swiglu','wide',True,2,512,'bfloat16'),
 ('fp8_expert_swiglu','wide',True,1,256,'float16'),
 ('fp8_expert_swiglu','wide',True,1,256,'float32'),
])
def test_typed_product_staging_matches_independent_equations(tmp_path,kind,layout,packed,stages,threads,dtype):
 from test_lfm_moe_native import test_native_operations_match_independent_references as check
 check(tmp_path,kind,dict(r=65,rows=65,k=384,o=256,experts=7,top=3,partitions=1,
   block_m=64,max_block_m=128,compact=True,tile_map=True,columns=128,
   threads=threads,stages=stages,pair_layout=layout,activation_vector=16,
   packed_input=packed,packed_output=packed and kind=='fp8_expert_swiglu',
   routed_input=kind=='expert_partial',product_dtype=dtype,activation_dtype=dtype,
   stage_product=True))
