"""Budgeted, serial H200 benchmark. Run with modal run tools/h200_modal.py."""
from pathlib import Path
import modal

ROOT = Path(__file__).resolve().parents[1]
MODEL = 'LiquidAI/LFM2.5-24B-A2B-FP8'
REV = 'f54bf39547fd5b7955abb9fe8d1b151e31fbbddb'
app = modal.App('akas-h200-demonstration')
volume = modal.Volume.from_name('akas-h200-evidence', create_if_missing=True)
base = (modal.Image.from_registry('nvidia/cuda:13.0.2-devel-ubuntu24.04', add_python='3.12')
        .apt_install('git', 'g++', 'curl', 'libnuma1')
        .env({'HF_HOME':'/data/hf', 'CUDA_HOME':'/usr/local/cuda', 'OMP_NUM_THREADS':'4',
              'OPENBLAS_NUM_THREADS':'1', 'MAX_JOBS':'4', 'PYTHONPATH':'/workspace/akas/src:/workspace/akas:/workspace/tensor/src',
              'TENSOR_NVRTC_HOME':'/usr/local/cuda', 'TOKENIZERS_PARALLELISM':'false'}) )
def source(image):
    return (image.add_local_dir(ROOT / 'src', '/workspace/akas/src')
            .add_local_dir(ROOT / 'tools', '/workspace/akas/tools')
            .add_local_dir(ROOT.parent / 'tensor' / 'src', '/workspace/tensor/src'))
vimage = source(base.uv_pip_install('vllm==0.31.0'))
simage = source(base.uv_pip_install('sglang[all]==0.5.21'))
aimage = source(base.uv_pip_install('numpy==2.5.3', 'tilelang==0.1.14', 'apache-tvm-ffi==0.1.12',
                                  'torch', 'safetensors', 'huggingface-hub', 'aiohttp', 'regex'))
cimage = source(
    base.uv_pip_install('numpy==2.5.3', 'tilelang==0.1.14', 'apache-tvm-ffi==0.1.12',
                        'torch', 'safetensors', 'huggingface-hub', 'aiohttp', 'regex')
    .add_local_dir(ROOT/'build/nvrtc-12.9', '/opt/tensor-nvrtc-12.9', copy=True)
    .env({'TENSOR_NVRTC_HOME':'/opt/tensor-nvrtc-12.9',
          'OPENBLAS_NUM_THREADS':'8', 'OMP_NUM_THREADS':'8'}))
dimage = modal.Image.debian_slim(python_version='3.12').uv_pip_install('huggingface-hub')

@app.function(image=dimage, volumes={'/data':volume}, timeout=1200, cpu=2, memory=4096, scaledown_window=2)
def download():
    from huggingface_hub import snapshot_download
    p = snapshot_download(MODEL, revision=REV, local_dir='/data/checkpoint')
    volume.commit()
    return p

def worker(runtime, repeats=3, options=None):
    import subprocess, json, time, os, hashlib
    from datetime import datetime, timezone
    os.chdir('/workspace/akas')
    os.environ['OMP_NUM_THREADS']='1'
    os.environ['FLASHINFER_WORKSPACE_BASE']='/data/cache/flashinfer'
    os.environ['VLLM_CACHE_ROOT']='/data/cache/vllm'
    os.environ['TRITON_CACHE_DIR']='/data/cache/triton'
    os.environ['TORCHINDUCTOR_CACHE_DIR']='/data/cache/inductor'
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    directory=Path('/data/results')/f'{stamp}-{runtime}'
    directory.mkdir(parents=True)
    cfg=dict(checkpoint='/data/checkpoint', shapes=[[b,2048] for b in [1,4,16,64,256]],
             vocab=131072, output_tokens=128, mode='ar', optimized=True, streaming=True,
             warmup=1, repeats=repeats, runtime_options=options or {})
    # Read actual vocab; every runtime shares the same seeded token-ID prompts.
    cfg['vocab']=json.loads(Path('/data/checkpoint/config.json').read_text())['vocab_size']
    from akas.text.tokenizer import Tokenizer
    tok=Tokenizer.from_pretrained('/data/checkpoint')
    cfg['probe_prompts']=[tok.encode(text,add_bos=True) for text in [
        'The capital of France is', 'One plus one equals',
        'The largest planet in the solar system is', 'Water freezes at',
        'A simple Python function to add two numbers:\n', 'The opposite of hot is',
        'The first three prime numbers are', 'The chemical symbol for gold is']]
    (directory/'config.json').write_text(json.dumps(cfg,indent=2))
    start=time.monotonic()
    command=['python','-u','-m',f'tools.baselines.{runtime}','--config',str(directory/'config.json'),'--out',str(directory/'raw.json')]
    with (directory/'worker.log').open('w') as log:
        proc=subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,text=True)
        for line in proc.stdout:
            print(line,end='',flush=True); log.write(line); log.flush()
        code=proc.wait()
    meta=dict(runtime=runtime, returncode=code, elapsed_seconds=time.monotonic()-start,
              gpu=subprocess.check_output(['nvidia-smi','-q'],text=True), model=MODEL, revision=REV,
              dependencies=subprocess.check_output(['python','-m','pip','freeze'],text=True),
              started_at=stamp, command=command)
    (directory/'execution.json').write_text(json.dumps(meta,indent=2))
    volume.commit()
    return dict(directory=str(directory), **meta)

@app.function(image=vimage, gpu='H200', volumes={'/data':volume}, timeout=1800, cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def vllm(repeats:int=3, options:dict|None=None):
    return worker('vllm',repeats,options)

@app.function(image=simage, gpu='H200', volumes={'/data':volume}, timeout=1800, cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def sglang(repeats:int=3, options:dict|None=None):
    return worker('sglang',repeats,options)

@app.function(image=aimage, gpu='H200', volumes={'/data':volume}, timeout=3600, cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def akas(program:str='fp8-small', repeats:int=3,profile:bool=True):
    import subprocess, time, json
    start=time.monotonic()
    proc=subprocess.run(['python','-u','-m','tools.h200_akas','measure','--program',f'/data/programs/{program}', '--out', f'/data/results/akas-{program}-{time.time_ns()}.json','--repeats',str(repeats),*(['--profile'] if profile else [])],cwd='/workspace/akas')
    volume.commit()
    return dict(returncode=proc.returncode, elapsed_seconds=time.monotonic()-start)

@app.function(image=aimage, gpu='H200', volumes={'/data':volume}, timeout=1200, cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def tune(program:str='fp8-small'):
    import subprocess,time
    tick=time.monotonic()
    out=f'/data/results/kernel-sweep-{time.time_ns()}.json'
    p=subprocess.run(['python','-u','-m','tools.h200_kernel_sweep','benchmark',
        '--program',f'/data/programs/{program}','--sweep','/data/sweep-v1','--out',out],cwd='/workspace/akas')
    volume.commit()
    return dict(returncode=p.returncode,elapsed_seconds=time.monotonic()-tick,out=out)

@app.function(image=aimage, gpu='H200', volumes={'/data':volume}, timeout=1800, cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def native(program:str='fp8-small',repeats:int=3,profile_only:bool=False,batches:list[int]|None=None):
    import subprocess,time
    tick=time.monotonic();out=f'/data/results/native-{program}-{time.time_ns()}.json'
    p=subprocess.run(['python','-u','-m','tools.h200_native','--program',f'/data/programs/{program}','--out',out,'--repeats',str(repeats),*(['--profile-only'] if profile_only else []),*(['--batches',*map(str,batches)] if batches else [])],cwd='/workspace/akas')
    volume.commit()
    return dict(returncode=p.returncode,elapsed_seconds=time.monotonic()-tick,out=out)

@app.function(image=aimage, gpu='H200', volumes={'/data':volume}, timeout=300, cpu=4, memory=65536, scaledown_window=2, max_containers=1)
def tmaqual():
    import subprocess,time
    tick=time.monotonic()
    p=subprocess.run(['python','-u','-m','tools.h200_tma_qualify'],cwd='/workspace/akas')
    volume.commit()
    return dict(returncode=p.returncode,elapsed_seconds=time.monotonic()-tick)

def native_reference_worker(runtime):
    import os,subprocess,time
    stamp=time.time_ns();out=f'/data/results/native-ref-{runtime}-{stamp}'
    os.makedirs(out,exist_ok=True)
    env={**os.environ,'OMP_NUM_THREADS':'1','AKAS_GPU_EVENT_DIR':out,
        'AKAS_GPU_EVENT_CONTROL':f'{out}/control.json',
        'SGLANG_ENABLE_DELAY_SAMPLE':'0',
        'PYTHONPATH':'/workspace/akas/tools/baselines/native_site:'+os.environ.get('PYTHONPATH',''),
        'FLASHINFER_WORKSPACE_BASE':'/data/cache/flashinfer','VLLM_CACHE_ROOT':'/data/cache/vllm',
        'TRITON_CACHE_DIR':'/data/cache/triton','TORCHINDUCTOR_CACHE_DIR':'/data/cache/inductor'}
    tick=time.monotonic()
    p=subprocess.run(['python','-u','-m','tools.h200_native_refs','--runtime',runtime,'--out',out],env=env,cwd='/workspace/akas')
    volume.commit();return dict(returncode=p.returncode,elapsed_seconds=time.monotonic()-tick,out=out)

@app.function(image=vimage,gpu='H200',volumes={'/data':volume},timeout=1800,cpu=4,memory=65536,scaledown_window=2,max_containers=1)
def vnative():return native_reference_worker('vllm')

@app.function(image=simage,gpu='H200',volumes={'/data':volume},timeout=1800,cpu=4,memory=65536,scaledown_window=2,max_containers=1)
def snative():return native_reference_worker('sglang')

def inspect_sources(runtime, paths):
    import importlib.util
    root=Path(importlib.util.find_spec(runtime).origin).parent
    return {path:(root/path).read_text() for path in paths if (root/path).exists()}

@app.function(image=vimage, timeout=120, cpu=1, memory=2048, scaledown_window=2)
def vsource():
    return inspect_sources('vllm',['v1/worker/gpu_worker.py','v1/worker/gpu_model_runner.py','v1/worker/gpu/model_runner.py'])

@app.function(image=simage, timeout=120, cpu=1, memory=2048, scaledown_window=2)
def ssource():
    return inspect_sources('sglang',['srt/managers/tp_worker.py','srt/model_executor/model_runner.py'])

@app.local_entrypoint()
def main(action:str='download', repeats:int=3, options:str='{}', program:str='fp8-small'):
    import json, time
    if action in ('akas', 'tune'):
        raise RuntimeError('Use modal run tools/h200_akas_optimize.py; the standard campaign owns compilation, qualification and promotion.')
    ledger_path=ROOT/'build/h200/cost-ledger.json'
    ledger_path.parent.mkdir(parents=True,exist_ok=True)
    ledger=json.loads(ledger_path.read_text()) if ledger_path.exists() else []
    if action=='source':
        for runtime,callback in [('vllm',vsource),('sglang',ssource)]:
            for path,source_text in callback.remote().items():
                dest=ROOT/'build/h200/baseline-source'/runtime/path
                dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(source_text)
                print(dest)
        ledger.append(dict(action='CPU-source-inspection',conservative_usd=.02,status='completed'))
        ledger_path.write_text(json.dumps(ledger,indent=2));return
    rate=.001261+4*.0000131+64*.00000222
    # Reserve each function's full timeout before allocating any GPU.
    reserve=(1200 if action=='tune' else 3600 if action=='akas' else 1800)*rate if action!='download' else .15
    if sum(row['conservative_usd'] for row in ledger)+reserve > 28:
        raise RuntimeError('Insufficient remaining campaign budget for this bounded job')
    if action != 'download':
        names={Path(e.path).name for e in volume.listdir('/checkpoint')}
        required={'tokenizer.json','config.json', *[f'model-{i:05d}-of-00010.safetensors' for i in range(1,11)]}
        if not required <= names:
            raise RuntimeError(f'Checkpoint not ready; refusing GPU allocation. Missing {required-names}')
        if action in ('akas','native','profile','tune') and 'program.json' not in {Path(e.path).name for e in volume.listdir(f'/programs/{program}')}:
            raise RuntimeError('Compiled program not uploaded; refusing GPU allocation')
    tick=time.monotonic()
    row=dict(action=action,started_at=time.time(),conservative_usd=reserve,status='reserved')
    ledger.append(row);ledger_path.write_text(json.dumps(ledger,indent=2))
    try:
        result = download.remote() if action=='download' else vnative.remote() if action=='native-vllm' else snative.remote() if action=='native-sglang' else tmaqual.remote() if action=='tmaqual' else native.remote(program,0,True) if action=='profile' else native.remote(program,repeats,**json.loads(options)) if action=='native' else tune.remote(program) if action=='tune' else akas.remote(program,repeats,**json.loads(options)) if action=='akas' else {'vllm':vllm,'sglang':sglang}[action].remote(repeats,json.loads(options))
    except BaseException:
        row['status']='failed';raise
    else:
        row['status']='completed'
    finally:
        row.update(elapsed_seconds=time.monotonic()-tick)
        if row['status']=='completed':
            row['conservative_usd']=(row['elapsed_seconds']+30)*(rate if action!='download' else .00015)
        ledger_path.write_text(json.dumps(ledger,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k not in ('gpu','dependencies')} if isinstance(result,dict) else result,indent=2))
    if isinstance(result,dict) and result.get('returncode',0):
        raise SystemExit(result['returncode'])
