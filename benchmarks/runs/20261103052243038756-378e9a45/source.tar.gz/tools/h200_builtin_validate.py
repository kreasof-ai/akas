"""Run the existing optimizer's full-model qualification on searched artifacts."""
from pathlib import Path
import modal
from tools.h200_modal import ROOT,aimage,volume

app=modal.App('akas-h200-builtin-model-validation')


@app.function(image=aimage,gpu='H200',volumes={'/data':volume},timeout=900,
              cpu=4,memory=65536,scaledown_window=2,max_containers=1)
def validate(program: str):
    import hashlib,json,os,time,traceback
    import numpy as np
    import tensor
    from akas.benchmarking.history import Recorder
    from akas.models.lfm2 import LFM2MoE
    from akas.optimization.evaluation import diagnostic,evaluate

    os.environ['AKAS_SKIP_AUTOTUNE']='0'
    source=Path('/data/programs')/program
    manifest=json.loads((source/'program.json').read_text())
    used={('decode',b,1) for b in (1,4,16,64,256)}|{('prefill',b,2048) for b in (1,4,16)}
    coverage={(p['phase'],p['rows'],p['chunk']):p for p in manifest['builtin_qualification']['phases']}
    kernels_pass=all(coverage[k]['status']=='passed' for k in used)
    metadata=dict(runtime='akas',purpose='builtin-model-qualification',
        model='LiquidAI/LFM2.5-24B-A2B-FP8',provider='cuda',target='sm_90a',mode='ar',
        weight_format='fp8',kv_dtype='float16',protocol='native-token-step-v2',
        transport='native optimizer phase and scheduler measurements',
        program=program,program_sha256=hashlib.sha256((source/'program.json').read_bytes()).hexdigest(),
        reference_run_id='20261102212133108734-4a2dd18e',reference_program='optimized-v5',
        qualification='Existing akas.optimization.evaluation.evaluate, unchanged: independent operation qualification, 1% full-model diagnostic equivalence, complete greedy output preservation and slot-reuse repeatability',
        builtin_kernel_qualification_complete=kernels_pass,
        kernel_coverage=manifest['builtin_qualification']['phases'],warmup=1,repeats=3)
    recorder=Recorder('/data/standard-benchmarks',metadata,kind='qualification',
        change='Run the existing optimizer full-model qualification on the built-in searched H200 program',
        parent=metadata['reference_run_id'],dependency_sources={'tensor':Path('/workspace/tensor')})
    recorder.artifact(Path(__file__),'benchmark.py')
    recipe=dict(chunk=2048,window=None,graphs=True,prefill_requests=16,
                prefill_token_budget=256*2048,decode_prefill_token_budget=256,mode='ar')
    workload=dict(batches=[1,4,16,64,256],prefix_tokens=[2048],output_tokens=128)
    previous=json.loads((Path('/data/standard-benchmarks/runs')/metadata['reference_run_id']/'report.json').read_text())
    previous['metadata']['run_id']=metadata['reference_run_id']
    results=[];status='failed';tick=time.monotonic();features={};evidence={}
    print('STARTED',recorder.id,program,'kernel coverage',kernels_pass,flush=True)
    try:
        with tensor.Device() as device:
            metadata['device']=device.info
            with LFM2MoE('/data/checkpoint','/data/programs/optimized-v5',device,
                         checkpoint_options={'tokenizer':False}) as baseline:
                baseline.prefill_group_size=16
                for batch in workload['batches']:
                    key=f'b{batch}-p2048'
                    evidence[key]=diagnostic(baseline,recipe,batch,2048)
                    print('REFERENCE DIAGNOSTIC',key,evidence[key].shape,flush=True)
            with LFM2MoE('/data/checkpoint',source,device,
                         checkpoint_options={'tokenizer':False}) as candidate:
                candidate.prefill_group_size=16
                results,features,statistics=evaluate(candidate,recipe,workload,reference=previous,evidence=evidence)
                metadata.update(statistics)
        status='passed' if kernels_pass else 'partial'
    except Exception as error:
        metadata.update(error=f'{type(error).__name__}: {error}',traceback=traceback.format_exc())
        results=getattr(error,'results',results);features=getattr(error,'diagnostics',features)
        print(metadata['traceback'],flush=True)
    finally:
        metadata.update(qualification_status=status,elapsed_seconds=time.monotonic()-tick)
        for name,data in [('baseline-diagnostics.npz',evidence),('candidate-diagnostics.npz',features)]:
            path=recorder.directory/name;np.savez_compressed(path,**data);recorder.artifact(path,name)
        recorder.program(source)
        for name in ('builtin-search-evidence.json','builtin-selection.json'):
            recorder.artifact(source/name,name)
        record=recorder.update(dict(metadata=metadata,results=results),final=True,status=status)
        volume.commit()
    print('BUILTIN MODEL QUALIFICATION',recorder.id,record['status'],flush=True)
    return dict(run_id=recorder.id,status=record['status'],error=metadata.get('error'))


@app.local_entrypoint()
def main(program: str):
    import json,time
    ledger_path=ROOT/'build/h200/cost-ledger.json';ledger=json.loads(ledger_path.read_text())
    rate=.001261+4*.0000131+64*.00000222
    if sum(r['conservative_usd'] for r in ledger)+900*rate>28:raise RuntimeError('insufficient budget')
    row=dict(action='akas-builtin-model-validation',program=program,status='reserved',
             started_at=time.time(),conservative_usd=900*rate)
    ledger.append(row);ledger_path.write_text(json.dumps(ledger,indent=2));tick=time.monotonic()
    try:
        result=validate.remote(program);row.update(status='completed',result=result);print(json.dumps(result),flush=True)
    finally:
        row['elapsed_seconds']=time.monotonic()-tick
        if row['status']=='completed':row['conservative_usd']=(row['elapsed_seconds']+30)*rate
        ledger_path.write_text(json.dumps(ledger,indent=2))
