"""Precompile built-in search seeds and neighbors without opening a GPU."""
import argparse
import concurrent.futures
import hashlib
import json
import multiprocessing
from pathlib import Path
import time


def compile_job(job):
    from akas.artifacts.schema import Kernel
    from akas.compilation.emit import compile_kernel
    tick=time.monotonic()
    try:
        result=compile_kernel(Path(job['out']),Kernel(job['id'],job['kind'],job['parameters'],
            job['source']),target='sm_90a',source_directory='sources',artifact_directory='outputs')
        return dict(id=job['id'],status='compiled',seconds=time.monotonic()-tick,artifact=result)
    except Exception as error:
        return dict(id=job['id'],status='failed',seconds=time.monotonic()-tick,error=str(error))


def main():
    from tools.h200_builtin_search import operation_bundle
    from akas.kernels.registry import candidates
    from akas.compilation.selection import selected_source
    from akas.compilation.state import mapped_source
    from tensor.compiler.search import neighbors

    parser=argparse.ArgumentParser()
    parser.add_argument('--program',type=Path,default=Path('build/h200/optimized-v5'))
    parser.add_argument('--out',type=Path,default=Path('build/h200/offline-builtin'))
    parser.add_argument('--geometries',default='decode:256,prefill:16')
    parser.add_argument('--workers',type=int,default=2)
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((args.program/'program.json').read_text());jobs={}
    for geometry in args.geometries.split(','):
        name,rows=geometry.split(':');rows=int(rows)
        phase=next(p for p in manifest['phases'] if p['phase']==name and p['rows']==rows)
        forward=json.loads((args.program/phase['path']).read_text())
        for key,record in forward['kernels'].items():
            if record['kind'] not in ('expert_pair_partial','expert_partial','expert_swiglu','fp8_expert_swiglu'):continue
            bundle,_=operation_bundle(args.program,phase,key);declaration=bundle.kernels[0]
            graph=bundle.manifest['forward'];kind=record['kind'];parameters=record['parameters']
            variants=candidates(kind,parameters,contract=graph['contract'],provider='cuda',
                                phase=graph['phase'],target='sm_90a')
            for variant in variants:
                axes=dict(variant.space)
                if not axes:continue
                current=record['schedule'] if record['schedule']['implementation']==variant.identifier else {}
                seed=dict(family=variant.identifier,**{k:current.get(k,v[0]) for k,v in axes.items()})
                if any(seed[k] not in v for k,v in axes.items()):continue
                configurations=[seed,*neighbors(seed,{variant.identifier:axes})]
                for config in configurations:
                    schedule={k:v for k,v in config.items() if k!='family'}
                    p={**parameters,**schedule}
                    if not variant.compatible(kind,p,contract=graph['contract'],provider='cuda',
                                              phase=graph['phase'],target='sm_90a'):continue
                    spec=dict(kind=kind,parameters=parameters,contract=graph['contract'],phase=graph['phase'])
                    source=selected_source(spec,schedule,dict(provider='cuda',target='sm_90a'),variant)
                    if declaration.mapping is not None:source=mapped_source(source,declaration.mapping)
                    text=source.render();digest=hashlib.sha256(text.encode()).hexdigest()
                    jobs[digest]=dict(id=digest,kind=kind,parameters=parameters,source=text,out=str(args.out))
    print('OFFLINE PRECOMPILE',len(jobs),'sources; no qualification or timing',flush=True)
    report=dict(purpose='compile-cache-only',jobs=[])
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,
            mp_context=multiprocessing.get_context('spawn')) as pool:
        for result in pool.map(compile_job,jobs.values(),chunksize=1):
            report['jobs'].append(result)
            (args.out/'compile.json').write_text(json.dumps(report,indent=2))
            print('COMPILED',len(report['jobs']),len(jobs),result['status'],round(result['seconds'],2),flush=True)


if __name__=='__main__':main()
